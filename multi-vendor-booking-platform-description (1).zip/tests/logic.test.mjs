// Run: node --experimental-strip-types --test tests/logic.test.mjs
import test from "node:test";
import assert from "node:assert/strict";
import { refundPercent, customerFee } from "../src/lib/policy.ts";
import { permissionsForRole, homeForRole, P } from "../src/lib/rbac.ts";

test("refund policy", () => {
  assert.equal(refundPercent(48, false), 100);
  assert.equal(refundPercent(10, false), 50);
  assert.equal(refundPercent(2, false), 0);
  assert.equal(refundPercent(1, true), 100); // provider cancels → full refund
});

test("VIP fee discount", () => {
  assert.equal(customerFee(2, 0), 2);
  assert.equal(customerFee(2, 50), 1);
  assert.equal(customerFee(2, 100), 0);
});

test("staff only gets delegated provider permissions", () => {
  const p = permissionsForRole("STAFF", [P.BOOKINGS_VIEW, P.ADMIN_ACCESS, "bogus"]);
  assert.deepEqual(p, [P.BOOKINGS_VIEW]);
  assert.ok(!p.includes(P.FINANCE_VIEW));
});

test("admin vs super admin separation", () => {
  assert.ok(!permissionsForRole("PLATFORM_ADMIN").includes(P.ADMINS_MANAGE));
  assert.ok(!permissionsForRole("PLATFORM_ADMIN").includes(P.CARDS_CREATE_LARGE));
  assert.ok(permissionsForRole("SUPER_ADMIN").includes(P.ADMINS_MANAGE));
  assert.deepEqual(permissionsForRole("CUSTOMER"), []);
});

test("role routing", () => {
  assert.equal(homeForRole("CUSTOMER"), "/app");
  assert.equal(homeForRole("PROVIDER_OWNER"), "/provider");
  assert.equal(homeForRole("STAFF"), "/staff");
  assert.equal(homeForRole("PLATFORM_ADMIN"), "/admin");
  assert.equal(homeForRole("SUPER_ADMIN"), "/super-admin");
});
