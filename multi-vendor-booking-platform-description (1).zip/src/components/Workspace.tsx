"use client";

import { useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import { DELEGABLE_PERMISSIONS, STAFF_PRESETS, P } from "@/lib/rbac";
import { Btn, Card, Empty, ErrorBox, Skeleton, STATUS_AR, inputCls, lyd, postJson, useApi, useToast } from "./ui";

interface Bk { id: number; bookingRef: string; serviceId: number; customerName: string; customerPhone: string; bookingDate: string; startTime: string; endTime: string; status: string; paymentMethod: string; totalPrice?: string; providerNet?: string; platformFee?: string }
interface StaffRow { id: number; fullName: string; phone: string | null; roleTitle: string; isActive: boolean; permissions: string[] }
interface Data {
  me: { fullName: string; permissions: string[] };
  organization: { nameAr: string; slug: string };
  services: { id: number; nameAr: string; price: string; durationMinutes: number }[];
  staff: StaffRow[];
  bookings: Bk[];
  finance: { wallet?: { balance: string; pendingSettlement: string; totalEarned: string; totalCommissionPaid: string }; subscription?: { status: string; renewalDate: string; plan?: { nameAr: string; commissionRate: string; monthlyPrice: string } } | null } | null;
}

export default function Workspace() {
  const tab = useSearchParams().get("tab") || "home";
  const { data, loading, error, reload } = useApi<Data>("/api/provider/dashboard");
  const toast = useToast();
  if (loading && !data) return <Skeleton rows={5} />;
  if (error) return <ErrorBox message={error} onRetry={reload} />;
  const d = data!;
  const can = (p: string) => d.me.permissions.includes(p);
  const today = new Date().toISOString().slice(0, 10);
  const svcName = (id: number) => d.services.find((s) => s.id === id)?.nameAr || "";

  async function setStatus(id: number, status: string) {
    try { await postJson(`/api/provider/bookings/${id}`, { status }, "PATCH"); toast.show("تم تحديث الحجز"); reload(); }
    catch (e) { toast.show((e as Error).message, false); }
  }
  async function cancel(id: number) {
    try { await postJson(`/api/bookings/${id}/cancel`, { reason: "إلغاء من المنشأة" }); toast.show("تم الإلغاء واسترداد المبلغ للعميل"); reload(); }
    catch (e) { toast.show((e as Error).message, false); }
  }

  const BookingList = ({ list }: { list: Bk[] }) => list.length === 0 ? <Empty title="لا توجد حجوزات" /> : (
    <div className="space-y-2">
      {list.map((b) => (
        <Card key={b.id}>
          <div className="flex justify-between gap-2">
            <div>
              <div className="font-black text-sm">{b.customerName}</div>
              <div className="text-xs text-slate-500">{svcName(b.serviceId)}</div>
              <div className="text-xs text-slate-400" dir="ltr">{b.customerPhone}</div>
            </div>
            <div className="text-left">
              <div className="text-sm font-bold">{b.startTime}</div>
              <div className="text-[11px] text-slate-400">{b.bookingDate}</div>
              <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-slate-100">{STATUS_AR[b.status]}</span>
            </div>
          </div>
          {b.totalPrice && <div className="text-xs text-slate-500 mt-2">الإجمالي {lyd(b.totalPrice)} • صافي {lyd(b.providerNet)}</div>}
          {b.status === "CONFIRMED" && (
            <div className="flex gap-2 mt-3 flex-wrap">
              {can(P.BOOKINGS_CHECKIN) && <Btn className="flex-1" onClick={() => setStatus(b.id, "COMPLETED")}>حضر / إكمال</Btn>}
              {can(P.BOOKINGS_CHECKIN) && <Btn variant="ghost" className="flex-1" onClick={() => setStatus(b.id, "NO_SHOW")}>لم يحضر</Btn>}
              {can(P.BOOKINGS_CANCEL) && <Btn variant="danger" onClick={() => cancel(b.id)}>إلغاء</Btn>}
            </div>
          )}
        </Card>
      ))}
    </div>
  );

  const todays = d.bookings.filter((b) => b.bookingDate === today);

  return (
    <div className="space-y-5">
      <div>
        <p className="text-sm text-slate-500">{d.organization.nameAr}</p>
        <h1 className="text-xl font-black">{{ home: "الرئيسية", bookings: "الحجوزات", new: "حجز جديد", customers: "العملاء", services: "الخدمات", staff: "الموظفون", finance: "الإيرادات والمحفظة", more: "المزيد" }[tab] || "الرئيسية"}</h1>
      </div>

      {tab === "home" && (
        <>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            {can(P.BOOKINGS_VIEW) && <Stat label="حجوزات اليوم" value={todays.length} />}
            {can(P.BOOKINGS_VIEW) && <Stat label="القادمة" value={d.bookings.filter((b) => b.bookingDate >= today && b.status === "CONFIRMED").length} />}
            {d.finance?.wallet && <Stat label="المستحق للتسوية" value={lyd(d.finance.wallet.pendingSettlement)} />}
            {d.finance?.wallet && <Stat label="إجمالي الإيرادات" value={lyd(d.finance.wallet.totalEarned)} />}
          </div>
          {can(P.BOOKINGS_VIEW) ? (<><h2 className="font-black">حجوزات اليوم</h2><BookingList list={todays} /></>) : <Empty title="لا توجد أدوات حجز ضمن صلاحياتك" hint="تواصل مع صاحب المنشأة لتعديل الصلاحيات" />}
          <Card className="text-sm">رابط الحجز المباشر لمشاركته في وسائل التواصل: <b dir="ltr" className="text-blue-700">{typeof window !== "undefined" ? window.location.origin : ""}/?p={d.organization.slug}</b></Card>
        </>
      )}

      {tab === "bookings" && can(P.BOOKINGS_VIEW) && <BookingList list={d.bookings} />}
      {tab === "new" && can(P.BOOKINGS_CREATE) && <NewBooking services={d.services} onDone={() => { toast.show("تم إنشاء الحجز"); reload(); }} onErr={(m) => toast.show(m, false)} />}
      {tab === "customers" && can(P.CUSTOMERS_VIEW) && <Customers bookings={d.bookings} />}
      {tab === "services" && can(P.SERVICES_MANAGE) && <Services services={d.services} onDone={reload} toast={toast.show} />}
      {tab === "staff" && can(P.STAFF_MANAGE) && <StaffMgr staff={d.staff} onDone={reload} toast={toast.show} />}
      {tab === "finance" && can(P.FINANCE_VIEW) && d.finance && <Finance f={d.finance} />}
      {tab === "more" && <More can={can} />}
      {toast.node}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string | number }) {
  return <div className="bg-white rounded-2xl border border-slate-200 p-4"><div className="text-xs text-slate-500">{label}</div><div className="text-lg font-black mt-1">{value}</div></div>;
}

function NewBooking({ services, onDone, onErr }: { services: Data["services"]; onDone: () => void; onErr: (m: string) => void }) {
  const [f, setF] = useState({ serviceId: services[0]?.id, bookingDate: new Date().toISOString().slice(0, 10), startTime: "10:00", customerName: "", customerPhone: "" });
  const [busy, setBusy] = useState(false);
  return (
    <Card>
      <form className="space-y-3" onSubmit={async (e) => { e.preventDefault(); setBusy(true); try { await postJson("/api/provider/bookings", f); onDone(); setF({ ...f, customerName: "", customerPhone: "" }); } catch (er) { onErr((er as Error).message); } finally { setBusy(false); } }}>
        <select className={inputCls} value={f.serviceId} onChange={(e) => setF({ ...f, serviceId: Number(e.target.value) })}>{services.map((s) => <option key={s.id} value={s.id}>{s.nameAr}</option>)}</select>
        <div className="grid grid-cols-2 gap-2">
          <input type="date" className={inputCls} value={f.bookingDate} onChange={(e) => setF({ ...f, bookingDate: e.target.value })} />
          <input type="time" className={inputCls} value={f.startTime} onChange={(e) => setF({ ...f, startTime: e.target.value })} />
        </div>
        <input className={inputCls} required placeholder="اسم العميل" value={f.customerName} onChange={(e) => setF({ ...f, customerName: e.target.value })} />
        <input className={inputCls} dir="ltr" required placeholder="+2189XXXXXXXX" value={f.customerPhone} onChange={(e) => setF({ ...f, customerPhone: e.target.value })} />
        <Btn variant="accent" className="w-full" disabled={busy}>{busy ? "جاري الحفظ..." : "إنشاء الحجز"}</Btn>
      </form>
    </Card>
  );
}

function Customers({ bookings }: { bookings: Bk[] }) {
  const rows = useMemo(() => {
    const m = new Map<string, { name: string; phone: string; count: number; last: string; noShow: number; spent: number }>();
    for (const b of bookings) {
      const r = m.get(b.customerPhone) || { name: b.customerName, phone: b.customerPhone, count: 0, last: "", noShow: 0, spent: 0 };
      r.count++; if (b.bookingDate > r.last) r.last = b.bookingDate; if (b.status === "NO_SHOW") r.noShow++;
      if (b.totalPrice && ["CONFIRMED", "COMPLETED"].includes(b.status)) r.spent += parseFloat(b.totalPrice);
      m.set(b.customerPhone, r);
    }
    return [...m.values()];
  }, [bookings]);
  return rows.length === 0 ? <Empty title="لا يوجد عملاء بعد" /> : (
    <div className="space-y-2">{rows.map((r) => (
      <Card key={r.phone}>
        <div className="flex justify-between"><b className="text-sm">{r.name}</b><span className="text-xs text-slate-500" dir="ltr">{r.phone}</span></div>
        <div className="text-xs text-slate-500 mt-1">{r.count} حجوزات • آخر زيارة {r.last} • غياب {r.noShow}{r.spent ? ` • ${lyd(r.spent)}` : ""}</div>
      </Card>
    ))}</div>
  );
}

function Services({ services, onDone, toast }: { services: Data["services"]; onDone: () => void; toast: (m: string, ok?: boolean) => void }) {
  const [f, setF] = useState({ nameAr: "", price: "", durationMinutes: "60" });
  return (
    <div className="space-y-3">
      <Card>
        <form className="grid gap-2 sm:grid-cols-4" onSubmit={async (e) => { e.preventDefault(); try { await postJson("/api/services", f); toast("تمت إضافة الخدمة"); setF({ nameAr: "", price: "", durationMinutes: "60" }); onDone(); } catch (er) { toast((er as Error).message, false); } }}>
          <input className={`${inputCls} sm:col-span-2`} required placeholder="اسم الخدمة" value={f.nameAr} onChange={(e) => setF({ ...f, nameAr: e.target.value })} />
          <input className={inputCls} required type="number" placeholder="السعر د.ل" value={f.price} onChange={(e) => setF({ ...f, price: e.target.value })} />
          <input className={inputCls} type="number" placeholder="المدة (دقيقة)" value={f.durationMinutes} onChange={(e) => setF({ ...f, durationMinutes: e.target.value })} />
          <Btn className="sm:col-span-4">إضافة خدمة</Btn>
        </form>
      </Card>
      {services.map((s) => <Card key={s.id}><div className="flex justify-between text-sm"><b>{s.nameAr}</b><span>{lyd(s.price)} • {s.durationMinutes} د</span></div></Card>)}
    </div>
  );
}

function StaffMgr({ staff, onDone, toast }: { staff: StaffRow[]; onDone: () => void; toast: (m: string, ok?: boolean) => void }) {
  const [editing, setEditing] = useState<Record<number, string[]>>({});
  const [nf, setNf] = useState({ fullName: "", phone: "", roleTitle: "استقبال" });
  return (
    <div className="space-y-3">
      <Card>
        <div className="font-black mb-2">إضافة موظف</div>
        <form className="space-y-2" onSubmit={async (e) => { e.preventDefault(); try { await postJson("/api/provider/staff", { ...nf, permissions: STAFF_PRESETS[nf.roleTitle] || [] }); toast("تمت إضافة الموظف – يمكنه الدخول برقم هاتفه"); setNf({ fullName: "", phone: "", roleTitle: "استقبال" }); onDone(); } catch (er) { toast((er as Error).message, false); } }}>
          <input className={inputCls} required placeholder="الاسم" value={nf.fullName} onChange={(e) => setNf({ ...nf, fullName: e.target.value })} />
          <input className={inputCls} dir="ltr" required placeholder="+2189XXXXXXXX" value={nf.phone} onChange={(e) => setNf({ ...nf, phone: e.target.value })} />
          <select className={inputCls} value={nf.roleTitle} onChange={(e) => setNf({ ...nf, roleTitle: e.target.value })}>{Object.keys(STAFF_PRESETS).map((k) => <option key={k}>{k}</option>)}</select>
          <Btn className="w-full">إضافة</Btn>
        </form>
      </Card>
      {staff.length === 0 ? <Empty title="لا يوجد موظفون" /> : staff.map((s) => {
        const perms = editing[s.id] ?? s.permissions;
        return (
          <Card key={s.id}>
            <div className="flex justify-between mb-2"><b>{s.fullName} — {s.roleTitle}</b><span className="text-xs text-slate-400" dir="ltr">{s.phone}</span></div>
            <div className="grid sm:grid-cols-2 gap-1">
              {DELEGABLE_PERMISSIONS.map((p) => (
                <label key={p.key} className="flex items-center gap-2 min-h-[40px] text-sm">
                  <input type="checkbox" className="w-5 h-5" checked={perms.includes(p.key)} onChange={(e) => setEditing({ ...editing, [s.id]: e.target.checked ? [...perms, p.key] : perms.filter((x) => x !== p.key) })} />
                  {p.label}
                </label>
              ))}
            </div>
            {editing[s.id] && <Btn className="w-full mt-2" onClick={async () => { try { await postJson("/api/provider/staff", { staffId: s.id, permissions: perms }, "PATCH"); toast("تم حفظ الصلاحيات"); const n = { ...editing }; delete n[s.id]; setEditing(n); onDone(); } catch (er) { toast((er as Error).message, false); } }}>حفظ الصلاحيات</Btn>}
          </Card>
        );
      })}
    </div>
  );
}

function Finance({ f }: { f: NonNullable<Data["finance"]> }) {
  return (
    <div className="space-y-3">
      {f.wallet && (
        <div className="grid grid-cols-2 gap-3">
          <Stat label="الرصيد المتاح" value={lyd(f.wallet.balance)} />
          <Stat label="معلق للتسوية" value={lyd(f.wallet.pendingSettlement)} />
          <Stat label="إجمالي الإيرادات" value={lyd(f.wallet.totalEarned)} />
          <Stat label="عمولة المنصة" value={lyd(f.wallet.totalCommissionPaid)} />
        </div>
      )}
      {f.subscription && (
        <Card><div className="font-black">الاشتراك: {f.subscription.plan?.nameAr}</div><div className="text-sm text-slate-500 mt-1">عمولة {f.subscription.plan?.commissionRate}% • التجديد {new Date(f.subscription.renewalDate).toLocaleDateString("ar-LY")}</div></Card>
      )}
      {/* TODO(payouts): payout request flow (bank transfer) – requires settlement schedule config */}
    </div>
  );
}

function More({ can }: { can: (p: string) => boolean }) {
  const items = [
    { tab: "services", label: "الخدمات", p: P.SERVICES_MANAGE },
    { tab: "staff", label: "الموظفون والصلاحيات", p: P.STAFF_MANAGE },
    { tab: "finance", label: "الإيرادات والمحفظة والاشتراك", p: P.FINANCE_VIEW },
  ].filter((i) => can(i.p));
  return items.length === 0 ? <Empty title="لا توجد أدوات إضافية ضمن صلاحياتك" /> : (
    <div className="bg-white rounded-2xl border border-slate-200 divide-y">
      {items.map((i) => <a key={i.tab} href={`?tab=${i.tab}`} className="block px-4 py-4 text-sm font-bold">{i.label}</a>)}
      <a href="/notifications" className="block px-4 py-4 text-sm font-bold">الإشعارات</a>
    </div>
  );
}
