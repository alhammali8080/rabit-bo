"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Eye, EyeOff, Zap, LogIn } from "lucide-react";
import { PORTALS, type PortalKey } from "@/lib/portals";
import { setToken, clearToken, apiFetch } from "@/lib/clientAuth";
import { Btn, inputCls, postJson } from "./ui";

/**
 * Login shown INSIDE the protected page. No navigation, no new tab: on success the
 * session is set and the same screen switches to the dashboard.
 */
export default function InlineLogin({ portal }: { portal: PortalKey }) {
  void 0;
  const cfg = PORTALS[portal];
  const router = useRouter();
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState("");

  async function enter(p: string, pw: string, label?: string) {
    setBusy(label || "form");
    setError("");
    try {
      const r = await postJson("/api/auth/login", { phone: p, password: pw, portal });
      setToken(r.token);
      // Confirm the session is readable from THIS page before switching the view.
      const me = await apiFetch("/api/me", { cache: "no-store" }).then((x) => x.json()).catch(() => null);
      if (!me?.user) {
        clearToken();
        throw new Error("لم يتم تثبيت الجلسة. أعد المحاولة.");
      }
      // Soft navigation only — the login stays alive and the dashboard appears in place.
      router.replace(r.redirect);
      router.refresh();
    } catch (e) {
      setError((e as Error).message);
      setBusy(null);
    }
  }

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <div className="w-full max-w-sm bg-white rounded-3xl shadow-xl overflow-hidden">
        <div className={`bg-gradient-to-l ${cfg.color} text-white p-5`}>
          <div className="flex items-center gap-3">
            <span className="text-4xl" aria-hidden>{cfg.emoji}</span>
            <div>
              <h1 className="font-black text-xl">{cfg.title}</h1>
              <p className="text-xs opacity-90">{cfg.subtitle}</p>
            </div>
          </div>
        </div>

        <div className="p-5 space-y-4">
          <div>
            <div className="text-xs font-bold text-slate-500 mb-2 flex items-center gap-1">
              <Zap className="w-4 h-4 text-amber-500" /> دخول بضغطة واحدة
            </div>
            <div className="space-y-2">
              {cfg.demo.map((d) => (
                <button key={d.phone} disabled={!!busy} onClick={() => enter(d.phone, "123456", d.phone)}
                  className={`w-full min-h-[52px] rounded-xl text-white font-bold bg-gradient-to-l ${cfg.color} disabled:opacity-60`}>
                  {busy === d.phone ? "جاري الدخول..." : d.label}
                </button>
              ))}
            </div>
          </div>

          {error && <div className="p-3 rounded-xl bg-red-50 text-red-700 text-sm border border-red-200">{error}</div>}

          <div className="relative flex items-center gap-2 text-xs text-slate-400"><span className="flex-1 h-px bg-slate-200" />أو بحسابك<span className="flex-1 h-px bg-slate-200" /></div>

          <form onSubmit={(e) => { e.preventDefault(); enter(phone, password); }} className="space-y-3">
            <input className={inputCls} dir="ltr" inputMode="tel" required placeholder="09XXXXXXXX" value={phone} onChange={(e) => setPhone(e.target.value)} />
            <div className="relative">
              <input className={inputCls} dir="ltr" type={show ? "text" : "password"} required placeholder="كلمة المرور" value={password} onChange={(e) => setPassword(e.target.value)} />
              <button type="button" onClick={() => setShow(!show)} aria-label="إظهار كلمة المرور" className="absolute left-3 top-3 text-slate-400">{show ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}</button>
            </div>
            <Btn className="w-full min-h-[50px]" disabled={!!busy}>
              <span className="inline-flex items-center gap-2"><LogIn className="w-4 h-4" />{busy === "form" ? "جاري الدخول..." : "دخول"}</span>
            </Btn>
          </form>
        </div>
      </div>
    </div>
  );
}
