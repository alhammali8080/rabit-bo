"use client";

import { useState } from "react";
import { useSearchParams } from "next/navigation";
import { Btn, Card, Empty, ErrorBox, Skeleton, inputCls, lyd, postJson, useApi, useToast } from "./ui";
import { ROLE_LABEL } from "@/lib/rbac";

type Toast = (m: string, ok?: boolean) => void;

export default function AdminConsole() {
  const tab = useSearchParams().get("tab") || "home";
  const toast = useToast();
  return (
    <div className="space-y-5">
      {tab === "home" && <Overview />}
      {tab === "users" && <Users toast={toast.show} />}
      {tab === "cards" && <Cards toast={toast.show} />}
      {tab === "vip" && <Vip toast={toast.show} />}
      {tab === "audit" && <Audit />}
      {tab === "care" && <Care toast={toast.show} />}
      {tab === "admins" && <Admins toast={toast.show} />}
      {toast.node}
    </div>
  );
}

interface Stats { metrics: Record<string, string | number>; auditLogs: { id: number; action: string; entity: string; entityId: string | null; userName: string | null; ipAddress: string | null; userAgent: string | null; result: string; createdAt: string; newValue: string | null }[] }

function Overview() {
  const { data, loading, error, reload } = useApi<Stats>("/api/admin/stats");
  if (loading) return <Skeleton rows={4} />;
  if (error) return <ErrorBox message={error} onRetry={reload} />;
  const m = data!.metrics;
  const items: [string, string | number][] = [
    ["المستخدمون", m.users], ["المنشآت", m.orgs], ["الحجوزات", m.bookings], ["GMV", lyd(m.gmv)],
    ["إيراد المنصة", lyd(m.platformRevenue)], ["أرصدة محافظ العملاء", lyd(m.walletLiability)], ["كروت مستخدمة (قيمة)", lyd(m.cardsRedeemed)],
  ];
  return (
    <>
      <h1 className="text-xl font-black">لوحة إدارة المنصة</h1>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {items.map(([k, v]) => <Card key={k}><div className="text-xs text-slate-500">{k}</div><div className="text-lg font-black mt-1">{v}</div></Card>)}
      </div>
    </>
  );
}

function Users({ toast }: { toast: Toast }) {
  const [q, setQ] = useState("");
  const { data, loading, reload } = useApi<{ id: number; fullName: string; phone: string; role: string; balance: string | null }[]>(`/api/admin/users?q=${encodeURIComponent(q)}`);
  const [adj, setAdj] = useState<{ id: number; amount: string; reason: string } | null>(null);
  return (
    <>
      <h1 className="text-xl font-black">المستخدمون والمحافظ</h1>
      <input className={inputCls} placeholder="بحث بالاسم أو الهاتف" value={q} onChange={(e) => setQ(e.target.value)} />
      {loading ? <Skeleton /> : !data?.length ? <Empty title="لا يوجد مستخدمون" /> : data.map((u) => (
        <Card key={u.id}>
          <div className="flex justify-between gap-2">
            <div><b className="text-sm">{u.fullName}</b><div className="text-xs text-slate-500" dir="ltr">{u.phone}</div></div>
            <div className="text-left"><span className="text-xs px-2 py-0.5 bg-slate-100 rounded">{ROLE_LABEL[u.role]}</span><div className="text-sm font-bold mt-1">{lyd(u.balance)}</div></div>
          </div>
          {u.role === "CUSTOMER" && (adj?.id === u.id ? (
            <div className="mt-3 space-y-2">
              <input className={inputCls} type="number" placeholder="القيمة (+ إضافة / - خصم)" value={adj.amount} onChange={(e) => setAdj({ ...adj, amount: e.target.value })} />
              <input className={inputCls} placeholder="سبب التعديل (إلزامي)" value={adj.reason} onChange={(e) => setAdj({ ...adj, reason: e.target.value })} />
              <div className="flex gap-2">
                <Btn className="flex-1" onClick={async () => { try { await postJson("/api/admin/users", { userId: u.id, amount: adj.amount, reason: adj.reason }); toast("تم التعديل وتسجيله في السجل المالي"); setAdj(null); reload(); } catch (e) { toast((e as Error).message, false); } }}>تأكيد</Btn>
                <Btn variant="ghost" onClick={() => setAdj(null)}>إلغاء</Btn>
              </div>
            </div>
          ) : <Btn variant="ghost" className="w-full mt-3" onClick={() => setAdj({ id: u.id, amount: "", reason: "" })}>تعديل إداري للرصيد</Btn>)}
        </Card>
      ))}
    </>
  );
}

interface Batch { id: number; batchRef: string; faceValue: string; quantity: number; used: number; remaining: number; totalValue: string; status: string; createdAt: string }

function Cards({ toast }: { toast: Toast }) {
  const { data, loading, error, reload } = useApi<Batch[]>("/api/admin/cards");
  const [f, setF] = useState({ faceValue: "50", quantity: "100", expiresInDays: "" });
  const [busy, setBusy] = useState(false);
  const [fresh, setFresh] = useState<{ batchRef: string; value: string; codes: { serial: string; code: string }[] } | null>(null);

  function exportCsv() {
    if (!fresh) return;
    const csv = "serial,code,value\n" + fresh.codes.map((c) => `${c.serial},${c.code},${fresh.value}`).join("\n");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob(["\ufeff" + csv], { type: "text/csv" }));
    a.download = `cards-${fresh.batchRef}.csv`;
    a.click();
  }
  function print() {
    if (!fresh) return;
    const w = window.open("", "_blank");
    if (!w) return;
    w.document.write(`<html dir="rtl"><head><title>${fresh.batchRef}</title><style>body{font-family:sans-serif}.g{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}.c{border:1px dashed #333;padding:10px;border-radius:8px}.v{font-size:20px;font-weight:bold}.k{font-family:monospace;font-size:15px;direction:ltr}</style></head><body><div class="g">${fresh.codes.map((c) => `<div class="c"><div>رابط للحجوزات – كرت شحن</div><div class="v">${fresh.value} د.ل</div><div class="k">${c.code}</div><small>${c.serial}</small></div>`).join("")}</div><script>print()</script></body></html>`);
    w.document.close();
  }

  return (
    <>
      <h1 className="text-xl font-black">كروت الشحن</h1>
      <Card>
        <div className="font-black mb-2">إنشاء دفعة جديدة (Batch)</div>
        <form className="grid gap-2 sm:grid-cols-4" onSubmit={async (e) => {
          e.preventDefault(); setBusy(true);
          try { const r = await postJson("/api/admin/cards", f); setFresh({ batchRef: r.batch.batchRef, value: r.batch.faceValue, codes: r.codes }); toast(`تم إنشاء ${r.codes.length} كرت`); reload(); }
          catch (er) { toast((er as { status?: number }).status === 403 ? "الدفعات الكبيرة تتطلب صلاحية Super Admin" : (er as Error).message, false); }
          finally { setBusy(false); }
        }}>
          <select className={inputCls} value={f.faceValue} onChange={(e) => setF({ ...f, faceValue: e.target.value })}>{[5, 10, 20, 50, 100, 200].map((v) => <option key={v} value={v}>{v} د.ل</option>)}</select>
          <input className={inputCls} type="number" min={1} max={5000} value={f.quantity} onChange={(e) => setF({ ...f, quantity: e.target.value })} placeholder="العدد" />
          <input className={inputCls} type="number" value={f.expiresInDays} onChange={(e) => setF({ ...f, expiresInDays: e.target.value })} placeholder="صلاحية بالأيام (اختياري)" />
          <Btn disabled={busy}>{busy ? "جاري الإنشاء..." : "إنشاء"}</Btn>
        </form>
      </Card>

      {fresh && (
        <Card className="border-amber-300 bg-amber-50">
          <div className="font-black">الدفعة {fresh.batchRef} – {fresh.codes.length} كرت</div>
          <p className="text-xs text-amber-900 mt-1">تنبيه أمني: الأكواد تظهر مرة واحدة فقط ولا تُخزَّن بشكل مقروء. قم بالتصدير أو الطباعة الآن.</p>
          <div className="flex gap-2 mt-3">
            <Btn onClick={print}>طباعة / PDF</Btn>
            <Btn variant="ghost" onClick={exportCsv}>تصدير Excel (CSV)</Btn>
            <Btn variant="danger" onClick={() => setFresh(null)}>إخفاء الأكواد</Btn>
          </div>
        </Card>
      )}

      {loading ? <Skeleton /> : error ? <ErrorBox message={error} onRetry={reload} /> : !data?.length ? <Empty title="لا توجد دفعات" /> : data.map((b) => (
        <Card key={b.id}>
          <div className="flex justify-between"><b>Batch #{b.batchRef}</b><span className="text-xs px-2 py-0.5 rounded bg-slate-100">{b.status}</span></div>
          <div className="text-sm text-slate-600 mt-1">القيمة {lyd(b.faceValue)} • العدد {b.quantity} • المستخدم {b.used} • المتبقي {b.remaining} • الإجمالي {lyd(b.totalValue)}</div>
          {b.status !== "CANCELLED" && (
            <div className="flex gap-2 mt-3">
              <Btn variant="ghost" onClick={async () => { await postJson("/api/admin/cards", { batchId: b.id, status: b.status === "ACTIVE" ? "SUSPENDED" : "ACTIVE" }, "PATCH").catch((e) => toast(e.message, false)); reload(); }}>{b.status === "ACTIVE" ? "إيقاف" : "تفعيل"}</Btn>
              <Btn variant="danger" onClick={async () => { if (!confirm("إلغاء الدفعة نهائياً؟ الكروت غير المستخدمة ستُلغى.")) return; await postJson("/api/admin/cards", { batchId: b.id, status: "CANCELLED" }, "PATCH").catch((e) => toast(e.message, false)); reload(); }}>إلغاء نهائي</Btn>
            </div>
          )}
        </Card>
      ))}
    </>
  );
}

interface VipData {
  tiers: { id: number; nameAr: string; benefits: { id: number; titleAr: string; key: string; value: string; isActive: boolean }[] }[];
  members: { id: number; name: string; phone: string; status: string; endsAt: string }[];
  campaigns: { id: number; titleAr: string; minRecharge: string; bonusAmount: string; vipOnly: boolean; isActive: boolean }[];
}

function Vip({ toast }: { toast: Toast }) {
  const { data, loading, reload } = useApi<VipData>("/api/admin/vip");
  const [g, setG] = useState({ phone: "", tierId: "", days: "365" });
  const [c, setC] = useState({ titleAr: "", minRecharge: "", bonusAmount: "", vipOnly: false });
  const act = async (body: unknown, ok: string) => { try { await postJson("/api/admin/vip", body); toast(ok); reload(); } catch (e) { toast((e as Error).message, false); } };
  if (loading || !data) return <Skeleton />;
  return (
    <>
      <h1 className="text-xl font-black">VIP والحملات</h1>
      <Card>
        <div className="font-black mb-2">منح عضوية VIP</div>
        <div className="grid gap-2 sm:grid-cols-4">
          <input className={inputCls} dir="ltr" placeholder="+2189..." value={g.phone} onChange={(e) => setG({ ...g, phone: e.target.value })} />
          <select className={inputCls} value={g.tierId} onChange={(e) => setG({ ...g, tierId: e.target.value })}><option value="">المستوى</option>{data.tiers.map((t) => <option key={t.id} value={t.id}>{t.nameAr}</option>)}</select>
          <input className={inputCls} type="number" value={g.days} onChange={(e) => setG({ ...g, days: e.target.value })} placeholder="المدة بالأيام" />
          <Btn onClick={() => act({ action: "grant", ...g }, "تم منح العضوية")}>منح</Btn>
        </div>
      </Card>
      {data.tiers.map((t) => (
        <Card key={t.id}>
          <div className="font-black mb-2">مزايا {t.nameAr}</div>
          {t.benefits.map((b) => (
            <div key={b.id} className="flex items-center justify-between gap-2 min-h-[48px] border-t first:border-0">
              <label className="flex items-center gap-2 text-sm"><input type="checkbox" className="w-5 h-5" checked={b.isActive} onChange={(e) => act({ action: "benefit", benefitId: b.id, isActive: e.target.checked }, "تم التحديث")} />{b.titleAr}</label>
              {b.key.endsWith("PERCENT") && <input className="w-20 min-h-[40px] border rounded-lg px-2 text-sm" type="number" defaultValue={Number(b.value)} onBlur={(e) => e.target.value !== String(Number(b.value)) && act({ action: "benefit", benefitId: b.id, value: e.target.value }, "تم التحديث")} />}
            </div>
          ))}
        </Card>
      ))}
      <Card>
        <div className="font-black mb-2">حملات الشحن</div>
        <div className="grid gap-2 sm:grid-cols-5">
          <input className={`${inputCls} sm:col-span-2`} placeholder="العنوان" value={c.titleAr} onChange={(e) => setC({ ...c, titleAr: e.target.value })} />
          <input className={inputCls} type="number" placeholder="الحد الأدنى" value={c.minRecharge} onChange={(e) => setC({ ...c, minRecharge: e.target.value })} />
          <input className={inputCls} type="number" placeholder="المكافأة" value={c.bonusAmount} onChange={(e) => setC({ ...c, bonusAmount: e.target.value })} />
          <Btn onClick={() => act({ action: "campaign", ...c }, "تم إنشاء الحملة")}>إنشاء</Btn>
        </div>
        <label className="flex items-center gap-2 text-sm mt-2"><input type="checkbox" checked={c.vipOnly} onChange={(e) => setC({ ...c, vipOnly: e.target.checked })} /> لأعضاء VIP فقط</label>
        <div className="mt-3 space-y-2">
          {data.campaigns.map((x) => (
            <div key={x.id} className="flex justify-between items-center text-sm border-t pt-2">
              <span>{x.titleAr} ({lyd(x.minRecharge)} ← +{lyd(x.bonusAmount)}){x.vipOnly ? " • VIP" : ""}</span>
              <Btn variant="ghost" onClick={() => act({ action: "campaignToggle", campaignId: x.id, isActive: !x.isActive }, "تم التحديث")}>{x.isActive ? "إيقاف" : "تفعيل"}</Btn>
            </div>
          ))}
        </div>
      </Card>
      <Card>
        <div className="font-black mb-2">الأعضاء</div>
        {data.members.map((m) => (
          <div key={m.id} className="flex justify-between items-center text-sm border-t py-2">
            <span>{m.name} <span dir="ltr" className="text-slate-400">{m.phone}</span> • {m.status} حتى {new Date(m.endsAt).toLocaleDateString("ar-LY")}</span>
            {m.status === "ACTIVE" && <Btn variant="danger" onClick={() => act({ action: "revoke", membershipId: m.id }, "تم إلغاء العضوية")}>إلغاء</Btn>}
          </div>
        ))}
      </Card>
    </>
  );
}

function Audit() {
  const { data, loading } = useApi<Stats>("/api/admin/stats");
  if (loading || !data) return <Skeleton />;
  return (
    <>
      <h1 className="text-xl font-black">سجل العمليات (Audit Log)</h1>
      {data.auditLogs.length === 0 ? <Empty title="لا توجد سجلات" /> : data.auditLogs.map((l) => (
        <Card key={l.id}>
          <div className="flex justify-between gap-2 text-sm"><b>{l.action}</b><span className={`text-xs font-bold ${l.result === "SUCCESS" ? "text-emerald-600" : "text-red-600"}`}>{l.result}</span></div>
          <div className="text-xs text-slate-500 mt-1">{l.userName || "نظام"} • {l.entity} {l.entityId} • {new Date(l.createdAt).toLocaleString("ar-LY")}</div>
          <div className="text-[11px] text-slate-400 truncate" dir="ltr">{l.ipAddress} • {l.userAgent}</div>
        </Card>
      ))}
    </>
  );
}

function Admins({ toast }: { toast: Toast }) {
  const { data, loading, error, reload } = useApi<{ id: number; fullName: string; phone: string; role: string; isActive: boolean }[]>("/api/super/admins");
  const [f, setF] = useState({ fullName: "", phone: "", role: "PLATFORM_ADMIN" });
  const act = async (body: unknown, method = "POST") => { try { await postJson("/api/super/admins", body, method); toast("تم"); reload(); } catch (e) { toast((e as Error).message, false); } };
  return (
    <>
      <h1 className="text-xl font-black">إدارة المدراء</h1>
      <Card>
        <div className="grid gap-2 sm:grid-cols-4">
          <input className={inputCls} placeholder="الاسم" value={f.fullName} onChange={(e) => setF({ ...f, fullName: e.target.value })} />
          <input className={inputCls} dir="ltr" placeholder="+2189..." value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} />
          <select className={inputCls} value={f.role} onChange={(e) => setF({ ...f, role: e.target.value })}><option value="PLATFORM_ADMIN">Admin</option><option value="SUPPORT_AGENT">دعم فني</option></select>
          <Btn onClick={() => act(f)}>إنشاء</Btn>
        </div>
      </Card>
      {loading ? <Skeleton /> : error ? <ErrorBox message={error} onRetry={reload} /> : data!.map((a) => (
        <Card key={a.id}>
          <div className="flex justify-between items-center gap-2">
            <div><b className="text-sm">{a.fullName}</b><div className="text-xs text-slate-500">{ROLE_LABEL[a.role]} • <span dir="ltr">{a.phone}</span>{a.isActive ? "" : " • موقوف"}</div></div>
            {a.role !== "SUPER_ADMIN" && (
              <div className="flex gap-2">
                <Btn variant="ghost" onClick={() => act({ userId: a.id, isActive: !a.isActive }, "PATCH")}>{a.isActive ? "إيقاف" : "تفعيل"}</Btn>
                <Btn variant="danger" onClick={() => confirm("سحب صلاحيات الإدارة؟") && act({ userId: a.id, role: "CUSTOMER" }, "PATCH")}>سحب الصلاحية</Btn>
              </div>
            )}
          </div>
        </Card>
      ))}
    </>
  );
}

const NEED_AR: Record<string, string> = { CONSULT: "كشف استشاري", DENTAL: "أسنان", LAB: "تحاليل", CHECKUP: "فحص شامل", SURGERY: "جراحة يوم واحد", DERMA: "جلدية وتجميل", OTHER: "أخرى" };
const WHO_AR: Record<string, string> = { SELF: "لنفسه", FAMILY: "العائلة", CHILD: "طفل", PARENT: "أحد الوالدين" };
const CARE_ST: Record<string, string> = { NEW: "جديد", CONTACTED: "تم التواصل", BOOKED: "تم الحجز", CLOSED: "مغلق" };

function Care({ toast }: { toast: Toast }) {
  const { data, loading, error, reload } = useApi<{ id: number; requestRef: string; fullName: string; phone: string; needType: string; forWhom: string; age: number | null; city: string; budget: string | null; preferredDate: string | null; notes: string | null; status: string; createdAt: string }[]>("/api/care-requests");
  const set = async (id: number, status: string) => { try { await postJson("/api/care-requests", { id, status }, "PATCH"); toast("تم التحديث"); reload(); } catch (e) { toast((e as Error).message, false); } };
  return (
    <>
      <h1 className="text-xl font-black">طلبات الاستشارة الصحية</h1>
      {loading ? <Skeleton /> : error ? <ErrorBox message={error} onRetry={reload} /> : !data?.length ? <Empty title="لا توجد طلبات" /> : data.map((r) => (
        <Card key={r.id}>
          <div className="flex justify-between gap-2">
            <div><b className="text-sm">{r.fullName}</b> <a href={`tel:${r.phone}`} dir="ltr" className="text-xs text-blue-700">{r.phone}</a></div>
            <span className="text-xs px-2 py-0.5 rounded bg-slate-100 h-fit">{CARE_ST[r.status]}</span>
          </div>
          <div className="text-sm text-slate-600 mt-1">{NEED_AR[r.needType]} • {WHO_AR[r.forWhom]}{r.age ? ` • ${r.age} سنة` : ""} • {r.city}{r.budget ? ` • ميزانية ${r.budget}` : ""}{r.preferredDate ? ` • ${r.preferredDate}` : ""}</div>
          {r.notes && <p className="text-xs text-slate-500 mt-1">{r.notes}</p>}
          <div className="text-[11px] text-slate-400 mt-1">{r.requestRef} • {new Date(r.createdAt).toLocaleString("ar-LY")}</div>
          <div className="flex gap-2 mt-3 flex-wrap">
            {["CONTACTED", "BOOKED", "CLOSED"].filter((x) => x !== r.status).map((x) => <Btn key={x} variant="ghost" onClick={() => set(r.id, x)}>{CARE_ST[x]}</Btn>)}
          </div>
        </Card>
      ))}
    </>
  );
}
