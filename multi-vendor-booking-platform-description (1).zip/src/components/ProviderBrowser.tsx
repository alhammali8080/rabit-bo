"use client";

import { useEffect, useMemo, useState } from "react";
import { Search, Star, MapPin, BadgeCheck } from "lucide-react";
import BookingSheet, { type Org, type Srv, type Branch } from "./BookingSheet";
import { Empty, Skeleton, inputCls, lyd } from "./ui";

export interface Cat { id: number; slug: string; nameAr: string; icon: string }
export interface MarketData { categories: Cat[]; organizations: Org[]; services: Srv[]; branches: Branch[] }

let cache: Promise<MarketData> | null = null;
export function loadMarket() {
  if (!cache) cache = fetch("/api/data").then((r) => r.json()).catch(() => { cache = null; return { categories: [], organizations: [], services: [], branches: [] }; });
  return cache;
}

export default function ProviderBrowser({ loggedIn, categorySlug, limit, showSearch = true, excludeSlugs = [] }: {
  loggedIn: boolean; categorySlug?: string; limit?: number; showSearch?: boolean; excludeSlugs?: string[];
}) {
  const [data, setData] = useState<MarketData | null>(null);
  const [q, setQ] = useState("");
  const [debounced, setDebounced] = useState("");
  const [city, setCity] = useState("all");
  const [sel, setSel] = useState<{ org: Org; srv: Srv } | null>(null);

  useEffect(() => { loadMarket().then(setData); }, []);
  useEffect(() => { const t = setTimeout(() => setDebounced(q.trim()), 250); return () => clearTimeout(t); }, [q]);

  const catId = data?.categories.find((c) => c.slug === categorySlug)?.id;
  const scoped = useMemo(() => (data?.organizations || []).filter((o) => (!categorySlug || o.categoryId === catId) && !excludeSlugs.includes(o.slug)), [data, categorySlug, catId, excludeSlugs]);
  const cities = useMemo(() => [...new Set(scoped.map((o) => o.city))], [scoped]);
  const list = useMemo(() => {
    const r = scoped.filter((o) => {
      const srvText = (data?.services || []).filter((s) => s.organizationId === o.id).map((s) => s.nameAr).join(" ");
      return (city === "all" || o.city === city) && (!debounced || `${o.nameAr} ${o.subtitleAr} ${srvText}`.includes(debounced));
    }).filter((o) => (data?.services || []).some((s) => s.organizationId === o.id));
    return limit ? [...r].sort((a, b) => parseFloat(b.rating) - parseFloat(a.rating)).slice(0, limit) : r;
  }, [scoped, data, city, debounced, limit]);

  if (!data) return <Skeleton rows={3} />;

  return (
    <div className="space-y-4">
      {showSearch && (
        <div className="grid gap-2 sm:grid-cols-[1fr_200px]">
          <div className="relative">
            <Search className="w-5 h-5 text-slate-400 absolute top-3 right-3" />
            <input className={`${inputCls} pr-10 h-12`} placeholder="ابحث باسم المنشأة أو الخدمة..." value={q} onChange={(e) => setQ(e.target.value)} />
          </div>
          <select className={`${inputCls} h-12`} value={city} onChange={(e) => setCity(e.target.value)}>
            <option value="all">كل المدن</option>
            {cities.map((c) => <option key={c}>{c}</option>)}
          </select>
        </div>
      )}
      {list.length === 0 ? <Empty title="لا توجد نتائج" hint="جرّب كلمة بحث أخرى أو مدينة مختلفة" /> : (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((o) => {
            const srvs = data.services.filter((s) => s.organizationId === o.id);
            const from = Math.min(...srvs.map((s) => parseFloat(s.price)));
            return (
              <article key={o.id} className="group bg-white rounded-2xl border border-slate-200 overflow-hidden hover:shadow-xl hover:-translate-y-0.5 transition">
                <div className="relative h-44 bg-slate-100">
                  {o.coverUrl && <img src={o.coverUrl} alt="" loading="lazy" className="w-full h-full object-cover" />}
                  <span className="absolute top-3 right-3 bg-white/95 rounded-full px-2.5 py-1 text-xs font-bold flex items-center gap-1"><Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />{Number(o.rating).toFixed(1)} <span className="text-slate-400">({o.reviewsCount})</span></span>
                  <span className="absolute bottom-3 left-3 bg-slate-900/85 text-white rounded-lg px-2.5 py-1 text-xs font-bold">ابتداءً من {lyd(from)}</span>
                </div>
                <div className="p-4 space-y-2">
                  <h3 className="font-black text-slate-900 flex items-center gap-1">{o.nameAr}<BadgeCheck className="w-4 h-4 text-blue-600" aria-label="موثقة" /></h3>
                  <p className="text-sm text-slate-500 line-clamp-1">{o.subtitleAr}</p>
                  <p className="text-xs text-slate-500 flex items-center gap-1"><MapPin className="w-3.5 h-3.5" />{o.city}</p>
                  <div className="space-y-1.5 pt-2">
                    {srvs.slice(0, 3).map((s) => (
                      <button key={s.id} onClick={() => setSel({ org: o, srv: s })} className="w-full min-h-[44px] flex items-center justify-between gap-2 px-3 py-2 rounded-xl bg-slate-50 hover:bg-blue-50 border border-transparent hover:border-blue-200 text-right">
                        <span className="text-sm font-bold line-clamp-1">{s.nameAr}</span>
                        <span className="text-sm font-black text-blue-700 shrink-0">{lyd(s.price)}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}
      {sel && <BookingSheet org={sel.org} service={sel.srv} branches={data.branches} loggedIn={loggedIn} onClose={() => setSel(null)} />}
    </div>
  );
}
