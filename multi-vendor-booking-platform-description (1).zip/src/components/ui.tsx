"use client";

import { useEffect, useState, useCallback, type ReactNode } from "react";
import { apiFetch } from "@/lib/clientAuth";

export function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 ${className}`}>{children}</div>;
}

export function Skeleton({ rows = 3 }: { rows?: number }) {
  return (
    <div className="space-y-3 animate-pulse" aria-busy="true">
      {Array.from({ length: rows }).map((_, i) => <div key={i} className="h-16 bg-slate-200 rounded-2xl" />)}
    </div>
  );
}

export function Empty({ title, hint }: { title: string; hint?: string }) {
  return (
    <div className="text-center py-10 border-2 border-dashed border-slate-200 rounded-2xl">
      <p className="font-bold text-slate-600">{title}</p>
      {hint && <p className="text-xs text-slate-400 mt-1">{hint}</p>}
    </div>
  );
}

export function ErrorBox({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="p-4 bg-red-50 border border-red-200 text-red-700 rounded-2xl text-sm flex items-center justify-between gap-3">
      <span>{message}</span>
      {onRetry && <button onClick={onRetry} className="px-3 py-1.5 bg-white border border-red-200 rounded-lg font-bold text-xs">إعادة المحاولة</button>}
    </div>
  );
}

export function Btn({ children, className = "", variant = "primary", ...p }: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "ghost" | "danger" | "accent" }) {
  const v = {
    primary: "bg-blue-700 hover:bg-blue-800 text-white",
    accent: "bg-amber-500 hover:bg-amber-600 text-white",
    ghost: "bg-slate-100 hover:bg-slate-200 text-slate-800",
    danger: "bg-red-50 hover:bg-red-100 text-red-700",
  }[variant];
  return <button {...p} className={`min-h-[44px] px-4 rounded-xl font-bold text-sm transition disabled:opacity-50 ${v} ${className}`}>{children}</button>;
}

export const inputCls = "w-full min-h-[44px] px-3 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-600 bg-white";

/** Fetch helper with loading/error state + friendly messages. */
export function useApi<T>(url: string | null) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(!!url);
  const load = useCallback(async () => {
    if (!url) return;
    setLoading(true);
    setError(null);
    try {
      const res = await apiFetch(url, { cache: "no-store" });
      const j = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(j.error || "تعذر تحميل البيانات");
      setData(j);
    } catch (e) {
      setError(e instanceof Error ? e.message : "تعذر تحميل البيانات");
    } finally {
      setLoading(false);
    }
  }, [url]);
  useEffect(() => { load(); }, [load]);
  return { data, error, loading, reload: load, setData };
}

export async function postJson(url: string, body: unknown, method = "POST") {
  const res = await apiFetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  const j = await res.json().catch(() => ({}));
  if (!res.ok) throw Object.assign(new Error(j.error || "حدث خطأ غير متوقع، يرجى المحاولة مرة أخرى."), { data: j, status: res.status });
  return j;
}

/** Minimal toast */
export function useToast() {
  const [t, setT] = useState<{ msg: string; ok: boolean } | null>(null);
  const show = (msg: string, ok = true) => { setT({ msg, ok }); setTimeout(() => setT(null), 3500); };
  const node = t ? (
    <div role="status" className={`fixed bottom-24 lg:bottom-6 left-1/2 -translate-x-1/2 z-50 px-4 py-3 rounded-xl shadow-lg text-sm font-bold text-white ${t.ok ? "bg-emerald-600" : "bg-red-600"}`}>{t.msg}</div>
  ) : null;
  return { show, node };
}

export const lyd = (v: string | number | null | undefined) => `${Number(v || 0).toFixed(2)} د.ل`;

export const STATUS_AR: Record<string, string> = {
  PENDING: "قيد الانتظار", CONFIRMED: "مؤكد", CANCELLED: "ملغي", COMPLETED: "مكتمل", NO_SHOW: "لم يحضر", REJECTED: "مرفوض", RESCHEDULED: "معاد جدولته",
};
export const TX_AR: Record<string, string> = {
  CREDIT: "إضافة رصيد", DEBIT: "خصم", REFUND: "استرداد", BONUS: "مكافأة", VIP_BONUS: "مكافأة VIP", ADJUSTMENT: "تعديل إداري", CARD_RECHARGE: "شحن كرت",
};
