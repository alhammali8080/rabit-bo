"use client";

import Link from "next/link";
import { usePathname, useSearchParams } from "next/navigation";
import { Suspense, useEffect, useState } from "react";
import {
  Home, Search, CalendarDays, Wallet, User, Crown, Bell, Users, Plus, MoreHorizontal, LayoutDashboard,
  CreditCard, Shield, FileText, Building2, BarChart3, LogOut, Scissors, KeyRound, Repeat, Menu, X, Globe, Bus, Ticket,
} from "lucide-react";
import type { ReactNode } from "react";
import { logout } from "@/lib/clientAuth";

const ICONS = { Home, Search, CalendarDays, Wallet, User, Crown, Bell, Users, Plus, MoreHorizontal, LayoutDashboard, CreditCard, Shield, FileText, Building2, BarChart3, Scissors, KeyRound, Bus, Ticket };
export type IconName = keyof typeof ICONS;
export interface NavItem { href: string; label: string; icon: IconName; primary?: boolean }

function NavLinks({ nav, onNavigate }: { nav: NavItem[]; onNavigate?: () => void }) {
  const path = usePathname();
  const tab = useSearchParams().get("tab");
  const isActive = (href: string) => {
    const [p, q] = href.split("?");
    const hrefTab = q ? new URLSearchParams(q).get("tab") : null;
    if (p !== path) return false;
    return hrefTab === tab || (!hrefTab && !tab);
  };
  return (
    <>
      {nav.map((n) => {
        const I = ICONS[n.icon];
        return (
          <Link key={n.href} href={n.href} onClick={onNavigate}
            className={`flex items-center gap-3 px-3 h-11 rounded-xl text-sm font-bold transition ${isActive(n.href) ? "bg-blue-50 text-blue-700" : "text-slate-600 hover:bg-slate-100"}`}>
            <I className="w-5 h-5" /> {n.label}
          </Link>
        );
      })}
    </>
  );
}

export default function RoleShell({
  brand, subtitle, nav, children, accent = "blue",
}: {
  brand: string; subtitle: string; nav: NavItem[]; bottom?: NavItem[]; children: ReactNode; accent?: "blue" | "purple" | "slate" | "amber";
}) {
  const path = usePathname();
  const [open, setOpen] = useState(false);
  useEffect(() => setOpen(false), [path]);
  const accentBg = { blue: "bg-blue-800", purple: "bg-purple-800", slate: "bg-slate-800", amber: "bg-amber-600" }[accent];


  const Footer = () => (
    <div className="p-3 border-t border-slate-200 space-y-1">
      <Link href="/" className="flex items-center gap-3 px-3 h-11 rounded-xl text-sm font-bold text-slate-600 hover:bg-slate-100"><Globe className="w-5 h-5" /> الموقع الرئيسي</Link>
      <button onClick={logout} className="w-full flex items-center gap-3 px-3 h-11 rounded-xl text-sm font-bold text-blue-700 hover:bg-blue-50"><Repeat className="w-5 h-5" /> تبديل الدور / الحساب</button>
      <button onClick={logout} className="w-full flex items-center gap-3 px-3 h-11 rounded-xl text-sm font-bold text-red-600 hover:bg-red-50"><LogOut className="w-5 h-5" /> تسجيل الخروج</button>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-50 lg:flex">
      <aside className="hidden lg:flex lg:w-64 flex-col bg-white border-l border-slate-200 sticky top-0 h-screen">
        <div className={`${accentBg} text-white px-5 py-5`}>
          <div className="text-lg font-black">{brand}</div>
          <div className="text-xs opacity-80 truncate">{subtitle}</div>
        </div>
        <nav className="flex-1 overflow-y-auto p-3 space-y-1"><Suspense><NavLinks nav={nav} /></Suspense></nav>
        <Footer />
      </aside>

      <div className="flex-1 min-w-0">
        <header className={`lg:hidden ${accentBg} text-white px-3 h-14 flex items-center gap-2 sticky top-0 z-30`}>
          <button onClick={() => setOpen(true)} aria-label="القائمة" className="p-2 rounded-lg hover:bg-white/10"><Menu className="w-6 h-6" /></button>
          <div className="font-black flex-1 truncate">{brand}</div>
          <Link href="/notifications" aria-label="الإشعارات" className="p-2 rounded-lg hover:bg-white/10"><Bell className="w-5 h-5" /></Link>
        </header>
        <main className="p-4 sm:p-6 lg:p-8 max-w-6xl mx-auto">{children}</main>
      </div>

      {open && (
        <div className="lg:hidden fixed inset-0 z-50" role="dialog" aria-modal="true">
          <div className="absolute inset-0 bg-slate-900/50" onClick={() => setOpen(false)} />
          <div className="absolute top-0 right-0 bottom-0 w-[82%] max-w-xs bg-white shadow-xl flex flex-col">
            <div className={`${accentBg} text-white px-4 h-16 flex items-center justify-between`}>
              <div><div className="font-black">{brand}</div><div className="text-xs opacity-80 truncate">{subtitle}</div></div>
              <button onClick={() => setOpen(false)} aria-label="إغلاق" className="p-2 rounded-lg hover:bg-white/10"><X className="w-5 h-5" /></button>
            </div>
            <nav className="flex-1 overflow-y-auto p-3 space-y-1"><Suspense><NavLinks nav={nav} onNavigate={() => setOpen(false)} /></Suspense></nav>
            <Footer />
          </div>
        </div>
      )}
    </div>
  );
}
