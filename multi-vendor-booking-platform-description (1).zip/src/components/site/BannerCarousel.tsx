"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";

interface Banner { id: number; titleAr: string; subtitleAr: string; badgeAr: string | null; imageUrl: string; ctaLabel: string; href: string; isSponsored: boolean }

export default function BannerCarousel() {
  const [items, setItems] = useState<Banner[] | null>(null);
  const [i, setI] = useState(0);
  const [paused, setPaused] = useState(false);
  useEffect(() => { fetch("/api/banners").then((r) => r.json()).then((d) => setItems(Array.isArray(d) ? d : [])).catch(() => setItems([])); }, []);
  useEffect(() => {
    if (!items?.length || paused) return;
    const t = setInterval(() => setI((x) => (x + 1) % items.length), 6000);
    return () => clearInterval(t);
  }, [items, paused]);

  if (!items) return <div className="h-[340px] sm:h-[420px] rounded-3xl bg-slate-200 animate-pulse" />;
  if (!items.length) return null;
  const go = (d: number) => setI((x) => (x + d + items.length) % items.length);

  return (
    <div className="relative h-[340px] sm:h-[420px] rounded-3xl overflow-hidden bg-slate-900 shadow-xl" onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)} aria-roledescription="carousel">
      {items.map((b, k) => (
        <div key={b.id} className={`absolute inset-0 transition-opacity duration-700 ${k === i ? "opacity-100" : "opacity-0 pointer-events-none"}`} aria-hidden={k !== i}>
          <img src={b.imageUrl} alt="" className="absolute inset-0 w-full h-full object-cover" loading={k === 0 ? "eager" : "lazy"} />
          <div className="absolute inset-0 bg-gradient-to-l from-slate-950/90 via-slate-950/60 to-slate-950/10" />
          <div className="relative h-full flex flex-col justify-end sm:justify-center p-6 sm:p-12 max-w-2xl text-white">
            <div className="flex items-center gap-2 mb-3">
              {b.badgeAr && <span className="text-xs font-bold bg-amber-500 text-slate-950 rounded-full px-3 py-1">{b.badgeAr}</span>}
              {b.isSponsored && <span className="text-[10px] font-bold bg-white/20 rounded px-2 py-0.5">إعلان</span>}
            </div>
            <h2 className="text-2xl sm:text-4xl font-black leading-tight">{b.titleAr}</h2>
            <p className="mt-2 text-sm sm:text-lg text-slate-200">{b.subtitleAr}</p>
            <Link href={b.href} className="mt-5 inline-flex w-fit items-center gap-2 h-12 px-6 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black">{b.ctaLabel} <ChevronLeft className="w-5 h-5" /></Link>
          </div>
        </div>
      ))}
      <button onClick={() => go(1)} aria-label="السابق" className="hidden sm:flex absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/20 hover:bg-white/30 text-white items-center justify-center"><ChevronRight /></button>
      <button onClick={() => go(-1)} aria-label="التالي" className="hidden sm:flex absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/20 hover:bg-white/30 text-white items-center justify-center"><ChevronLeft /></button>
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
        {items.map((b, k) => <button key={b.id} onClick={() => setI(k)} aria-label={`شريحة ${k + 1}`} className={`h-2 rounded-full transition-all ${k === i ? "w-8 bg-amber-400" : "w-2 bg-white/50"}`} />)}
      </div>
    </div>
  );
}
