import Link from "next/link";

export default function SiteFooter() {
  return (
    <footer className="bg-slate-950 text-slate-400 mt-16">
      <div className="max-w-7xl mx-auto px-4 py-10 grid gap-8 sm:grid-cols-2 lg:grid-cols-4 text-sm">
        <div>
          <div className="flex items-center gap-2 text-white font-black text-lg"><span className="w-9 h-9 rounded-xl bg-blue-700 flex items-center justify-center">ر</span>رابط للحجوزات</div>
          <p className="mt-3 leading-relaxed">منصة ليبية واحدة لحجز كل شيء: الفنادق، الملاعب، الحافلات، تذاكر المباريات، العيادات والمزيد.</p>
        </div>
        <div><div className="text-white font-bold mb-3">اكتشف</div><ul className="space-y-2">
          <li><Link href="/categories" className="hover:text-white">كل التصنيفات</Link></li>
          <li><Link href="/bus" className="hover:text-white">رحلات الحافلات</Link></li>
          <li><Link href="/events" className="hover:text-white">المباريات والفعاليات</Link></li>
          <li><Link href="/health" className="hover:text-white">رابط الصحي</Link></li></ul></div>
        <div><div className="text-white font-bold mb-3">للأعمال</div><ul className="space-y-2">
          <li><Link href="/login/provider" className="hover:text-white">دخول مزودي الخدمة</Link></li>
          <li><Link href="/login/staff" className="hover:text-white">دخول الموظفين</Link></li>
          <li><Link href="/#join" className="hover:text-white">انضم كمزود خدمة</Link></li></ul></div>
        <div><div className="text-white font-bold mb-3">تواصل معنا</div><ul className="space-y-2">
          <li dir="ltr" className="text-right">support@rabit.ly</li><li>طرابلس – ليبيا</li></ul></div>
      </div>
      <div className="border-t border-slate-800 py-4 text-center text-xs">© {new Date().getFullYear()} رابط للحجوزات – Rabit Bookings</div>
    </footer>
  );
}
