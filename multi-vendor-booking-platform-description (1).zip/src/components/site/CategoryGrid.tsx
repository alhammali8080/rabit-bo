"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { loadMarket, type MarketData } from "../ProviderBrowser";

export default function CategoryGrid() {
  const [data, setData] = useState<MarketData | null>(null);
  useEffect(() => { loadMarket().then(setData); }, []);
  if (!data) return <div className="grid grid-cols-3 sm:grid-cols-5 gap-3">{Array.from({ length: 15 }).map((_, i) => <div key={i} className="h-28 rounded-2xl bg-slate-200 animate-pulse" />)}</div>;
  return (
    <div className="grid grid-cols-3 sm:grid-cols-5 gap-3">
      {data.categories.map((c) => {
        const n = data.organizations.filter((o) => o.categoryId === c.id).length;
        return (
          <Link key={c.id} href={c.slug === "tickets" ? "/events" : `/category/${c.slug}`}
            className="group bg-white rounded-2xl border border-slate-200 p-3 sm:p-4 flex flex-col items-center justify-center text-center gap-2 min-h-[112px] hover:border-blue-400 hover:shadow-lg transition">
            <span className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-blue-50 group-hover:bg-blue-100 flex items-center justify-center text-2xl sm:text-3xl" aria-hidden>{c.icon}</span>
            <span className="text-[12px] sm:text-sm font-bold text-slate-800 leading-tight">{c.nameAr}</span>
            <span className="text-[10px] text-slate-400">{n} {n === 1 ? "منشأة" : "منشآت"}</span>
          </Link>
        );
      })}
    </div>
  );
}
