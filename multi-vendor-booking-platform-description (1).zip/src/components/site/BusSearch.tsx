"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeftRight, Search } from "lucide-react";

const today = () => new Date().toISOString().slice(0, 10);

export default function BusSearch({ initial, compact = false }: { initial?: { from?: string; to?: string; date?: string }; compact?: boolean }) {
  const router = useRouter();
  const [cities, setCities] = useState<string[]>(["طرابلس", "بنغازي", "مصراتة", "سبها", "طبرق", "الزاوية"]);
  const [from, setFrom] = useState(initial?.from || "طرابلس");
  const [to, setTo] = useState(initial?.to || "بنغازي");
  const [date, setDate] = useState(initial?.date || today());
  useEffect(() => { fetch("/api/bus/search").then((r) => r.json()).then((d) => d.cities?.length && setCities([...new Set([...d.cities, "طبرق", "سبها", "الزاوية"])])).catch(() => {}); }, []);
  const sel = "w-full h-12 px-3 rounded-xl border border-slate-300 bg-white text-sm font-bold focus:outline-none focus:ring-2 focus:ring-blue-600";
  return (
    <form onSubmit={(e) => { e.preventDefault(); router.push(`/bus?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}&date=${date}`); }}
      className={`grid gap-2 ${compact ? "sm:grid-cols-[1fr_auto_1fr_1fr_auto]" : "sm:grid-cols-[1fr_auto_1fr_1fr_auto]"} items-end`}>
      <label className="text-xs font-bold text-slate-500">من<select className={sel} value={from} onChange={(e) => setFrom(e.target.value)}>{cities.map((c) => <option key={c}>{c}</option>)}</select></label>
      <button type="button" onClick={() => { setFrom(to); setTo(from); }} aria-label="تبديل الاتجاه" className="h-12 w-12 mx-auto rounded-xl border border-slate-300 bg-white flex items-center justify-center"><ArrowLeftRight className="w-5 h-5 text-slate-500" /></button>
      <label className="text-xs font-bold text-slate-500">إلى<select className={sel} value={to} onChange={(e) => setTo(e.target.value)}>{cities.filter((c) => c !== from).map((c) => <option key={c}>{c}</option>)}</select></label>
      <label className="text-xs font-bold text-slate-500">التاريخ<input type="date" className={sel} min={today()} value={date} onChange={(e) => setDate(e.target.value)} /></label>
      <button className="h-12 px-6 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-black flex items-center justify-center gap-2"><Search className="w-5 h-5" /> ابحث</button>
    </form>
  );
}
