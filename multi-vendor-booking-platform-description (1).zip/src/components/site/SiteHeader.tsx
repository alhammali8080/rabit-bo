"use client";
import { apiFetch } from "@/lib/clientAuth";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { Menu, X, User, Wallet, LayoutGrid, Bus, Ticket, HeartPulse, Home } from "lucide-react";

export interface Me { user: { fullName: string; role: string; home: string } | null; vip?: unknown }

export function useMe() {
  const [me, setMe] = useState<Me | null>(null);
  useEffect(() => { apiFetch("/api/me", { cache: "no-store" }).then((r) => r.json()).then(setMe).catch(() => setMe({ user: null })); }, []);
  return me;
}

const LINKS = [
  { href: "/", label: "الرئيسية", icon: Home },
  { href: "/categories", label: "التصنيفات", icon: LayoutGrid },
  { href: "/bus", label: "الحافلات", icon: Bus },
  { href: "/events", label: "المباريات والفعاليات", icon: Ticket },
  { href: "/health", label: "رابط الصحي", icon: HeartPulse },
];

export default function SiteHeader() {
  const me = useMe();
  const path = usePathname();
  const [open, setOpen] = useState(false);
  useEffect(() => setOpen(false), [path]);
  const user = me?.user;
  const active = (h: string) => (h === "/" ? path === "/" : path.startsWith(h));

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center gap-4">
        <button className="lg:hidden p-2 -mr-2 rounded-lg hover:bg-slate-100" aria-label="القائمة" onClick={() => setOpen(true)}><Menu className="w-6 h-6" /></button>
        <Link href="/" className="flex items-center gap-2 shrink-0">
          <span className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-800 to-blue-600 text-white flex items-center justify-center font-black text-lg">ر</span>
          <span className="font-black text-lg text-slate-900">رابط<span className="text-blue-700"> للحجوزات</span></span>
        </Link>
        <nav className="hidden lg:flex items-center gap-1 mr-6">
          {LINKS.map((l) => (
            <Link key={l.href} href={l.href} className={`px-3 py-2 rounded-lg text-sm font-bold ${active(l.href) ? "text-blue-700 bg-blue-50" : "text-slate-600 hover:text-slate-900"}`}>{l.label}</Link>
          ))}
        </nav>
        <div className="flex-1" />
        {user ? (
          <div className="flex items-center gap-2">
            {user.role === "CUSTOMER" && <Link href="/app/wallet" className="hidden sm:flex items-center gap-1 px-3 h-10 rounded-lg text-sm font-bold text-slate-700 hover:bg-slate-100"><Wallet className="w-4 h-4" /> المحفظة</Link>}
            <Link href={user.home} className="flex items-center gap-2 px-3 h-10 rounded-lg bg-blue-700 text-white text-sm font-bold"><User className="w-4 h-4" /><span className="max-w-[110px] truncate">{user.role === "CUSTOMER" ? user.fullName.split(" ")[0] : "لوحتي"}</span></Link>
          </div>
        ) : me ? (
          <Link href="/login" className="px-4 h-10 rounded-lg bg-blue-700 text-white text-sm font-bold flex items-center">تسجيل الدخول</Link>
        ) : <span className="w-24 h-10 rounded-lg bg-slate-100 animate-pulse" />}
      </div>

      {open && (
        <div className="lg:hidden fixed inset-0 z-50" role="dialog" aria-modal="true">
          <div className="absolute inset-0 bg-slate-900/50" onClick={() => setOpen(false)} />
          <div className="absolute top-0 right-0 bottom-0 w-[82%] max-w-xs bg-white shadow-xl flex flex-col">
            <div className="h-16 px-4 flex items-center justify-between border-b">
              <span className="font-black">القائمة</span>
              <button onClick={() => setOpen(false)} aria-label="إغلاق" className="p-2 rounded-lg hover:bg-slate-100"><X className="w-5 h-5" /></button>
            </div>
            <nav className="p-3 space-y-1 flex-1 overflow-y-auto">
              {LINKS.map((l) => (
                <Link key={l.href} href={l.href} className={`flex items-center gap-3 px-3 h-12 rounded-xl font-bold ${active(l.href) ? "bg-blue-50 text-blue-700" : "text-slate-700"}`}><l.icon className="w-5 h-5" />{l.label}</Link>
              ))}
            </nav>
            <div className="p-3 border-t">
              <Link href={user ? user.home : "/login"} className="flex items-center justify-center h-12 rounded-xl bg-blue-700 text-white font-bold">{user ? "حسابي / لوحتي" : "تسجيل الدخول"}</Link>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
