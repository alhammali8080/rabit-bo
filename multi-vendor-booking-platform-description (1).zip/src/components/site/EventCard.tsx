import Link from "next/link";
import { CalendarDays, MapPin } from "lucide-react";

export interface EventRow { id: number; slug: string; titleAr: string; subtitleAr: string | null; kind: string; venueAr: string; city: string; eventDate: string; eventTime: string; imageUrl: string; homeTeam: string | null; awayTeam: string | null; minPrice: string | null; left: number | null }

export const fmtDate = (d: string) => new Date(`${d}T12:00:00`).toLocaleDateString("ar-LY", { weekday: "long", day: "numeric", month: "long" });

export default function EventCard({ e }: { e: EventRow }) {
  return (
    <Link href={`/events/${e.slug}`} className="group block bg-white rounded-2xl border border-slate-200 overflow-hidden hover:shadow-xl transition">
      <div className="relative h-40">
        <img src={e.imageUrl} alt="" loading="lazy" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 to-transparent" />
        <span className="absolute top-3 right-3 text-[11px] font-bold bg-amber-500 text-slate-950 rounded-full px-2.5 py-1">{e.kind === "MATCH" ? "⚽ مباراة" : "🎤 حفل"}</span>
        {e.homeTeam && <div className="absolute bottom-3 inset-x-3 text-white font-black text-center">{e.homeTeam} <span className="text-amber-400">×</span> {e.awayTeam}</div>}
      </div>
      <div className="p-4 space-y-1.5">
        <h3 className="font-black line-clamp-1">{e.titleAr}</h3>
        <p className="text-xs text-slate-500 flex items-center gap-1"><CalendarDays className="w-3.5 h-3.5" />{fmtDate(e.eventDate)} • {e.eventTime}</p>
        <p className="text-xs text-slate-500 flex items-center gap-1"><MapPin className="w-3.5 h-3.5" />{e.venueAr}</p>
        <div className="flex items-center justify-between pt-2">
          <span className="text-sm">ابتداءً من <b className="text-blue-700">{Number(e.minPrice || 0).toFixed(0)} د.ل</b></span>
          <span className="text-xs font-bold text-white bg-blue-700 group-hover:bg-blue-800 rounded-lg px-3 py-1.5">احجز تذكرة</span>
        </div>
      </div>
    </Link>
  );
}
