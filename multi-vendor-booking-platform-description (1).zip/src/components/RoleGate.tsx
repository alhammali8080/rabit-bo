"use client";

import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { useRouter } from "next/navigation";
import { portalForRole, type PortalKey } from "@/lib/portals";
import { me, type SessionInfo } from "@/lib/clientAuth";

export interface SessionUser { userId: number; role: string; fullName: string; phone: string; organizationId?: number | null; permissions: string[]; home: string }

const Ctx = createContext<SessionUser | null>(null);
export const useSessionUser = () => useContext(Ctx);

/**
 * Client-side page guard (the API re-checks every permission server-side).
 * Never redirects to another page to log in: when there is no session it renders the
 * `login` element IN PLACE, and the dashboard replaces it after a successful login.
 */
export default function RoleGate({
  roles, portal, children, login,
}: {
  roles: string[]; portal: PortalKey; children: (u: SessionUser) => ReactNode; login?: (portalKey: PortalKey) => ReactNode;
}) {
  const router = useRouter();
  const [user, setUser] = useState<SessionUser | null>(null);
  const [failed, setFailed] = useState(false);
  const [tries, setTries] = useState(0);

  useEffect(() => {
    let alive = true;
    setFailed(false);
    let n = 0;
    const attempt = () => {
      if (!alive) return;
      me()
        .then((d: SessionInfo | null) => {
          if (!alive) return;
          const u: SessionUser | null = (d?.user as SessionUser) ?? null;
          if (u) {
            if (!roles.includes(u.role)) {
              // Wrong area for this role → send them to their own area (soft navigation).
              return router.replace(u.home || `/login/${portalForRole(u.role)}`);
            }
            return setUser(u);
          }
          if (n++ < 3) return setTimeout(attempt, 400);
          setFailed(true);
        })
        .catch(() => {
          if (!alive) return;
          if (n++ < 3) return setTimeout(attempt, 400);
          setFailed(true);
        });
    };
    attempt();
    return () => { alive = false; };
  }, [roles, portal, router, tries]);

  // No session on this device → the login UI renders right here, on the same URL.
  if (!user) {
    if (failed && login) return <>{login(portal)}</>;
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
        <div className="text-center">
          <div className="w-10 h-10 border-4 border-blue-700 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-sm text-slate-500 mt-3">جاري التحقق من الدخول...</p>
        </div>
      </div>
    );
  }
  return <Ctx.Provider value={user}>{children(user)}</Ctx.Provider>;
}
