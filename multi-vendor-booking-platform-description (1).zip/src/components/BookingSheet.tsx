"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { X, CheckCircle2, Wallet, Banknote } from "lucide-react";
import { apiFetch } from "@/lib/clientAuth";
import { Btn, inputCls, lyd, postJson } from "./ui";

export interface Org { id: number; nameAr: string; city: string; primaryAddress: string; cancellationPolicyAr: string; currency: string; categoryId: number; subtitleAr: string; descriptionAr: string; rating: string; reviewsCount: number; coverUrl?: string | null; slug: string }
export interface Srv { id: number; organizationId: number; nameAr: string; descriptionAr: string; durationMinutes: number; price: string }
export interface Branch { id: number; organizationId: number; nameAr: string; district: string }

const SLOTS = ["09:00", "10:00", "11:00", "12:00", "14:00", "15:00", "16:00", "17:00", "18:00", "19:00", "20:00"];
const tomorrow = () => new Date(Date.now() + 86400000).toISOString().slice(0, 10);

export default function BookingSheet({ org, service, branches, loggedIn, onClose, onBooked }: {
  org: Org; service: Srv; branches: Branch[]; loggedIn: boolean; onClose: () => void; onBooked?: () => void;
}) {
  const orgBranches = useMemo(() => branches.filter((b) => b.organizationId === org.id), [branches, org.id]);
  const [branchId, setBranchId] = useState(orgBranches[0]?.id);
  const [date, setDate] = useState(tomorrow());
  const [time, setTime] = useState("10:00");
  const [method, setMethod] = useState<"WALLET" | "CASH">("WALLET");
  const [balance, setBalance] = useState<number | null>(null);
  const [vipFee, setVipFee] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [done, setDone] = useState<{ bookingRef: string } | null>(null);

  useEffect(() => {
    if (!loggedIn) return;
    apiFetch("/api/wallet?limit=1").then((r) => r.json()).then((j) => setBalance(j.wallet ? parseFloat(j.wallet.balance) : null)).catch(() => {});
    apiFetch("/api/vip").then((r) => r.json()).then((j) => {
      const b = j.active?.benefits?.find((x: { key: string }) => x.key === "FEE_DISCOUNT_PERCENT");
      if (b) setVipFee(Math.max(0, Math.round(2 * (100 - parseFloat(b.value))) / 100));
    }).catch(() => {});
  }, [loggedIn]);

  const price = parseFloat(service.price);
  const fee = vipFee ?? 2;
  const total = price + fee;
  const after = balance != null ? balance - total : null;
  const insufficient = method === "WALLET" && after != null && after < 0;

  async function submit() {
    setLoading(true);
    setError("");
    try {
      const r = await postJson("/api/bookings", { organizationId: org.id, serviceId: service.id, branchId, bookingDate: date, startTime: time, paymentMethod: method });
      setDone(r);
      onBooked?.();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 flex items-end sm:items-center justify-center" role="dialog" aria-modal="true">
      <div className="bg-white w-full sm:max-w-md rounded-t-3xl sm:rounded-3xl max-h-[92vh] overflow-y-auto">
        <div className="flex items-center justify-between p-4 border-b sticky top-0 bg-white">
          <div>
            <div className="font-black">{service.nameAr}</div>
            <div className="text-xs text-slate-500">{org.nameAr}</div>
          </div>
          <button onClick={onClose} aria-label="إغلاق" className="p-2 rounded-xl hover:bg-slate-100"><X className="w-5 h-5" /></button>
        </div>

        {!loggedIn ? (
          <div className="p-6 text-center space-y-4">
            <p className="text-sm text-slate-600">سجّل الدخول برقم هاتفك لإتمام الحجز والدفع من المحفظة.</p>
            <Link href="/login" className="block"><Btn className="w-full">تسجيل الدخول</Btn></Link>
          </div>
        ) : done ? (
          <div className="p-6 text-center space-y-3">
            <CheckCircle2 className="w-14 h-14 text-emerald-600 mx-auto" />
            <div className="font-black text-lg">تم تأكيد حجزك</div>
            <div className="font-mono text-blue-700 font-bold">{done.bookingRef}</div>
            <div className="text-sm text-slate-600">{date} الساعة {time}</div>
            <Link href="/app/bookings"><Btn className="w-full mt-2">عرض حجوزاتي</Btn></Link>
          </div>
        ) : (
          <div className="p-4 space-y-4">
            {orgBranches.length > 1 && (
              <select className={inputCls} value={branchId} onChange={(e) => setBranchId(Number(e.target.value))}>
                {orgBranches.map((b) => <option key={b.id} value={b.id}>{b.nameAr} – {b.district}</option>)}
              </select>
            )}
            <input type="date" className={inputCls} min={tomorrow()} value={date} onChange={(e) => setDate(e.target.value)} />
            <div className="grid grid-cols-4 gap-2">
              {SLOTS.map((s) => (
                <button key={s} onClick={() => setTime(s)} className={`min-h-[44px] rounded-xl text-sm font-bold border ${time === s ? "bg-blue-700 text-white border-blue-700" : "bg-white border-slate-200"}`}>{s}</button>
              ))}
            </div>

            <div>
              <div className="text-sm font-bold mb-2">اختر طريقة الدفع</div>
              <div className="grid grid-cols-2 gap-2">
                <button onClick={() => setMethod("WALLET")} className={`p-3 rounded-xl border text-right ${method === "WALLET" ? "border-blue-700 bg-blue-50" : "border-slate-200"}`}>
                  <Wallet className="w-5 h-5 text-blue-700 mb-1" /><div className="text-sm font-bold">المحفظة</div>
                  <div className="text-xs text-slate-500">{balance != null ? lyd(balance) : "..."}</div>
                </button>
                <button onClick={() => setMethod("CASH")} className={`p-3 rounded-xl border text-right ${method === "CASH" ? "border-blue-700 bg-blue-50" : "border-slate-200"}`}>
                  <Banknote className="w-5 h-5 text-emerald-700 mb-1" /><div className="text-sm font-bold">الدفع في المكان</div>
                  <div className="text-xs text-slate-500">عند الحضور</div>
                </button>
              </div>
              {/* TODO(payments): add online card gateway (e.g. Moamalat / Sadad) via the payment abstraction layer */}
            </div>

            <div className="bg-slate-50 rounded-xl p-3 text-sm space-y-1">
              <div className="flex justify-between"><span>قيمة الخدمة</span><b>{lyd(price)}</b></div>
              <div className="flex justify-between"><span>رسوم الحجز {vipFee != null && <span className="text-amber-600 font-bold">(خصم VIP)</span>}</span><b>{lyd(fee)}</b></div>
              <div className="flex justify-between border-t pt-1"><span>الإجمالي</span><b className="text-blue-700">{lyd(total)}</b></div>
              {method === "WALLET" && balance != null && (
                <>
                  <div className="flex justify-between text-slate-500"><span>الرصيد الحالي</span><span>{lyd(balance)}</span></div>
                  <div className={`flex justify-between ${insufficient ? "text-red-600" : "text-emerald-700"}`}><span>الرصيد بعد العملية</span><b>{lyd(after)}</b></div>
                </>
              )}
            </div>
            <p className="text-xs text-slate-500">{org.cancellationPolicyAr}</p>
            {error && <div className="p-3 rounded-xl bg-red-50 text-red-700 text-sm">{error}</div>}
            {insufficient ? (
              <Link href="/app/wallet"><Btn variant="accent" className="w-full">الرصيد غير كافٍ – اشحن المحفظة</Btn></Link>
            ) : (
              <Btn variant="accent" className="w-full" disabled={loading} onClick={submit}>{loading ? "جاري التأكيد..." : method === "WALLET" ? "تأكيد الدفع والحجز" : "تأكيد الحجز"}</Btn>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
