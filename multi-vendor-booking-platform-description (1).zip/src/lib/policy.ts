// Pure business rules (unit-testable, no I/O).

/** Refund policy: >=24h full, >=6h 50%, else none. Provider-initiated cancellation = full refund. */
export function refundPercent(hoursBefore: number, byProvider: boolean) {
  if (byProvider) return 100;
  if (hoursBefore >= 24) return 100;
  if (hoursBefore >= 6) return 50;
  return 0;
}

export function customerFee(base: number, vipDiscountPercent: number) {
  return Math.max(0, Math.round(base * (100 - vipDiscountPercent)) / 100);
}
