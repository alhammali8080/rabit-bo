// Separate login portal per role (safe for client & server).
export type PortalKey = "customer" | "provider" | "staff" | "admin" | "super";

export const PORTALS: Record<PortalKey, {
  title: string; subtitle: string; emoji: string; roles: string[]; color: string; demo: { label: string; phone: string }[]; canRegister?: boolean;
}> = {
  customer: { title: "دخول العملاء", subtitle: "احجز وادفع وتابع حجوزاتك", emoji: "🙋", roles: ["CUSTOMER"], color: "from-blue-700 to-blue-500", canRegister: true,
    demo: [{ label: "عميل VIP – عبد الرحمن", phone: "0914441122" }, { label: "عميلة – فاطمة", phone: "0923337788" }] },
  provider: { title: "دخول مزودي الخدمة", subtitle: "أصحاب المنشآت والأنشطة", emoji: "🏪", roles: ["PROVIDER_OWNER"], color: "from-emerald-700 to-emerald-500",
    demo: [{ label: "مصحة قرطبة", phone: "0925551122" }, { label: "قصر الأندلس", phone: "0917773344" }, { label: "منتجع رمال زوارة", phone: "0949995566" }] },
  staff: { title: "دخول الموظفين", subtitle: "حسب الصلاحيات التي يحددها صاحب المنشأة", emoji: "🧑‍💼", roles: ["STAFF", "PROVIDER_MANAGER"], color: "from-slate-700 to-slate-500",
    demo: [{ label: "أحمد – استقبال", phone: "0920000002" }, { label: "سارة – مالية", phone: "0920000003" }] },
  admin: { title: "دخول إدارة المنصة", subtitle: "Admin والدعم الفني", emoji: "🛡️", roles: ["PLATFORM_ADMIN", "SUPPORT_AGENT"], color: "from-purple-700 to-purple-500",
    demo: [{ label: "مدير المنصة", phone: "0911002030" }] },
  super: { title: "دخول الإدارة العليا", subtitle: "Super Admin – العمليات الحساسة", emoji: "👑", roles: ["SUPER_ADMIN"], color: "from-amber-600 to-amber-400",
    demo: [{ label: "الإدارة العليا", phone: "0910000001" }] },
};

export const PORTAL_KEYS = Object.keys(PORTALS) as PortalKey[];

export function portalForRole(role: string): PortalKey {
  return (PORTAL_KEYS.find((k) => PORTALS[k].roles.includes(role)) ?? "customer");
}
