/** Normalizes Libyan phone input: 0914441122 / 914441122 / 218914441122 / +218 91 444 1122 → +218914441122 */
export function normalizePhone(input: string): string {
  let p = String(input || "").replace(/[^\d+]/g, "");
  if (p.startsWith("00")) p = "+" + p.slice(2);
  if (p.startsWith("+")) return p;
  if (p.startsWith("218")) return "+" + p;
  if (p.startsWith("0") && p.length === 10) return "+218" + p.slice(1);
  if (p.length === 9 && p.startsWith("9")) return "+218" + p;
  return p.length >= 9 ? "+" + p : p;
}
export const isValidPhone = (p: string) => /^\+[0-9]{9,15}$/.test(p);
