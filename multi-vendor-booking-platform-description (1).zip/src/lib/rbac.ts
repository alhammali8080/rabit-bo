// Roles + Permissions. Safe to import from client & server (no secrets).

export const P = {
  // Provider / tenant scope
  BOOKINGS_VIEW: "bookings.view",
  BOOKINGS_CREATE: "bookings.create",
  BOOKINGS_EDIT: "bookings.edit",
  BOOKINGS_CANCEL: "bookings.cancel",
  BOOKINGS_CHECKIN: "bookings.checkin",
  CUSTOMERS_VIEW: "customers.view",
  SERVICES_MANAGE: "services.manage",
  STAFF_MANAGE: "staff.manage",
  BRANCHES_MANAGE: "branches.manage",
  FINANCE_VIEW: "finance.view",
  FINANCE_WITHDRAW: "finance.withdraw",
  SUBSCRIPTION_MANAGE: "subscription.manage",
  SETTINGS_MANAGE: "settings.manage",
  REPORTS_VIEW: "reports.view",
  // Platform admin scope
  ADMIN_ACCESS: "admin.access",
  USERS_MANAGE: "users.manage",
  PROVIDERS_MANAGE: "providers.manage",
  CARDS_VIEW: "cards.view",
  CARDS_CREATE: "cards.create",
  VIP_MANAGE: "vip.manage",
  WALLETS_ADJUST: "wallets.adjust",
  AUDIT_VIEW: "audit.view",
  // Super admin only
  SUPER_ACCESS: "super.access",
  ADMINS_MANAGE: "admins.manage",
  CARDS_CREATE_LARGE: "cards.create_large",
  COMMISSIONS_GLOBAL: "commissions.global",
  SETTINGS_SYSTEM: "settings.system",
} as const;

export type Permission = (typeof P)[keyof typeof P];

// Permissions a provider owner may delegate to staff (shown as checkboxes)
export const DELEGABLE_PERMISSIONS: { key: Permission; label: string }[] = [
  { key: P.BOOKINGS_VIEW, label: "مشاهدة الحجوزات" },
  { key: P.BOOKINGS_CREATE, label: "إنشاء حجز" },
  { key: P.BOOKINGS_EDIT, label: "تعديل حجز" },
  { key: P.BOOKINGS_CANCEL, label: "إلغاء حجز" },
  { key: P.BOOKINGS_CHECKIN, label: "تسجيل الحضور وإكمال الخدمة" },
  { key: P.CUSTOMERS_VIEW, label: "مشاهدة العملاء" },
  { key: P.SERVICES_MANAGE, label: "إدارة الخدمات" },
  { key: P.FINANCE_VIEW, label: "رؤية الإيرادات والتقارير المالية" },
  { key: P.REPORTS_VIEW, label: "التقارير" },
  { key: P.STAFF_MANAGE, label: "إدارة الموظفين" },
  { key: P.SETTINGS_MANAGE, label: "إعدادات المنشأة" },
];

export const STAFF_PRESETS: Record<string, Permission[]> = {
  "استقبال": [P.BOOKINGS_VIEW, P.BOOKINGS_CREATE, P.BOOKINGS_EDIT, P.BOOKINGS_CHECKIN, P.CUSTOMERS_VIEW],
  "مالي": [P.FINANCE_VIEW, P.REPORTS_VIEW, P.BOOKINGS_VIEW],
  "مختص": [P.BOOKINGS_VIEW, P.BOOKINGS_CHECKIN],
};

const PROVIDER_ALL: Permission[] = [
  P.BOOKINGS_VIEW, P.BOOKINGS_CREATE, P.BOOKINGS_EDIT, P.BOOKINGS_CANCEL, P.BOOKINGS_CHECKIN,
  P.CUSTOMERS_VIEW, P.SERVICES_MANAGE, P.STAFF_MANAGE, P.BRANCHES_MANAGE, P.FINANCE_VIEW,
  P.FINANCE_WITHDRAW, P.SUBSCRIPTION_MANAGE, P.SETTINGS_MANAGE, P.REPORTS_VIEW,
];

const ADMIN_ALL: Permission[] = [
  P.ADMIN_ACCESS, P.USERS_MANAGE, P.PROVIDERS_MANAGE, P.CARDS_VIEW, P.CARDS_CREATE,
  P.VIP_MANAGE, P.WALLETS_ADJUST, P.AUDIT_VIEW,
];

export function permissionsForRole(role: string, staffPerms: string[] = []): Permission[] {
  switch (role) {
    case "PROVIDER_OWNER":
      return PROVIDER_ALL;
    case "PROVIDER_MANAGER":
    case "STAFF":
      return staffPerms.filter((p) => (PROVIDER_ALL as string[]).includes(p)) as Permission[];
    case "PLATFORM_ADMIN":
      return ADMIN_ALL;
    case "SUPPORT_AGENT":
      return [P.ADMIN_ACCESS, P.USERS_MANAGE];
    case "SUPER_ADMIN":
      return [...ADMIN_ALL, P.SUPER_ACCESS, P.ADMINS_MANAGE, P.CARDS_CREATE_LARGE, P.COMMISSIONS_GLOBAL, P.SETTINGS_SYSTEM];
    default:
      return [];
  }
}

export function homeForRole(role: string): string {
  switch (role) {
    case "PROVIDER_OWNER":
      return "/provider";
    case "PROVIDER_MANAGER":
    case "STAFF":
      return "/staff";
    case "PLATFORM_ADMIN":
    case "SUPPORT_AGENT":
      return "/admin";
    case "SUPER_ADMIN":
      return "/super-admin";
    default:
      return "/app";
  }
}

export const ROLE_LABEL: Record<string, string> = {
  CUSTOMER: "عميل",
  PROVIDER_OWNER: "مزود خدمة",
  PROVIDER_MANAGER: "مدير منشأة",
  STAFF: "موظف",
  PLATFORM_ADMIN: "مدير المنصة",
  SUPPORT_AGENT: "دعم فني",
  SUPER_ADMIN: "الإدارة العليا",
};
