"use client";

import React, { useState } from "react";
import { Copy, Check, Sparkles, Building2, UserCheck, ShieldCheck, Zap } from "lucide-react";
import { platformPitchData } from "./pitchData";

export default function PitchDeckModal({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  const fullDeckText = `
منصة "رابط للحجوزات" - الملف التعريفي والخطط التسويقية المتكاملة

الاسم الرسمي: ${platformPitchData.name}
الشعار اللفظي: ${platformPitchData.tagline}

1. المصعد التعريفي (Elevator Pitch):
${platformPitchData.elevatorPitch}

2. الرؤية والرسالة:
- الرؤية: ${platformPitchData.vision.text}
- الرسالة: ${platformPitchData.mission.text}

3. رسالة تسويقية لمزودي الخدمات:
${platformPitchData.vendorPitch.content}
المزايا الرئيسية:
${platformPitchData.vendorPitch.highlights.map((h) => `- ${h.title}: ${h.desc}`).join("\n")}

4. رسالة تسويقية للمستخدم النهائي (العميل):
${platformPitchData.consumerPitch.content}
المزايا الرئيسية:
${platformPitchData.consumerPitch.highlights.map((h) => `- ${h.title}: ${h.desc}`).join("\n")}
  `.trim();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/75 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200">
        {/* Header */}
        <div className="sticky top-0 bg-white/95 backdrop-blur-md px-6 py-4 border-b border-slate-100 flex items-center justify-between z-10">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-blue-50 rounded-xl text-blue-600">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-slate-900">الملف التعريفي والتسويقي الشامل</h3>
              <p className="text-xs text-slate-500">جاهز للنسخ والعرض للمستثمرين والشركاء والعملاء</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => copyToClipboard(fullDeckText, "full")}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-blue-600 text-white hover:bg-blue-700 transition"
            >
              {copiedKey === "full" ? <Check className="w-4 h-4 text-emerald-300" /> : <Copy className="w-4 h-4" />}
              {copiedKey === "full" ? "تم نسخ الملف كاملاً!" : "نسخ الملف بالكامل"}
            </button>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 space-y-8">
          {/* Elevator pitch block */}
          <section className="bg-gradient-to-br from-blue-50/80 via-slate-50 to-indigo-50/40 p-5 rounded-2xl border border-blue-100/60 relative group">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-blue-700 uppercase tracking-wider flex items-center gap-1.5">
                <Zap className="w-4 h-4" /> نبذة تعريفية قصيرة (Elevator Pitch)
              </span>
              <button
                onClick={() => copyToClipboard(platformPitchData.elevatorPitch, "elevator")}
                className="text-xs text-slate-500 hover:text-blue-600 flex items-center gap-1 bg-white px-2.5 py-1 rounded-md shadow-xs border border-slate-200"
              >
                {copiedKey === "elevator" ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedKey === "elevator" ? "تم النسخ" : "نسخ"}
              </button>
            </div>
            <p className="text-slate-700 leading-relaxed text-sm md:text-base font-medium">
              "{platformPitchData.elevatorPitch}"
            </p>
          </section>

          {/* Vision & Mission */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <section className="p-5 rounded-xl border border-slate-200 bg-white shadow-xs">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-bold text-slate-800 text-sm flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-blue-600" /> {platformPitchData.vision.title}
                </h4>
                <button
                  onClick={() => copyToClipboard(platformPitchData.vision.text, "vision")}
                  className="text-xs text-slate-400 hover:text-blue-600"
                >
                  {copiedKey === "vision" ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
              <p className="text-xs md:text-sm text-slate-600 leading-relaxed">
                {platformPitchData.vision.text}
              </p>
            </section>

            <section className="p-5 rounded-xl border border-slate-200 bg-white shadow-xs">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-bold text-slate-800 text-sm flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-emerald-600" /> {platformPitchData.mission.title}
                </h4>
                <button
                  onClick={() => copyToClipboard(platformPitchData.mission.text, "mission")}
                  className="text-xs text-slate-400 hover:text-blue-600"
                >
                  {copiedKey === "mission" ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
              <p className="text-xs md:text-sm text-slate-600 leading-relaxed">
                {platformPitchData.mission.text}
              </p>
            </section>
          </div>

          {/* Vendors Pitch Section */}
          <section className="p-5 rounded-2xl border border-indigo-100 bg-indigo-50/30">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-indigo-600" />
                <h4 className="font-bold text-slate-900">{platformPitchData.vendorPitch.title}</h4>
              </div>
              <button
                onClick={() =>
                  copyToClipboard(
                    `${platformPitchData.vendorPitch.content}\n${platformPitchData.vendorPitch.highlights.map((h) => `${h.title}: ${h.desc}`).join("\n")}`,
                    "vendors"
                  )
                }
                className="text-xs text-indigo-600 bg-white px-2.5 py-1 rounded-md border border-indigo-200 shadow-xs flex items-center gap-1 font-medium"
              >
                {copiedKey === "vendors" ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                نسخ رسالة المزودين
              </button>
            </div>
            <p className="text-xs font-semibold text-indigo-700 mb-2">
              {platformPitchData.vendorPitch.subtitle}
            </p>
            <p className="text-sm text-slate-700 leading-relaxed mb-4">
              {platformPitchData.vendorPitch.content}
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {platformPitchData.vendorPitch.highlights.map((h, i) => (
                <div key={i} className="bg-white p-3 rounded-lg border border-slate-100 text-xs">
                  <span className="font-bold text-slate-900 block mb-0.5 text-sm">{h.title}</span>
                  <span className="text-slate-600">{h.desc}</span>
                </div>
              ))}
            </div>
          </section>

          {/* Consumers Pitch Section */}
          <section className="p-5 rounded-2xl border border-emerald-100 bg-emerald-50/30">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <UserCheck className="w-5 h-5 text-emerald-600" />
                <h4 className="font-bold text-slate-900">{platformPitchData.consumerPitch.title}</h4>
              </div>
              <button
                onClick={() =>
                  copyToClipboard(
                    `${platformPitchData.consumerPitch.content}\n${platformPitchData.consumerPitch.highlights.map((h) => `${h.title}: ${h.desc}`).join("\n")}`,
                    "consumers"
                  )
                }
                className="text-xs text-emerald-700 bg-white px-2.5 py-1 rounded-md border border-emerald-200 shadow-xs flex items-center gap-1 font-medium"
              >
                {copiedKey === "consumers" ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                نسخ رسالة العملاء
              </button>
            </div>
            <p className="text-xs font-semibold text-emerald-700 mb-2">
              {platformPitchData.consumerPitch.subtitle}
            </p>
            <p className="text-sm text-slate-700 leading-relaxed mb-4">
              {platformPitchData.consumerPitch.content}
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {platformPitchData.consumerPitch.highlights.map((h, i) => (
                <div key={i} className="bg-white p-3 rounded-lg border border-slate-100 text-xs">
                  <span className="font-bold text-slate-900 block mb-0.5 text-sm">{h.title}</span>
                  <span className="text-slate-600">{h.desc}</span>
                </div>
              ))}
            </div>
          </section>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <p className="text-xs text-slate-500">
            صُمم خصيصاً لمنصة <strong className="text-slate-800">رابط للحجوزات</strong> بنبرة صوت احترافية ورسمية ومقنعة.
          </p>
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-100 rounded-lg transition"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
}
