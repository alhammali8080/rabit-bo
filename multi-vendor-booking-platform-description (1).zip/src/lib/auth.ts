import { SignJWT, jwtVerify } from "jose";

const JWT_SECRET = new TextEncoder().encode(
  process.env.AUTH_SECRET || "rabit-bookings-production-super-secret-key-2025-libya"
);

export interface TokenPayload {
  userId: number;
  role: string;
  phone: string;
  fullName: string;
  organizationId?: number | null;
}

export async function signToken(payload: TokenPayload): Promise<string> {
  return new SignJWT({ ...payload })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("30d")
    .sign(JWT_SECRET);
}

export async function verifyToken(token: string): Promise<TokenPayload | null> {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET);
    return payload as unknown as TokenPayload;
  } catch (e) {
    return null;
  }
}

/** Short-lived (2 min) handoff token: lets a top-level tab set a first-party cookie when the iframe blocks cookies. */
export async function signHandoff(userId: number): Promise<string> {
  return new SignJWT({ userId, purpose: "handoff" }).setProtectedHeader({ alg: "HS256" }).setIssuedAt().setExpirationTime("2m").sign(JWT_SECRET);
}
export async function verifyHandoff(token: string): Promise<number | null> {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET);
    return payload.purpose === "handoff" ? Number(payload.userId) : null;
  } catch {
    return null;
  }
}
