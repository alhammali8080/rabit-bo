import type { NavItem } from "@/components/RoleShell";
import { P } from "@/lib/rbac";

/** Builds provider/staff navigation filtered by permissions (items the user can't use are never rendered). */
export function workspaceNav(base: "/provider" | "/staff", perms: string[]) {
  const can = (p: string) => perms.includes(p);
  const all: (NavItem & { p?: string })[] = [
    { href: base, label: "الرئيسية", icon: "Home" },
    { href: `${base}?tab=bookings`, label: "الحجوزات", icon: "CalendarDays", p: P.BOOKINGS_VIEW },
    { href: `${base}?tab=new`, label: "حجز", icon: "Plus", p: P.BOOKINGS_CREATE, primary: true },
    { href: `${base}?tab=customers`, label: "العملاء", icon: "Users", p: P.CUSTOMERS_VIEW },
    { href: `${base}?tab=services`, label: "الخدمات", icon: "Scissors", p: P.SERVICES_MANAGE },
    { href: `${base}?tab=staff`, label: "الموظفون", icon: "KeyRound", p: P.STAFF_MANAGE },
    { href: `${base}?tab=finance`, label: "الإيرادات", icon: "BarChart3", p: P.FINANCE_VIEW },
    { href: "/notifications", label: "الإشعارات", icon: "Bell" },
  ];
  const nav = all.filter((i) => !i.p || can(i.p)).map(({ p: _p, ...i }) => ({ ...i, primary: false }));
  const bottom = all.filter((i) => ["الرئيسية", "الحجوزات", "حجز", "العملاء"].includes(i.label) && (!i.p || can(i.p))).map(({ p: _p, ...i }) => i);
  bottom.push({ href: `${base}?tab=more`, label: "المزيد", icon: "MoreHorizontal" });
  return { nav, bottom };
}
