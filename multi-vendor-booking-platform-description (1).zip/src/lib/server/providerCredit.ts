import "server-only";
import { eq } from "drizzle-orm";
import { ledgerEntries, wallets } from "@/db/schema";
import type { Tx } from "./wallet";

/** Records provider share in the ledger (platform commission deducted) and adds it to pending settlement. */
export async function creditProvider(tx: Tx, orgId: number, gross: number, ref: string, description: string, commissionPct = 5) {
  const fee = Math.round(gross * commissionPct) / 100;
  const net = gross - fee;
  await tx.insert(ledgerEntries).values({
    organizationId: orgId, transactionType: "BOOKING_PAYMENT", grossAmount: gross.toFixed(2), platformFee: fee.toFixed(2),
    netAmount: net.toFixed(2), currency: "LYD", description, reference: ref,
  });
  const [w] = await tx.select().from(wallets).where(eq(wallets.organizationId, orgId)).for("update");
  if (w) {
    await tx.update(wallets).set({
      pendingSettlement: (parseFloat(w.pendingSettlement) + net).toFixed(2),
      totalEarned: (parseFloat(w.totalEarned) + gross).toFixed(2),
      totalCommissionPaid: (parseFloat(w.totalCommissionPaid) + fee).toFixed(2),
      updatedAt: new Date(),
    }).where(eq(wallets.id, w.id));
  }
}
