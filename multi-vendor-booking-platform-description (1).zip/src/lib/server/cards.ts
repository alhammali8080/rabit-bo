import "server-only";
import { createHmac, randomInt } from "crypto";

// No ambiguous chars (0/O, 1/I/L)
const ALPHABET = "23456789ABCDEFGHJKMNPQRSTUVWXYZ";

function secret() {
  return process.env.CARD_SECRET || process.env.AUTH_SECRET || "rabit-dev-card-secret-change-me";
}

export function generateCardCode(): string {
  const groups: string[] = [];
  for (let g = 0; g < 4; g++) {
    let s = "";
    for (let i = 0; i < 4; i++) s += ALPHABET[randomInt(ALPHABET.length)];
    groups.push(s);
  }
  return groups.join("-");
}

export function normalizeCode(input: string) {
  return input.toUpperCase().replace(/[^A-Z0-9]/g, "");
}

/** Keyed hash: DB leak alone does not reveal or allow brute-forcing codes. */
export function hashCardCode(code: string) {
  return createHmac("sha256", secret()).update(normalizeCode(code)).digest("hex");
}

export function hashOtp(phone: string, code: string) {
  return createHmac("sha256", secret()).update(`otp:${phone}:${code}`).digest("hex");
}
