import "server-only";
import { db } from "@/db";
import { auditLogs } from "@/db/schema";
import { requestMeta } from "./session";

export async function audit(entry: {
  userId?: number | null;
  action: string;
  entity: string;
  entityId?: string | number | null;
  oldValue?: unknown;
  newValue?: unknown;
  result?: "SUCCESS" | "FAILED" | "DENIED";
}) {
  try {
    const meta = await requestMeta();
    const str = (v: unknown) => (v === undefined || v === null ? null : typeof v === "string" ? v : JSON.stringify(v));
    await db.insert(auditLogs).values({
      userId: entry.userId ?? null,
      action: entry.action,
      entity: entry.entity,
      entityId: entry.entityId != null ? String(entry.entityId) : null,
      oldValue: str(entry.oldValue),
      newValue: str(entry.newValue),
      ipAddress: meta.ip,
      userAgent: meta.userAgent,
      result: entry.result ?? "SUCCESS",
    });
  } catch (e) {
    console.error("[audit] failed", e);
  }
}
