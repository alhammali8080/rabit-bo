import "server-only";
import { randomBytes } from "crypto";
import { and, eq, gt, sql } from "drizzle-orm";
import { db } from "@/db";
import { userWallets, walletTransactions, vipMemberships, vipBenefits } from "@/db/schema";
import { UserError } from "./session";

export type Tx = Parameters<Parameters<typeof db.transaction>[0]>[0];

export interface WalletTxInput {
  userId: number;
  type: string; // WalletTxType
  amount: number; // signed: + credit, - debit
  source: string;
  reference?: string | null;
  note?: string | null;
  actorId?: number | null;
}

const round = (n: number) => Math.round(n * 100) / 100;

/**
 * THE ONLY way to change a wallet balance. Must be called inside a transaction.
 * Locks the wallet row (SELECT ... FOR UPDATE), validates, updates, and writes the ledger row.
 */
export async function applyWalletTx(tx: Tx, input: WalletTxInput) {
  const amount = round(input.amount);
  if (!Number.isFinite(amount) || amount === 0) throw new UserError("قيمة العملية غير صالحة");

  await tx.insert(userWallets).values({ userId: input.userId }).onConflictDoNothing({ target: userWallets.userId });
  const [wallet] = await tx.select().from(userWallets).where(eq(userWallets.userId, input.userId)).for("update");
  if (wallet.isFrozen) throw new UserError("المحفظة موقوفة مؤقتاً، يرجى التواصل مع الدعم", 423);

  const before = parseFloat(wallet.balance);
  const after = round(before + amount);
  if (after < 0) throw new UserError("رصيد المحفظة غير كافٍ لإتمام العملية", 402);

  await tx.update(userWallets).set({ balance: after.toFixed(2), updatedAt: new Date() }).where(eq(userWallets.id, wallet.id));

  const [row] = await tx
    .insert(walletTransactions)
    .values({
      txRef: `WTX-${Date.now().toString(36).toUpperCase()}-${randomBytes(3).toString("hex").toUpperCase()}`,
      userId: input.userId,
      walletId: wallet.id,
      type: input.type,
      amount: amount.toFixed(2),
      balanceBefore: before.toFixed(2),
      balanceAfter: after.toFixed(2),
      source: input.source,
      reference: input.reference ?? null,
      note: input.note ?? null,
      actorId: input.actorId ?? null,
    })
    .returning();
  return row;
}

export async function getWallet(userId: number) {
  await db.insert(userWallets).values({ userId }).onConflictDoNothing({ target: userWallets.userId });
  const [w] = await db.select().from(userWallets).where(eq(userWallets.userId, userId));
  return w;
}

/** Active VIP membership + active benefits map for a user (or null). */
export async function getActiveVip(userId: number, tx: Tx | typeof db = db) {
  const [m] = await tx
    .select()
    .from(vipMemberships)
    .where(and(eq(vipMemberships.userId, userId), eq(vipMemberships.status, "ACTIVE"), gt(vipMemberships.endsAt, sql`now()`)))
    .limit(1);
  if (!m) return null;
  const benefits = await tx
    .select()
    .from(vipBenefits)
    .where(and(eq(vipBenefits.tierId, m.tierId), eq(vipBenefits.isActive, true)));
  const map: Record<string, number> = {};
  for (const b of benefits) map[b.key] = parseFloat(b.value);
  return { membership: m, benefits, map };
}
