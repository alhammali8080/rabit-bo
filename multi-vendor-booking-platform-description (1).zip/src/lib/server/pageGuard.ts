import "server-only";
import { redirect } from "next/navigation";
import { getSession, type Session } from "./session";
import { homeForRole } from "@/lib/rbac";

/** Server-side page guard: unauthenticated → /login, wrong role → that role's own home. */
export async function requirePageRole(roles: string[]): Promise<Session> {
  const s = await getSession();
  if (!s) redirect("/login");
  if (!roles.includes(s.role)) redirect(homeForRole(s.role));
  return s;
}
