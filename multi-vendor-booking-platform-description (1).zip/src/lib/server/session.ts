import "server-only";
import { cookies, headers } from "next/headers";
import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users, staff, organizations } from "@/db/schema";
import { signToken, verifyToken } from "@/lib/auth";
import { permissionsForRole, type Permission } from "@/lib/rbac";

export const SESSION_COOKIE = "rabit_session";

export interface Session {
  userId: number;
  role: string;
  fullName: string;
  phone: string;
  organizationId: number | null;
  staffId: number | null;
  permissions: Permission[];
}

/** Sets the session cookie (when the browser allows it) and returns the token for header-based auth. */
export async function createSessionCookie(user: { id: number; role: string; phone: string; fullName: string }): Promise<string> {
  const token = await signToken({ userId: user.id, role: user.role, phone: user.phone, fullName: user.fullName });
  const jar = await cookies();
  jar.set(SESSION_COOKIE, token, {
    httpOnly: true,
    // Standard first-party cookie: works normally on the real domain (Vercel / custom domain).
    // SameSite=Lax also protects against CSRF. On real hosting the browser accepts this
    // cookie like any normal website, so login "just works" without any workaround.
    // (Inside a preview iframe such cookies are blocked by the browser; the app falls
    // back to the session token in that case.)
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 24 * 14,
  });
  return token;
}

export async function clearSessionCookie() {
  (await cookies()).set(SESSION_COOKIE, "", {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 0,
  });
}

/** Always re-reads the user from DB so role/permission changes apply immediately. */
export async function getSession(): Promise<Session | null> {
  // 1) Authorization: Bearer  2) ?tk= query param  3) session cookie
  const h = await headers();
  const auth = h.get("authorization") || "";
  const bearer = auth.toLowerCase().startsWith("bearer ") ? auth.slice(7).trim() : "";
  const qp = h.get("x-rabit-token") || "";
  const cookieToken = (await cookies()).get(SESSION_COOKIE)?.value;
  const token = bearer || qp || cookieToken;
  if (!token) return null;
  const payload = await verifyToken(token);
  if (!payload?.userId) return null;

  const [user] = await db.select().from(users).where(eq(users.id, payload.userId));
  if (!user || !user.isActive) return null;

  let organizationId: number | null = null;
  let staffId: number | null = null;
  let staffPerms: string[] = [];

  if (user.role === "PROVIDER_OWNER") {
    const [org] = await db.select({ id: organizations.id }).from(organizations).where(eq(organizations.ownerId, user.id));
    organizationId = org?.id ?? null;
  } else if (user.role === "STAFF" || user.role === "PROVIDER_MANAGER") {
    const [st] = await db.select().from(staff).where(eq(staff.userId, user.id));
    if (st && st.isActive) {
      organizationId = st.organizationId;
      staffId = st.id;
      try {
        staffPerms = JSON.parse(st.permissionsJson || "[]");
      } catch {
        staffPerms = [];
      }
    }
  }

  return {
    userId: user.id,
    role: user.role,
    fullName: user.fullName,
    phone: user.phone,
    organizationId,
    staffId,
    permissions: permissionsForRole(user.role, staffPerms),
  };
}

export function hasPerm(s: Session, p: Permission) {
  return s.permissions.includes(p);
}

/**
 * API guard. Returns a Session, or a 401/403 NextResponse.
 * Usage: const g = await guard({ perm }); if (g instanceof NextResponse) return g;
 */
export async function guard(opts: { perm?: Permission; roles?: string[]; tenant?: boolean } = {}): Promise<Session | NextResponse> {
  const s = await getSession();
  if (!s) return NextResponse.json({ error: "يرجى تسجيل الدخول" }, { status: 401 });
  if (opts.roles && !opts.roles.includes(s.role)) return forbidden();
  if (opts.perm && !hasPerm(s, opts.perm)) return forbidden();
  if (opts.tenant && !s.organizationId) return forbidden();
  return s;
}

export function forbidden() {
  return NextResponse.json({ error: "403 Forbidden – لا تملك صلاحية لهذه العملية" }, { status: 403 });
}

export async function requestMeta() {
  const h = await headers();
  return {
    ip: (h.get("x-forwarded-for") || "").split(",")[0].trim() || h.get("x-real-ip") || "unknown",
    userAgent: (h.get("user-agent") || "").slice(0, 250),
  };
}

/** Converts any error into a safe user-facing message and logs internally. */
export function safeError(e: unknown, fallback = "حدث خطأ غير متوقع، يرجى المحاولة مرة أخرى.") {
  if (e instanceof UserError) return NextResponse.json({ error: e.message }, { status: e.status });
  console.error("[rabit]", e);
  return NextResponse.json({ error: fallback }, { status: 500 });
}

export class UserError extends Error {
  constructor(message: string, public status = 400) {
    super(message);
  }
}
