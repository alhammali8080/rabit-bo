"use client";

/**
 * Session for browsers that block cookies and storage (preview iframes, some in-app browsers).
 *
 * The token lives in a module-level variable, so it survives CLIENT-SIDE navigation
 * (Next.js soft navigation keeps the JS context alive). It is also mirrored to
 * localStorage / the URL fragment so a manual refresh can recover it.
 */

export const TOKEN_KEY = "rabit_token";
export const HASH = "#tk=";
export const QUERY = "tk";
let memory: string | null = null;
let installed = false;

function currentUrlToken(): string | null {
  if (typeof window === "undefined") return null;
  // ?tk=... (survives a full reload because it is part of the address)
  try {
    const q = new URLSearchParams(window.location.search).get(QUERY);
    if (looksLikeJwt(q)) return q as string;
  } catch {}
  // #tk=... (legacy)
  return fromHash();
}

function storages(): Storage[] {
  if (typeof window === "undefined") return [];
  const out: Storage[] = [];
  for (const get of [() => window.localStorage, () => window.sessionStorage]) {
    try {
      const s = get();
      s.setItem("__probe", "1");
      s.removeItem("__probe");
      out.push(s);
    } catch {
      /* blocked */
    }
  }
  return out;
}

const looksLikeJwt = (t: string | null | undefined) => !!t && t.split(".").length === 3;

function fromHash(): string | null {
  if (typeof window === "undefined") return null;
  const h = window.location.hash || "";
  if (!h.startsWith(HASH)) return null;
  try {
    const t = decodeURIComponent(h.slice(HASH.length));
    return looksLikeJwt(t) ? t : null;
  } catch {
    return null;
  }
}

export function getToken(): string | null {
  if (looksLikeJwt(memory)) return memory;
  // URL is the source of truth when storage is unavailable (it survives reloads there)
  const fromUrl = currentUrlToken();
  if (fromUrl) {
    memory = fromUrl;
    return fromUrl;
  }
  for (const s of storages()) {
    const v = s.getItem(TOKEN_KEY);
    if (looksLikeJwt(v)) {
      memory = v as string;
      return memory;
    }
  }
  return fromHash();
}

export function setToken(t?: string | null) {
  if (!looksLikeJwt(t)) return;
  memory = t as string;
  const stores = storages();
  for (const s of stores) {
    try {
      s.setItem(TOKEN_KEY, t as string);
    } catch {}
  }
  // When nothing can be stored, keep the token in the URL so a manual refresh still works.
  if (!stores.length && typeof window !== "undefined") {
    try {
      history.replaceState(null, "", window.location.pathname + window.location.search + HASH + encodeURIComponent(t as string));
    } catch {}
  }
}

export function clearToken() {
  memory = null;
  for (const s of storages()) {
    try {
      s.removeItem(TOKEN_KEY);
    } catch {}
  }
  if (typeof window !== "undefined" && window.location.hash.startsWith(HASH)) {
    try {
      history.replaceState(null, "", window.location.pathname + window.location.search);
    } catch {}
  }
}

export function storageBlocked(): boolean {
  return typeof window !== "undefined" && storages().length === 0;
}

export function authHeaders(extra?: HeadersInit): Headers {
  const h = new Headers(extra);
  const t = getToken();
  if (t && !h.has("Authorization")) h.set("Authorization", `Bearer ${t}`);
  return h;
}

export async function apiFetch(url: string, init: RequestInit = {}): Promise<Response> {
  return fetch(url, { ...init, headers: authHeaders(init.headers) });
}

export interface SessionInfo {
  user: null | { userId: number; role: string; fullName: string; phone: string; home: string; permissions: string[] };
  vip?: unknown;
}

export async function me(): Promise<SessionInfo | null> {
  try {
    const r = await apiFetch("/api/me", { cache: "no-store" });
    return await r.json();
  } catch {
    return null;
  }
}

export async function logout() {
  try {
    await apiFetch("/api/auth/logout", { method: "POST" });
  } catch {}
  clearToken();
  window.location.href = "/login";
}

/**
 * Runs once when the module loads.
 *  - picks the token up out of the address (?tk= / #tk=)
 *  - stores it whenever storage is available
 *  - when storage is BLOCKED (preview iframes), re-appends it to every internal
 *    navigation by wrapping history.pushState/replaceState, so it also survives reloads
 */
if (typeof window !== "undefined" && !installed) {
  installed = true;
  const t = currentUrlToken();
  if (t) {
    memory = t;
    const stores = storages();
    for (const s of stores) {
      try {
        s.setItem(TOKEN_KEY, t);
      } catch {}
    }
    if (stores.length) {
      // Storage works: remove the token from the address bar (it is no longer needed there).
      try {
        history.replaceState(null, "", window.location.pathname + window.location.search.replace(new RegExp(`[?&]${QUERY}=[^&]*`, ""), ""));
      } catch {}
    }
  }

  // Keep the token in the address across navigations when nothing can be stored.
  const keep = (url: string | URL | null | undefined) => {
    const tok = memory;
    if (!tok || storageBlocked() || url == null) return url;
    try {
      const u = new URL(String(url), window.location.origin);
      if (u.origin === window.location.origin && u.pathname !== "/login" && !u.searchParams.has(QUERY)) {
        u.searchParams.set(QUERY, tok);
        return u.pathname + u.search + (u.hash || "");
      }
    } catch {}
    return url;
  };

  for (const method of ["pushState", "replaceState"] as const) {
    const orig = history[method].bind(history);
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (history as any)[method] = function (state: unknown, title: string, url?: string | URL | null, ...rest: unknown[]) {
      return (orig as (s: unknown, t: string, u?: string | URL | null) => void)(state, title, keep(url));
    };
  }
}
