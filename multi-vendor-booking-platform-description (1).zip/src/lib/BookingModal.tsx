"use client";

import React, { useState } from "react";
import { X, Calendar, Clock, CheckCircle2, User, Phone, Mail, ShieldCheck, AlertCircle, CreditCard, Banknote } from "lucide-react";
import confetti from "canvas-confetti";

interface Service {
  id: number;
  organizationId: number;
  nameAr: string;
  descriptionAr: string;
  durationMinutes: number;
  price: string;
  depositAmount: string;
  currency: string;
}

interface Organization {
  id: number;
  nameAr: string;
  city: string;
  primaryAddress: string;
  cancellationPolicyAr: string;
  currency: string;
}

interface Branch {
  id: number;
  organizationId: number;
  nameAr: string;
  district: string;
}

interface StaffMember {
  id: number;
  organizationId: number;
  fullName: string;
  titleAr: string;
}

interface Props {
  organization: Organization;
  service: Service | null;
  branches: Branch[];
  staff: StaffMember[];
  isOpen: boolean;
  onClose: () => void;
  onSuccessBooking?: () => void;
  initialCustomer?: any;
}

export default function BookingModal({
  organization,
  service,
  branches,
  staff,
  isOpen,
  onClose,
  onSuccessBooking,
  initialCustomer,
}: Props) {
  const [step, setStep] = useState<1 | 2>(1);
  const [selectedBranchId, setSelectedBranchId] = useState<number>(branches[0]?.id || 1);
  const [selectedStaffId, setSelectedStaffId] = useState<string>("any");
  const [selectedDate, setSelectedDate] = useState("2025-05-20");
  const [selectedTime, setSelectedTime] = useState("16:00");
  const [paymentMethod, setPaymentMethod] = useState<"ONLINE" | "CASH">("ONLINE");

  const [customerName, setCustomerName] = useState(initialCustomer?.fullName || "");
  const [customerPhone, setCustomerPhone] = useState(initialCustomer?.phone || "");
  const [customerEmail, setCustomerEmail] = useState(initialCustomer?.email || "");
  const [notes, setNotes] = useState("");

  const [loading, setLoading] = useState(false);
  const [bookingRef, setBookingRef] = useState<string | null>(null);
  const [confirmedBookingData, setConfirmedBookingData] = useState<any>(null);
  const [error, setError] = useState("");

  if (!isOpen || !service) return null;

  const timeSlots = [
    "09:00",
    "10:00",
    "11:00",
    "12:00",
    "14:00",
    "15:00",
    "16:00",
    "17:00",
    "18:00",
    "19:30",
    "20:30",
  ];

  const orgBranches = branches.filter((b) => b.organizationId === organization.id);
  const orgStaff = staff.filter((s) => s.organizationId === organization.id);

  const priceNum = parseFloat(service.price);
  const serviceFee = 2.0;
  const grandTotal = priceNum + serviceFee;

  const handleConfirmBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const res = await fetch("/api/bookings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          organizationId: organization.id,
          branchId: selectedBranchId,
          serviceId: service.id,
          staffId: selectedStaffId !== "any" ? Number(selectedStaffId) : null,
          customerId: initialCustomer?.id || null,
          customerName,
          customerPhone,
          customerEmail,
          bookingDate: selectedDate,
          startTime: selectedTime,
          notes,
          paymentMethod,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "تعذر إتمام الحجز، حاول لاحقاً");
      }

      setBookingRef(data.bookingRef);
      setConfirmedBookingData(data);
      setStep(2);

      try {
        confetti({
          particleCount: 90,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch (e) {
        // ignore
      }

      if (onSuccessBooking) onSuccessBooking();
    } catch (err: any) {
      setError(err.message || "حدث خطأ أثناء معالجة الحجز");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm overflow-y-auto text-right">
      <div className="bg-white rounded-2xl max-w-xl w-full overflow-hidden shadow-2xl border border-slate-200">
        {/* Header */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between">
          <div>
            <div className="text-xs text-blue-400 font-bold mb-0.5">منظومة الحجز الفوري السحابية – رابط</div>
            <h3 className="text-lg font-bold">{organization.nameAr}</h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-slate-800 text-slate-300 hover:text-white flex items-center justify-center transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {step === 1 ? (
          <form onSubmit={handleConfirmBooking} className="p-6 space-y-4 max-h-[85vh] overflow-y-auto">
            {/* Service & Price Summary */}
            <div className="bg-blue-50/80 border border-blue-100 p-4 rounded-xl flex items-center justify-between">
              <div>
                <h4 className="font-bold text-slate-900 text-sm">{service.nameAr}</h4>
                <p className="text-xs text-slate-600 mt-1 line-clamp-1">{service.descriptionAr}</p>
                <span className="text-[11px] text-blue-700 font-bold mt-1 inline-block">
                  المدة: {service.durationMinutes} دقيقة | بدون تضارب
                </span>
              </div>
              <div className="text-left shrink-0">
                <span className="text-xl font-black text-blue-800">{service.price}</span>
                <span className="text-xs font-semibold text-slate-600 mr-1">{organization.currency || "LYD"}</span>
              </div>
            </div>

            {error && (
              <div className="flex items-center gap-2 text-xs bg-red-50 text-red-700 p-3.5 rounded-xl border border-red-200 font-medium">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
                <span>{error}</span>
              </div>
            )}

            {/* Branch & Staff Selection */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">اختر الفرع *</label>
                <select
                  value={selectedBranchId}
                  onChange={(e) => setSelectedBranchId(Number(e.target.value))}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs bg-white focus:ring-2 focus:ring-blue-600 focus:outline-none"
                >
                  {orgBranches.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.nameAr} ({b.district})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">اختر المختص / الموظف</label>
                <select
                  value={selectedStaffId}
                  onChange={(e) => setSelectedStaffId(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs bg-white focus:ring-2 focus:ring-blue-600 focus:outline-none"
                >
                  <option value="any">أي موظف متاح (تلقائي)</option>
                  {orgStaff.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.fullName} - {s.titleAr}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Date & Time */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-blue-600" /> تاريخ الموعد *
                </label>
                <input
                  type="date"
                  required
                  value={selectedDate}
                  min={new Date().toISOString().split("T")[0]}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-blue-600" /> التوقيت المتاح (Slot) *
                </label>
                <select
                  value={selectedTime}
                  onChange={(e) => setSelectedTime(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs bg-white focus:ring-2 focus:ring-blue-600 focus:outline-none"
                >
                  {timeSlots.map((slot, i) => (
                    <option key={i} value={slot}>
                      الساعة {slot}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Customer Contact Details */}
            <div className="pt-2 border-t border-slate-100">
              <label className="block text-xs font-bold text-slate-700 mb-1">اسم العميل بالكامل *</label>
              <div className="relative">
                <input
                  type="text"
                  required
                  placeholder="الاسم الثلاثي"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full px-3 py-2 pr-9 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
                />
                <User className="w-4 h-4 text-slate-400 absolute top-2.5 right-3" />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">رقم الهاتف لاستلام الرمز والتأكيد *</label>
                <div className="relative">
                  <input
                    type="tel"
                    required
                    placeholder="+2189XXXXXXXX"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    className="w-full px-3 py-2 pr-9 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  />
                  <Phone className="w-4 h-4 text-slate-400 absolute top-2.5 right-3" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">البريد الإلكتروني (لتلقي التذكرة)</label>
                <div className="relative">
                  <input
                    type="email"
                    placeholder="name@email.com"
                    value={customerEmail}
                    onChange={(e) => setCustomerEmail(e.target.value)}
                    className="w-full px-3 py-2 pr-9 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  />
                  <Mail className="w-4 h-4 text-slate-400 absolute top-2.5 right-3" />
                </div>
              </div>
            </div>

            {/* Payment Method */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">طريقة الدفع</label>
              <div className="grid grid-cols-2 gap-3">
                <div
                  onClick={() => setPaymentMethod("ONLINE")}
                  className={`p-3 rounded-xl border cursor-pointer text-xs flex items-center gap-2.5 transition ${
                    paymentMethod === "ONLINE"
                      ? "border-blue-600 bg-blue-50/50 text-blue-900 font-bold"
                      : "border-slate-200 text-slate-700 hover:bg-slate-50"
                  }`}
                >
                  <CreditCard className="w-4 h-4 text-blue-600" />
                  <div>
                    <span>دفع إلكتروني فوري</span>
                    <span className="block text-[10px] text-slate-400 font-normal">بطاقة مصرفية / سداد / تداول</span>
                  </div>
                </div>

                <div
                  onClick={() => setPaymentMethod("CASH")}
                  className={`p-3 rounded-xl border cursor-pointer text-xs flex items-center gap-2.5 transition ${
                    paymentMethod === "CASH"
                      ? "border-blue-600 bg-blue-50/50 text-blue-900 font-bold"
                      : "border-slate-200 text-slate-700 hover:bg-slate-50"
                  }`}
                >
                  <Banknote className="w-4 h-4 text-emerald-600" />
                  <div>
                    <span>الدفع في المنشأة (كاش)</span>
                    <span className="block text-[10px] text-slate-400 font-normal">تأكيد الموعد عند الحضور</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Notes */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">ملاحظات أو طلبات خاصة للمزود</label>
              <textarea
                rows={2}
                placeholder="أي استفسار أو حالة خاصة ترغب بإبلاغ المنشأة بها..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
              />
            </div>

            {/* Financial Breakdown Table */}
            <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-1.5 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>سعر الخدمة:</span>
                <span className="font-bold">{service.price} {organization.currency}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>رسوم خدمة منصة رابط (تقنية وحماية):</span>
                <span className="font-bold">{serviceFee.toFixed(2)} {organization.currency}</span>
              </div>
              <div className="flex justify-between pt-1.5 border-t border-slate-200 text-slate-900 font-black text-sm">
                <span>الإجمالي المستحق:</span>
                <span className="text-blue-700">{grandTotal.toFixed(2)} {organization.currency}</span>
              </div>
            </div>

            <div className="bg-emerald-50 text-emerald-800 text-xs p-3 rounded-xl border border-emerald-200 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{organization.cancellationPolicyAr || "حجز مضمون محمي من التضارب"}</span>
            </div>

            {/* Submit / Cancel Buttons */}
            <div className="pt-2 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 border border-slate-300 rounded-xl text-xs font-medium text-slate-600 hover:bg-slate-50 transition"
              >
                إلغاء
              </button>
              <button
                type="submit"
                disabled={loading}
                className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-600/30 transition disabled:opacity-50 flex items-center gap-1.5"
              >
                {loading ? "جاري حجز وتأكيد الموعد..." : "تأكيد الحجز الفوري"}
              </button>
            </div>
          </form>
        ) : (
          /* Confirmation Step 2 */
          <div className="p-8 text-center space-y-5 animate-fadeIn">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-md">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div>
              <div className="inline-block px-3 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-full text-xs font-bold mb-2">
                تم تأكيد وتسجيل الحجز بنجاح
              </div>
              <h3 className="text-2xl font-black text-slate-900">مرحباً {customerName}</h3>
              <p className="text-xs text-slate-600 max-w-sm mx-auto mt-1 leading-relaxed">
                تم تأكيد حجزك رسمياً في <strong>{organization.nameAr}</strong> لخدمة <strong>{service.nameAr}</strong>.
              </p>
            </div>

            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 text-right space-y-2.5 text-xs max-w-md mx-auto">
              <div className="flex justify-between border-b border-slate-200 pb-2">
                <span className="text-slate-500">رقم الحجز المرجعي (Booking Ref):</span>
                <span className="font-mono font-bold text-blue-700 text-sm tracking-wider">{bookingRef}</span>
              </div>
              <div className="flex justify-between border-b border-slate-200 pb-2">
                <span className="text-slate-500">التاريخ والوقت:</span>
                <span className="font-bold text-slate-900">{selectedDate} في تمام {selectedTime}</span>
              </div>
              <div className="flex justify-between border-b border-slate-200 pb-2">
                <span className="text-slate-500">طريقة الدفع:</span>
                <span className="font-bold text-emerald-700">
                  {paymentMethod === "ONLINE" ? "مدفوع إلكترونياً بالكامل" : "الدفع عند الوصول للمقر"}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">الموقع:</span>
                <span className="text-slate-700 font-medium">{organization.city} - {organization.primaryAddress}</span>
              </div>
            </div>

            <div className="pt-2 flex flex-col sm:flex-row gap-2.5 justify-center max-w-xs mx-auto">
              <button
                onClick={onClose}
                className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-xs shadow-md transition"
              >
                العودة للرئيسية
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
