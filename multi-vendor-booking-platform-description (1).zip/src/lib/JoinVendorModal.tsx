"use client";

import React, { useState } from "react";
import { CheckCircle2, Send, X, Building2, MapPin, Phone, Mail, User, ShieldCheck } from "lucide-react";

interface Props {
  isOpen: boolean;
  onClose: () => void;
  categories: Array<{ slug: string; nameAr: string }>;
  onSuccessJoined?: () => void;
}

export default function JoinVendorModal({ isOpen, onClose, categories, onSuccessJoined }: Props) {
  const [formData, setFormData] = useState({
    businessName: "",
    categorySlug: "medical",
    contactPerson: "",
    email: "",
    phone: "",
    city: "طرابلس",
    address: "",
    notes: "",
  });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const res = await fetch("/api/vendors/join", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (!res.ok) {
        throw new Error("حدث خطأ أثناء إرسال الطلب، يرجى المحاولة لاحقاً");
      }

      setSuccess(true);
      if (onSuccessJoined) onSuccessJoined();
    } catch (err: any) {
      setError(err.message || "حدث خطأ غير متوقع");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm overflow-y-auto text-right">
      <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-100 relative">
        <button
          onClick={onClose}
          className="absolute top-4 left-4 text-slate-400 hover:text-slate-600 w-8 h-8 flex items-center justify-center rounded-lg hover:bg-slate-100 transition"
        >
          <X className="w-5 h-5" />
        </button>

        {success ? (
          <div className="text-center py-8 space-y-4">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-2 animate-bounce">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h3 className="text-2xl font-black text-slate-900">تم تسجيل منشأتكم وتفعيل لوحة التحكم!</h3>
            <p className="text-slate-600 text-xs sm:text-sm max-w-sm mx-auto leading-relaxed">
              أهلاً بكم في منظومة <strong>رابط للحجوزات</strong>. تم إنشاء حساب المنشأة وتخصيص الفرع والمحفظة، ويمكنكم الآن إضافة الخدمات واستقبال الحجوزات المباشرة.
            </p>
            <button
              onClick={() => {
                setSuccess(false);
                onClose();
              }}
              className="mt-4 px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold shadow-md transition text-xs"
            >
              تم، التوجه للمنصة
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-3.5">
            <div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-blue-50 text-blue-700 rounded-md text-xs font-bold mb-1">
                <ShieldCheck className="w-3.5 h-3.5" /> شركاء النجاح في ليبيا
              </div>
              <h3 className="text-xl font-black text-slate-900">انضم كمزود خدمة إلى منصة "رابط"</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                احصل على لوحة تحكم سحابية مستقلة، زد أرباحك، وأدر مواعيد صالتك أو مصحتك أو منتجعك باحترافية
              </p>
            </div>

            {error && (
              <div className="p-3 bg-red-50 text-red-600 text-xs rounded-xl border border-red-200">
                {error}
              </div>
            )}

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">اسم المنشأة أو النشاط التجاري *</label>
              <div className="relative">
                <input
                  type="text"
                  required
                  placeholder="مثال: مصحة النور التخصصية / قاعة السلام / شاليهات الواحة"
                  value={formData.businessName}
                  onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
                  className="w-full px-3 py-2 pr-9 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
                />
                <Building2 className="w-4 h-4 text-slate-400 absolute top-2.5 right-3" />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">القطاع المستهدف *</label>
                <select
                  value={formData.categorySlug}
                  onChange={(e) => setFormData({ ...formData, categorySlug: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs bg-white focus:ring-2 focus:ring-blue-600 focus:outline-none"
                >
                  <option value="medical">القطاع الطبي والمصحات</option>
                  <option value="events">المناسبات وصالات الأفراح</option>
                  <option value="hospitality">الضيافة والشاليهات والمنتجعات</option>
                  <option value="wellness">التجميل والعناية والنوادي</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">المدينة *</label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    placeholder="طرابلس، بنغازي، مصراتة، زوارة..."
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    className="w-full px-3 py-2 pr-9 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  />
                  <MapPin className="w-4 h-4 text-slate-400 absolute top-2.5 right-3" />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">اسم المسؤول *</label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    placeholder="الاسم الثلاثي"
                    value={formData.contactPerson}
                    onChange={(e) => setFormData({ ...formData, contactPerson: e.target.value })}
                    className="w-full px-3 py-2 pr-9 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  />
                  <User className="w-4 h-4 text-slate-400 absolute top-2.5 right-3" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">رقم الهاتف للتواصل *</label>
                <div className="relative">
                  <input
                    type="tel"
                    required
                    placeholder="+2189XXXXXXXX"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-3 py-2 pr-9 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  />
                  <Phone className="w-4 h-4 text-slate-400 absolute top-2.5 right-3" />
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">العنوان التفصيلي</label>
              <input
                type="text"
                placeholder="الشارع، الحي، أقرب نقطة دالة..."
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">ملاحظات أو نبذة عن الخدمات المقدمة</label>
              <textarea
                rows={2}
                placeholder="عدد القاعات أو العيادات، ساعات العمل المقترحة..."
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
              />
            </div>

            <div className="pt-2 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 border border-slate-300 rounded-xl text-xs font-medium text-slate-700 hover:bg-slate-50 transition"
              >
                إلغاء
              </button>
              <button
                type="submit"
                disabled={loading}
                className="flex items-center gap-1.5 px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-md transition disabled:opacity-50"
              >
                <Send className="w-3.5 h-3.5" />
                {loading ? "جاري الإرسال وتجهيز المنشأة..." : "إرسال طلب الانضمام"}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
