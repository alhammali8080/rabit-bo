"use client";

import React, { useState } from "react";
import { Search, X, CheckCircle, Calendar, Clock, MapPin, User, AlertCircle } from "lucide-react";

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export default function CheckBookingModal({ isOpen, onClose }: Props) {
  const [refInput, setRefInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState("");

  if (!isOpen) return null;

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!refInput.trim()) return;
    setLoading(true);
    setError("");
    setResult(null);

    try {
      const res = await fetch(`/api/bookings?bookingRef=${encodeURIComponent(refInput.trim().toUpperCase())}`);
      const data = await res.json();
      if (!res.ok || !data) {
        setError("لم يتم العثور على حجز بهذا الرقم المرجعي. يرجى التحقق من الرقم والمحاولة مرة أخرى.");
      } else {
        setResult(data);
      }
    } catch (e: any) {
      setError("حدث خطأ أثناء الاستعلام، يرجى المحاولة لاحقاً.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/75 backdrop-blur-sm">
      <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 relative">
        <button
          onClick={onClose}
          className="absolute top-4 left-4 text-slate-400 hover:text-slate-600 w-8 h-8 flex items-center justify-center rounded-lg hover:bg-slate-100 transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-right mb-5">
          <h3 className="text-lg font-bold text-slate-900">الاستعلام عن حجز مؤكد</h3>
          <p className="text-xs text-slate-500 mt-0.5">أدخل رقم الحجز المرجعي (مثال: RBT-2025-1082)</p>
        </div>

        <form onSubmit={handleSearch} className="flex gap-2 mb-4">
          <input
            type="text"
            required
            placeholder="RBT-2025-XXXX"
            value={refInput}
            onChange={(e) => setRefInput(e.target.value)}
            className="flex-1 px-3 py-2 border border-slate-300 rounded-lg text-sm font-mono uppercase focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <button
            type="submit"
            disabled={loading}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition disabled:opacity-50"
          >
            <Search className="w-4 h-4" />
            {loading ? "بحث..." : "استعلام"}
          </button>
        </form>

        {error && (
          <div className="p-3 bg-red-50 text-red-600 text-xs rounded-lg border border-red-200 flex items-start gap-2 mb-4">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {result && (
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3 text-xs animate-fadeIn">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200">
              <span className="text-slate-500">حالة الحجز:</span>
              <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 font-bold rounded-full text-[11px] flex items-center gap-1">
                <CheckCircle className="w-3.5 h-3.5" /> مؤكد
              </span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-500 flex items-center gap-1">
                <User className="w-3.5 h-3.5 text-blue-600" /> الاسم:
              </span>
              <span className="font-bold text-slate-800">{result.customerName}</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-500 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-blue-600" /> التاريخ:
              </span>
              <span className="font-bold text-slate-800">{result.bookingDate}</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-500 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-blue-600" /> الوقت:
              </span>
              <span className="font-bold text-slate-800">{result.bookingTime}</span>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-200">
              <span className="text-slate-500">المبلغ الإجمالي:</span>
              <span className="text-sm font-bold text-emerald-600">{result.totalPrice} ريال</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
