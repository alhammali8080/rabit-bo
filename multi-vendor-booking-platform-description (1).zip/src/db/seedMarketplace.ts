import bcrypt from "bcryptjs";
import { and, eq, gte, sql } from "drizzle-orm";
import { db } from "./index";
import {
  users, categories, organizations, branches, services, wallets, banners, events, ticketTiers, busTrips, UserRole, ProviderStatus,
} from "./schema";

const IMG = {
  stadium: "https://images.pexels.com/photos/35898730/pexels-photo-35898730.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  stadium2: "https://images.pexels.com/photos/28827841/pexels-photo-28827841.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  bus: "https://images.pexels.com/photos/18889487/pexels-photo-18889487.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  busSeats: "https://images.pexels.com/photos/24738022/pexels-photo-24738022.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  hotel: "https://images.pexels.com/photos/97083/pexels-photo-97083.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  hotel2: "https://images.pexels.com/photos/6466496/pexels-photo-6466496.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  restaurant: "https://images.pexels.com/photos/12181619/pexels-photo-12181619.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  restaurant2: "https://images.pexels.com/photos/33144658/pexels-photo-33144658.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  pitch: "https://images.pexels.com/photos/15521639/pexels-photo-15521639.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  concert: "https://images.pexels.com/photos/36675302/pexels-photo-36675302.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  resort: "https://images.unsplash.com/photo-1582719508461-905c673771fd?auto=format&fit=crop&w=1200&q=80",
  clinic: "https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?auto=format&fit=crop&w=1200&q=80",
};

type P = { cat: string; name: string; slug: string; sub: string; city: string; img: string; services: [string, string, number, number][] };

const PROVIDERS: P[] = [
  { cat: "hotels", name: "فندق باب البحر", slug: "bab-albahr-hotel", sub: "إطلالة على البحر في قلب طرابلس", city: "طرابلس", img: IMG.hotel,
    services: [["غرفة مزدوجة – ليلة", "إفطار مفتوح وواي فاي مجاني", 1440, 320], ["جناح عائلي – ليلة", "غرفتا نوم وصالة وإطلالة بحرية", 1440, 580]] },
  { cat: "hotels", name: "فندق الواحة – بنغازي", slug: "alwaha-hotel-benghazi", sub: "إقامة رجال الأعمال والعائلات", city: "بنغازي", img: IMG.hotel2,
    services: [["غرفة مفردة – ليلة", "مكتب عمل وإفطار", 1440, 250], ["غرفة ديلوكس – ليلة", "سرير كينغ وإطلالة على المدينة", 1440, 390]] },
  { cat: "sports", name: "ملاعب النخبة الخماسية", slug: "elite-football-pitches", sub: "ملاعب عشب صناعي بإضاءة ليلية", city: "طرابلس", img: IMG.pitch,
    services: [["ملعب خماسي – ساعة", "يشمل الكرة وغرف تبديل الملابس", 60, 120], ["ملعب سباعي – ساعة", "مقاس كبير مع مدرجات صغيرة", 60, 180]] },
  { cat: "sports", name: "نادي باور جيم", slug: "power-gym-misrata", sub: "صالة لياقة ومدربون معتمدون", city: "مصراتة", img: IMG.pitch,
    services: [["حصة تدريب شخصي", "مدرب خاص لمدة ساعة", 60, 60], ["تقييم لياقة وبرنامج غذائي", "قياس الجسم وخطة شهرية", 45, 90]] },
  { cat: "restaurants", name: "مطعم الشرفة البحري", slug: "alshurfa-seafood", sub: "مأكولات بحرية طازجة على الكورنيش", city: "طرابلس", img: IMG.restaurant,
    services: [["حجز طاولة لـ 4 أشخاص", "العربون يُخصم من الفاتورة", 120, 20], ["قاعة خاصة حتى 20 شخصاً", "للمناسبات العائلية وعزائم العمل", 180, 150]] },
  { cat: "restaurants", name: "كافيه الميدان", slug: "almaydan-cafe", sub: "قهوة مختصة وجلسات هادئة", city: "بنغازي", img: IMG.restaurant2,
    services: [["حجز جلسة لـ 6 أشخاص", "جلسة خارجية مع إطلالة", 120, 15]] },
  { cat: "cars", name: "رابط لتأجير السيارات", slug: "rabit-car-rental", sub: "سيارات حديثة مع تأمين شامل", city: "طرابلس", img: IMG.bus,
    services: [["سيارة اقتصادية – يوم", "تويوتا يارس أو ما يعادلها", 1440, 150], ["سيارة دفع رباعي – يوم", "مناسبة للرحلات الطويلة", 1440, 320], ["سيارة بسائق – 4 ساعات", "داخل المدينة", 240, 200]] },
  { cat: "travel", name: "وكالة المسافر للسياحة", slug: "almusafer-travel", sub: "رحلات داخلية وخارجية منظمة", city: "طرابلس", img: IMG.resort,
    services: [["رحلة غدامس – 3 أيام", "نقل وإقامة وجولة في المدينة القديمة", 4320, 850], ["برنامج جربة – 4 أيام", "فندق 4 نجوم مع الإفطار", 5760, 1250]] },
  { cat: "entertainment", name: "مدينة ألعاب السندباد", slug: "sindbad-park", sub: "ألعاب لكل الأعمار وحفلات أطفال", city: "طرابلس", img: IMG.concert,
    services: [["تذكرة دخول مفتوحة", "جميع الألعاب ليوم كامل", 180, 35], ["باقة حفلة عيد ميلاد", "قاعة وكعكة و15 طفلاً", 180, 450]] },
  { cat: "entertainment", name: "كارتينغ الساحل", slug: "sahel-karting", sub: "حلبة سباق سيارات صغيرة", city: "مصراتة", img: IMG.stadium2,
    services: [["جولة 15 دقيقة", "خوذة وتجهيزات السلامة", 15, 40]] },
  { cat: "business", name: "مركز طرابلس للأعمال", slug: "tripoli-business-center", sub: "قاعات اجتماعات ومساحات عمل مشتركة", city: "طرابلس", img: IMG.hotel2,
    services: [["قاعة اجتماعات – ساعة", "حتى 12 شخصاً مع شاشة عرض", 60, 90], ["مساحة عمل مشتركة – يوم", "إنترنت سريع وقهوة مجانية", 480, 40]] },
  { cat: "photography", name: "استوديو لمسة للتصوير", slug: "lamsa-studio", sub: "تصوير احترافي وإنتاج فيديو", city: "بنغازي", img: IMG.concert,
    services: [["جلسة تصوير شخصية", "20 صورة معدلة", 60, 150], ["تغطية حفل زفاف كاملة", "تصوير فوتوغرافي وفيديو وألبوم", 480, 1800]] },
  { cat: "kids", name: "نادي براعم للأطفال", slug: "baraem-kids", sub: "أنشطة تعليمية وترفيهية آمنة", city: "طرابلس", img: IMG.resort,
    services: [["ورشة رسم وأشغال يدوية", "للأعمار من 5 إلى 10 سنوات", 90, 45], ["حضانة نهارية – يوم", "وجبتان وأنشطة", 480, 60]] },
  { cat: "education", name: "أكاديمية المستقبل للتدريب", slug: "future-academy", sub: "دورات لغات ومهارات مهنية", city: "طرابلس", img: IMG.hotel2,
    services: [["حصة لغة إنجليزية خاصة", "مع مدرّس معتمد", 60, 50], ["دورة إكسل للمبتدئين – يوم", "شهادة حضور", 360, 180]] },
  { cat: "tickets", name: "ملعب طرابلس الدولي", slug: "tripoli-international-stadium", sub: "أكبر ملاعب ليبيا – تذاكر المباريات والفعاليات", city: "طرابلس", img: IMG.stadium,
    services: [["جولة داخل الملعب", "زيارة غرف الملابس والمنصة الرئيسية", 60, 20]] },
];

const BUS_OPERATORS = [
  { name: "الساحل للنقل البري", slug: "sahel-bus", sub: "رحلات يومية بين المدن الليبية بحافلات VIP", city: "طرابلس" },
  { name: "النجم السريع للحافلات", slug: "najm-express-bus", sub: "أسعار اقتصادية ومواعيد دقيقة", city: "بنغازي" },
];

const ROUTES: [string, string, number, number, string][] = [
  // from, to, hours, basePrice, station
  ["طرابلس", "بنغازي", 12, 95, "محطة طرابلس المركزية – طريق الشط"],
  ["بنغازي", "طرابلس", 12, 95, "محطة بنغازي – الكيش"],
  ["طرابلس", "مصراتة", 3, 30, "محطة طرابلس المركزية – طريق الشط"],
  ["مصراتة", "طرابلس", 3, 30, "محطة مصراتة – الطريق الساحلي"],
  ["طرابلس", "سبها", 10, 85, "محطة طرابلس المركزية – طريق الشط"],
  ["بنغازي", "طبرق", 6, 55, "محطة بنغازي – الكيش"],
  ["طرابلس", "الزاوية", 1, 12, "محطة قرقارش"],
];

const addDays = (n: number) => new Date(Date.now() + n * 86400000).toISOString().slice(0, 10);

async function ensureOrg(ownerPhone: string, ownerName: string, catId: number, o: { name: string; slug: string; sub: string; city: string; img: string }) {
  const [ex] = await db.select().from(organizations).where(eq(organizations.slug, o.slug));
  if (ex) return ex;
  const hash = await bcrypt.hash("123456", 10);
  const [u] = await db.insert(users).values({ role: UserRole.PROVIDER_OWNER, fullName: ownerName, phone: ownerPhone, passwordHash: hash, city: o.city }).onConflictDoNothing().returning();
  const owner = u ?? (await db.select().from(users).where(eq(users.phone, ownerPhone)))[0];
  const [org] = await db
    .insert(organizations)
    .values({
      ownerId: owner.id, categoryId: catId, nameAr: o.name, slug: o.slug, subtitleAr: o.sub,
      descriptionAr: `${o.name} – ${o.sub}. احجز مباشرة عبر رابط وادفع من محفظتك.`,
      city: o.city, primaryAddress: `${o.city} – المركز`, phone: ownerPhone, email: `${o.slug}@rabit.ly`,
      coverUrl: o.img, logoUrl: o.img, status: ProviderStatus.VERIFIED,
      rating: (4.5 + Math.random() * 0.5).toFixed(2), reviewsCount: 10 + Math.floor(Math.random() * 120), currency: "LYD",
    })
    .returning();
  await db.insert(branches).values({ organizationId: org.id, nameAr: "الفرع الرئيسي", city: o.city, district: "المركز", address: `${o.city} – المركز`, phone: ownerPhone, isMain: true });
  await db.insert(wallets).values({ organizationId: org.id }).onConflictDoNothing();
  return org;
}

let done = false;
export async function seedMarketplace() {
  if (done) return;
  const cats = await db.select().from(categories);
  const catId = (slug: string) => cats.find((c) => c.slug === slug)?.id;

  // 1) Providers for every category
  let i = 0;
  for (const p of PROVIDERS) {
    i++;
    const cid = catId(p.cat);
    if (!cid) continue;
    const [ex] = await db.select({ id: organizations.id }).from(organizations).where(eq(organizations.slug, p.slug));
    if (ex) continue;
    const org = await ensureOrg(`+2189300${String(i).padStart(5, "0")}`, `مالك ${p.name}`, cid, p);
    await db.insert(services).values(
      p.services.map(([nameAr, descriptionAr, durationMinutes, price]) => ({ organizationId: org.id, nameAr, descriptionAr, durationMinutes, price: price.toFixed(2) }))
    );
  }

  // 2) Bus operators
  const carsId = catId("cars");
  const operators = [];
  if (carsId) {
    let j = 0;
    for (const b of BUS_OPERATORS) {
      j++;
      operators.push(await ensureOrg(`+2189400${String(j).padStart(5, "0")}`, `إدارة ${b.name}`, carsId, { ...b, img: IMG.bus }));
    }
  }
  await ensureBusTrips(operators.map((o) => o.id));

  // 3) Events + ticket tiers
  const [anyEvent] = await db.select({ id: events.id }).from(events).limit(1);
  if (!anyEvent) {
    const evs = [
      { slug: "tripoli-derby", titleAr: "ديربي طرابلس: الأهلي × الاتحاد", subtitleAr: "الدوري الليبي الممتاز – الجولة الحاسمة", kind: "MATCH", venueAr: "ملعب طرابلس الدولي", city: "طرابلس", eventDate: addDays(6), eventTime: "19:00", imageUrl: IMG.stadium, homeTeam: "الأهلي طرابلس", awayTeam: "الاتحاد",
        tiers: [["المدرجات العامة", 20, 20000], ["المقصورة الجانبية", 60, 3000], ["المنصة الرئيسية VIP", 150, 400]] },
      { slug: "benghazi-derby", titleAr: "الأهلي بنغازي × النصر", subtitleAr: "قمة الشرق الليبي", kind: "MATCH", venueAr: "ملعب شهداء بنينا", city: "بنغازي", eventDate: addDays(13), eventTime: "18:30", imageUrl: IMG.stadium2, homeTeam: "الأهلي بنغازي", awayTeam: "النصر",
        tiers: [["المدرجات العامة", 15, 12000], ["المقصورة", 50, 1500]] },
      { slug: "summer-concert", titleAr: "ليلة الطرب الليبي", subtitleAr: "حفل موسيقي بمشاركة نخبة من الفنانين", kind: "CONCERT", venueAr: "مسرح الكشاف – طرابلس", city: "طرابلس", eventDate: addDays(20), eventTime: "21:00", imageUrl: IMG.concert, homeTeam: null, awayTeam: null,
        tiers: [["دخول عام", 50, 1500], ["الصفوف الأمامية", 120, 200]] },
    ] as const;
    for (const e of evs) {
      const { tiers, ...rest } = e;
      const [row] = await db.insert(events).values({ ...rest, descriptionAr: `${e.titleAr} – ${e.venueAr}. التذكرة إلكترونية وتُعرض من حسابك عند البوابة.` }).returning();
      await db.insert(ticketTiers).values(tiers.map(([nameAr, price, capacity]) => ({ eventId: row.id, nameAr, price: price.toFixed(2), capacity })));
    }
  } else {
    // keep demo events in the future
    await db.execute(sql`update events set event_date = to_char(now() + (id * 7 - 1) * interval '1 day', 'YYYY-MM-DD') where event_date < to_char(now(), 'YYYY-MM-DD')`);
  }

  // 4) Ad banners
  const [anyBanner] = await db.select({ id: banners.id }).from(banners).limit(1);
  if (!anyBanner) {
    await db.insert(banners).values([
      { titleAr: "ديربي طرابلس: الأهلي × الاتحاد", subtitleAr: "ملعب طرابلس الدولي – احجز تذكرتك الإلكترونية الآن قبل نفادها", badgeAr: "⚽ مباراة الأسبوع", imageUrl: IMG.stadium, ctaLabel: "اشترِ تذكرتك", href: "/events/tripoli-derby", displayOrder: 1 },
      { titleAr: "سافر بين المدن براحة", subtitleAr: "حافلات VIP يومية: طرابلس، بنغازي، مصراتة، سبها – اختر مقعدك وادفع من محفظتك", badgeAr: "🚌 النقل البري", imageUrl: IMG.bus, ctaLabel: "احجز مقعدك", href: "/bus", displayOrder: 2, isSponsored: false },
      { titleAr: "صيفك في منتجعات الساحل", subtitleAr: "شاليهات بمسابح خاصة بخصم يصل إلى 20% للحجز المبكر", badgeAr: "🏖️ عرض الصيف", imageUrl: IMG.resort, ctaLabel: "شاهد العروض", href: "/category/hospitality", displayOrder: 3 },
      { titleAr: "رابط الصحي", subtitleAr: "قارن المصحات واحصل على استشارة مجانية من مستشار صحي", badgeAr: "🏥 جديد", imageUrl: IMG.clinic, ctaLabel: "ابدأ الآن", href: "/health", displayOrder: 4, isSponsored: false },
    ]);
  }
  done = true;
}

/** Keeps 14 days of upcoming trips available (idempotent top-up). */
export async function ensureBusTrips(operatorIds?: number[]) {
  let ops = operatorIds;
  if (!ops?.length) {
    const rows = await db.select({ id: organizations.id }).from(organizations).where(sql`${organizations.slug} in ('sahel-bus','najm-express-bus')`);
    ops = rows.map((r) => r.id);
  }
  if (!ops.length) return;
  const today = addDays(0);
  for (let d = 0; d < 14; d++) {
    const date = addDays(d);
    const [has] = await db.select({ id: busTrips.id }).from(busTrips).where(and(eq(busTrips.tripDate, date), gte(busTrips.tripDate, today))).limit(1);
    if (has) continue;
    const rows = [];
    for (const [ri, [from, to, hours, base, station]] of ROUTES.entries()) {
      for (const [k, dep] of ["07:00", "14:00", "22:00"].entries()) {
        if (hours >= 10 && dep === "14:00") continue;
        const op = ops[(k + ri) % ops.length];
        const vip = k % 2 === 0;
        const [h, m] = dep.split(":").map(Number);
        const arr = `${String((h + hours) % 24).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
        rows.push({
          operatorId: op, fromCity: from, toCity: to, tripDate: date, departTime: dep, arriveTime: arr,
          busType: vip ? "VIP" : "STANDARD", seatCount: vip ? 30 : 44, price: (vip ? base * 1.3 : base).toFixed(2),
          amenities: JSON.stringify(vip ? ["واي فاي", "مقاعد جلدية", "شاحن USB", "وجبة خفيفة"] : ["تكييف", "شاحن USB"]),
          stationAr: station,
        });
      }
    }
    await db.insert(busTrips).values(rows);
  }
}
