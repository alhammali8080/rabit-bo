import { db } from "./index";
import {
  users,
  UserRole,
  categories,
  organizations,
  branches,
  staff,
  services,
  bookings,
  wallets,
  ledgerEntries,
  subscriptionPlans,
  subscriptions,
  reviews,
  systemSettings,
  auditLogs,
  vipTiers,
  vipBenefits,
  vipMemberships,
  rechargeBatches,
  rechargeCards,
  walletCampaigns,
  VipBenefitKey,
  WalletTxType,
  BookingStatus,
  PaymentStatus,
  ProviderStatus,
} from "./schema";
import bcrypt from "bcryptjs";
import { eq } from "drizzle-orm";
import { applyWalletTx } from "@/lib/server/wallet";
import { hashCardCode, normalizeCode } from "@/lib/server/cards";
import { seedMarketplace, ensureBusTrips } from "./seedMarketplace";

async function seedCore() {
  try {
    const existingUsers = await db.select().from(users).limit(1);
    if (existingUsers.length > 0) {
      return;
    }

    console.log("🚀 Starting Comprehensive Production Seed for رابط للحجوزات...");

    const passwordHash = await bcrypt.hash("123456", 10);
    const demoPasswordHash = await bcrypt.hash("123456", 10);

    // 1. Create Core Users
    const [adminUser] = await db
      .insert(users)
      .values({
        role: UserRole.PLATFORM_ADMIN,
        fullName: "المهندس أسامة الزنتاني (مدير المنصة)",
        phone: "+218911002030",
        email: "admin@rabit.ly",
        passwordHash,
        city: "طرابلس",
        isPhoneVerified: true,
      })
      .returning();

    const [providerOwner1] = await db
      .insert(users)
      .values({
        role: UserRole.PROVIDER_OWNER,
        fullName: "د. طارق الغرياني (مصحة قرطبة التخصصية)",
        phone: "+218925551122",
        email: "drtariq@qurtuba.ly",
        passwordHash: demoPasswordHash,
        city: "طرابلس",
        isPhoneVerified: true,
      })
      .returning();

    const [providerOwner2] = await db
      .insert(users)
      .values({
        role: UserRole.PROVIDER_OWNER,
        fullName: "الحاج فتحي المصراتي (قصر الأندلس للمناسبات)",
        phone: "+218917773344",
        email: "alandalus@events.ly",
        passwordHash: demoPasswordHash,
        city: "مصراتة",
        isPhoneVerified: true,
      })
      .returning();

    const [providerOwner3] = await db
      .insert(users)
      .values({
        role: UserRole.PROVIDER_OWNER,
        fullName: "سالم الورفلي (منتجع رمال زوارة والشاليهات)",
        phone: "+218949995566",
        email: "info@remaallibya.ly",
        passwordHash: demoPasswordHash,
        city: "زوارة",
        isPhoneVerified: true,
      })
      .returning();

    const [providerOwner4] = await db
      .insert(users)
      .values({
        role: UserRole.PROVIDER_OWNER,
        fullName: "مريم العبيدي (مركز أوركيد للتجميل والعناية)",
        phone: "+218928889900",
        email: "orchid@spa.ly",
        passwordHash: demoPasswordHash,
        city: "بنغازي",
        isPhoneVerified: true,
      })
      .returning();

    const [customer1] = await db
      .insert(users)
      .values({
        role: UserRole.CUSTOMER,
        fullName: "عبد الرحمن بن علي",
        phone: "+218914441122",
        email: "abdulrahman@gmail.com",
        passwordHash: demoPasswordHash,
        city: "طرابلس",
        isPhoneVerified: true,
      })
      .returning();

    const [customer2] = await db
      .insert(users)
      .values({
        role: UserRole.CUSTOMER,
        fullName: "فاطمة المهدي بن يونس",
        phone: "+218923337788",
        email: "fatima.younis@gmail.com",
        passwordHash: demoPasswordHash,
        city: "بنغازي",
        isPhoneVerified: true,
      })
      .returning();

    // 2. Insert Sectors / Categories
    const insertedCategories = await db
      .insert(categories)
      .values([
        {
          slug: "medical",
          nameAr: "القطاع الطبي والمصحات",
          nameEn: "Medical & Clinics",
          descriptionAr: "مصحات تخصصية، عيادات استشارية، ومراكز جراحة اليوم الواحد والأسنان في ليبيا",
          icon: "Stethoscope",
          defaultCommissionPercent: "5.00",
          displayOrder: 1,
        },
        {
          slug: "events",
          nameAr: "المناسبات وصالات الأفراح",
          nameEn: "Weddings & Event Halls",
          descriptionAr: "أفخم صالات الأفراح والمناسبات الاجتماعية والمؤتمرات المجهزة بالكامل",
          icon: "PartyPopper",
          defaultCommissionPercent: "7.00",
          displayOrder: 2,
        },
        {
          slug: "hospitality",
          nameAr: "المنتجعات والضيافة والشاليهات",
          nameEn: "Resorts & Chalets",
          descriptionAr: "شاليهات عائلية ساحلية، استراحات خاصة بمسابح، وفنادق راقية للاستجمام",
          icon: "Palmtree",
          defaultCommissionPercent: "8.00",
          displayOrder: 3,
        },
        {
          slug: "wellness",
          nameAr: "مراكز التجميل والاستجمام والنوادي",
          nameEn: "Beauty, Spa & Wellness",
          descriptionAr: "نوادي صحية، صالونات استجمام، ومراكز علاج طبيعي وعناية متكاملة",
          icon: "Sparkles",
          defaultCommissionPercent: "6.00",
          displayOrder: 4,
        },
      ])
      .returning();

    const catMedical = insertedCategories.find((c) => c.slug === "medical")!;
    const catEvents = insertedCategories.find((c) => c.slug === "events")!;
    const catHosp = insertedCategories.find((c) => c.slug === "hospitality")!;
    const catWell = insertedCategories.find((c) => c.slug === "wellness")!;

    // 3. Subscription Plans (SaaS Model)
    const insertedPlans = await db
      .insert(subscriptionPlans)
      .values([
        {
          slug: "starter",
          nameAr: "الباقة الأساسية (Starter)",
          monthlyPrice: "0.00",
          yearlyPrice: "0.00",
          currency: "LYD",
          maxBranches: 1,
          maxStaff: 3,
          commissionRate: "8.00",
          featuresJson: JSON.stringify([
            "لوحة تحكم لإدارة المواعيد",
            "استقبال الحجوزات الإلكترونية المباشرة",
            "رابط حجز مباشر للمشاركة في مواقع التواصل",
            "إشعارات النظام التلقائية",
          ]),
        },
        {
          slug: "business-pro",
          nameAr: "الباقة الاحترافية (Business Pro)",
          monthlyPrice: "180.00",
          yearlyPrice: "1800.00",
          currency: "LYD",
          maxBranches: 3,
          maxStaff: 12,
          commissionRate: "5.00",
          featuresJson: JSON.stringify([
            "كل مميزات الباقة الأساسية",
            "عمولة مخفضة 5% فقط للمنصة",
            "إدارة حتى 3 فروع و12 موظفاً",
            "تقارير الإيرادات المتقدمة وLedger المالي",
            "إرسال تنبيهات SMS وتذكير العملاء",
            "دعم فني مخصص وأولوية في نتائج البحث",
          ]),
        },
        {
          slug: "enterprise",
          nameAr: "باقة المنشآت الكبرى (Enterprise VIP)",
          monthlyPrice: "450.00",
          yearlyPrice: "4500.00",
          currency: "LYD",
          maxBranches: 10,
          maxStaff: 50,
          commissionRate: "3.50",
          featuresJson: JSON.stringify([
            "كل مميزات باقة الأعمال",
            "عمولة منخفضة جداً 3.5%",
            "فروع وموظفين غير محدودين",
            "دومين خاص وربط API كامل",
            "مدير حساب شخصي وحملات ترويجية ممولة",
          ]),
        },
      ])
      .returning();

    const planPro = insertedPlans.find((p) => p.slug === "business-pro")!;

    // 4. Create Organizations (Providers / Tenants)
    const insertedOrgs = await db
      .insert(organizations)
      .values([
        // Provider 1: Medical
        {
          ownerId: providerOwner1.id,
          categoryId: catMedical.id,
          nameAr: "مصحة قرطبة الدولية الاستشارية",
          nameEn: "Qurtuba International Clinic",
          slug: "qurtuba-clinic",
          subtitleAr: "أكبر صرح طبي لجراحة اليوم الواحد والاستشارات الطبية التخصصية في طرابلس",
          descriptionAr:
            "تأسست مصحة قرطبة لتقديم رعاية طبية تضاهي المعايير الدولية، مع غرف عمليات مجهزة بأحدث مناظير جراحية وطاقم استشاريين متميز في القلب والباطنة والأسنان والعيون وجراحة الأطفال.",
          city: "طرابلس",
          primaryAddress: "طريق السكة، بالقرب من جزيرة ميزران",
          phone: "+218 21 333 4455",
          email: "info@qurtuba.ly",
          logoUrl: "https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&w=300&q=80",
          coverUrl: "https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?auto=format&fit=crop&w=1200&q=80",
          status: ProviderStatus.VERIFIED,
          rating: "4.92",
          reviewsCount: 38,
          isFeatured: true,
          cancellationPolicyAr: "إلغاء مجاني حتى 12 ساعة قبل موعد الكشف مع استرداد المبلغ بالكامل",
          currency: "LYD",
        },
        // Provider 2: Events
        {
          ownerId: providerOwner2.id,
          categoryId: catEvents.id,
          nameAr: "قصر الأندلس الملكي للأفراح والمناسبات",
          nameEn: "Al-Andalus Royal Palace",
          slug: "alandalus-palace",
          subtitleAr: "صالات أعراس ومؤتمرات كبرى بسعة حتى 900 ضيف مع تجهيزات ملكية وبوفيه مفتوح",
          descriptionAr:
            "قصر الأندلس هو الخيار الأول للأعراس الليبية الفاخرة والمؤتمرات الدبلوماسية. قاعات متطورة بأنظمة صوت وإضاءة سينمائية، جنائن استقبال خلابة، وأرقى خدمات الضيافة والتنظيم.",
          city: "مصراتة",
          primaryAddress: "طريق الجزيرة، حي الرويسات",
          phone: "+218 51 666 7788",
          email: "alandalus@events.ly",
          logoUrl: "https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=300&q=80",
          coverUrl: "https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=1200&q=80",
          status: ProviderStatus.VERIFIED,
          rating: "4.96",
          reviewsCount: 52,
          isFeatured: true,
          cancellationPolicyAr: "تعديل الموعد متاح قبل 30 يوماً من موعد الحفل، واسترداد جزئي وفق العقد",
          currency: "LYD",
        },
        // Provider 3: Hospitality
        {
          ownerId: providerOwner3.id,
          categoryId: catHosp.id,
          nameAr: "منتجع رمال زوارة والشاليهات الشاطئية VIP",
          nameEn: "Remaal Zuwarah Luxury Resort",
          slug: "remaal-zuwarah",
          subtitleAr: "شاليهات عائلية خاصة بمسابح مغلقة وحدائق وشاطئ رملي بكر للاسترخاء",
          descriptionAr:
            "استمتع بعطلة لا تُنسى على ساحل البحر المتوسط في أرقى شاليهات زوارة. خصوصية تامة للعائلات، تصميم معماري مودرن، ألعاب مائية للأطفال، وخدمات فندقية مدار الساعة.",
          city: "زوارة",
          primaryAddress: "طريق الكورنيش الساحلي، منطقة المنقوب",
          phone: "+218 25 444 8899",
          email: "resort@remaallibya.ly",
          logoUrl: "https://images.unsplash.com/photo-1582719508461-905c673771fd?auto=format&fit=crop&w=300&q=80",
          coverUrl: "https://images.unsplash.com/photo-1582719508461-905c673771fd?auto=format&fit=crop&w=1200&q=80",
          status: ProviderStatus.VERIFIED,
          rating: "4.88",
          reviewsCount: 29,
          isFeatured: true,
          cancellationPolicyAr: "إلغاء مجاني قبل 48 ساعة من تاريخ الدخول",
          currency: "LYD",
        },
        // Provider 4: Beauty & Wellness
        {
          ownerId: providerOwner4.id,
          categoryId: catWell.id,
          nameAr: "مركز أوركيد للتجميل والسبا الملكي",
          nameEn: "Orchid Spa & Beauty Center",
          slug: "orchid-spa",
          subtitleAr: "جلسات تدليك استرخائي، حمام مغربي، وعناية متطورة بالبشرة والمكياج السينمائي",
          descriptionAr:
            "واحة من الهدوء والاستجمام في قلب بنغازي بأيدي خبيرات معتمدات. استخدام زيوت طبيعية وأحدث تقنيات الليزر والعناية بالبشرة لراحة جسدية ونفسية تامة.",
          city: "بنغازي",
          primaryAddress: "شارع دبي، حي الفويهات",
          phone: "+218 61 777 0011",
          email: "orchid@spa.ly",
          logoUrl: "https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=300&q=80",
          coverUrl: "https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=1200&q=80",
          status: ProviderStatus.VERIFIED,
          rating: "4.94",
          reviewsCount: 64,
          isFeatured: false,
          cancellationPolicyAr: "إلغاء مجاني حتى 6 ساعات قبل موعد الجلسة",
          currency: "LYD",
        },
      ])
      .returning();

    const orgMed = insertedOrgs.find((o) => o.slug === "qurtuba-clinic")!;
    const orgEvents = insertedOrgs.find((o) => o.slug === "alandalus-palace")!;
    const orgHosp = insertedOrgs.find((o) => o.slug === "remaal-zuwarah")!;
    const orgWell = insertedOrgs.find((o) => o.slug === "orchid-spa")!;

    // 5. Create Branches
    const [branchMed1] = await db
      .insert(branches)
      .values([
        {
          organizationId: orgMed.id,
          nameAr: "الفرع الرئيسي - طريق السكة",
          city: "طرابلس",
          district: "ميزران",
          address: "طريق السكة بجوار مجمع المحاكم",
          phone: "+218 21 333 4455",
          isMain: true,
          openingTime: "08:30",
          closingTime: "22:00",
        },
      ])
      .returning();

    const [branchEvents1] = await db
      .insert(branches)
      .values([
        {
          organizationId: orgEvents.id,
          nameAr: "المقر الرئيسي - قصر الأندلس",
          city: "مصراتة",
          district: "الرويسات",
          address: "طريق الجزيرة",
          phone: "+218 51 666 7788",
          isMain: true,
          openingTime: "10:00",
          closingTime: "01:00",
        },
      ])
      .returning();

    const [branchHosp1] = await db
      .insert(branches)
      .values([
        {
          organizationId: orgHosp.id,
          nameAr: "فرع الكورنيش والمسابح الخاصة",
          city: "زوارة",
          district: "المنقوب",
          address: "شاطئ الرمال الذهبية",
          phone: "+218 25 444 8899",
          isMain: true,
          openingTime: "09:00",
          closingTime: "23:00",
        },
      ])
      .returning();

    const [branchWell1] = await db
      .insert(branches)
      .values([
        {
          organizationId: orgWell.id,
          nameAr: "فرع الفويهات الملكي",
          city: "بنغازي",
          district: "الفويهات",
          address: "شارع دبي التجاري",
          phone: "+218 61 777 0011",
          isMain: true,
          openingTime: "10:00",
          closingTime: "21:00",
        },
      ])
      .returning();

    // 6. Create Staff for Organizations
    const [staffDoctor1] = await db
      .insert(staff)
      .values([
        {
          organizationId: orgMed.id,
          branchId: branchMed1.id,
          fullName: "د. طارق الغرياني",
          titleAr: "استشاري أول أمراض القلب والأوعية الدموية والقسطرة",
          phone: "+218925551122",
          email: "drtariq@qurtuba.ly",
          avatarUrl: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=200&q=80",
        },
        {
          organizationId: orgMed.id,
          branchId: branchMed1.id,
          fullName: "د. إيمان الصالحين",
          titleAr: "أخصائية طب وجراحة وتجميل الأسنان وزراعة الفكين",
          phone: "+218915556677",
          email: "dr.eman@qurtuba.ly",
          avatarUrl: "https://images.unsplash.com/photo-1594824813588-46c535793010?auto=format&fit=crop&w=200&q=80",
        },
      ])
      .returning();

    const [staffEventsMgr] = await db
      .insert(staff)
      .values([
        {
          organizationId: orgEvents.id,
          branchId: branchEvents1.id,
          fullName: "الأستاذ خالد الكوافي",
          titleAr: "المشرف العام ومنسق حفلات الزفاف والمؤتمرات",
          phone: "+218917770022",
          email: "khaled@alandalus.ly",
        },
      ])
      .returning();

    // 7. Create Services
    const insertedServices = await db
      .insert(services)
      .values([
        // Medical Services (Qurtuba)
        {
          organizationId: orgMed.id,
          branchId: branchMed1.id,
          nameAr: "كشف استشاري قلب وأوعية دموية + تخطيط قلب ECG",
          descriptionAr:
            "فحص سريري دقيق، تخطيط قلب كهربائي متقدم، تقييم ضغط الدم والدهون، وخطة علاجية مخصصة للوقاية والتعافي.",
          durationMinutes: 45,
          bufferMinutes: 15,
          price: "120.00",
          currency: "LYD",
        },
        {
          organizationId: orgMed.id,
          branchId: branchMed1.id,
          nameAr: "تنظيف وتبييض الأسنان بالليزر وإزالة الرواسب الجيرية",
          descriptionAr: "جلسة تجميلية متطورة لتنظيف وتبييض الأسنان مع فحص شامل وتلميع لابتسامة ناصعة.",
          durationMinutes: 60,
          bufferMinutes: 15,
          price: "180.00",
          currency: "LYD",
        },
        {
          organizationId: orgMed.id,
          branchId: branchMed1.id,
          nameAr: "فحص الموجات فوق الصوتية للقلب (Echocardiogram)",
          descriptionAr: "تصوير متلفز عالي الدقة لعضلات وصمامات القلب بواسطة استشاري القلب المعتمد.",
          durationMinutes: 40,
          bufferMinutes: 10,
          price: "220.00",
          currency: "LYD",
        },

        // Events Services (Al-Andalus)
        {
          organizationId: orgEvents.id,
          branchId: branchEvents1.id,
          nameAr: "حجز القاعة الكبرى الملكية لحفل الزفاف (شامل الضيافة)",
          descriptionAr:
            "سعة حتى 600 ضيفة، كوشة عصرية من أحدث التصاميم، بوفيه عشاء مفتوح فاخر، ومباشرات ومشرفة تنظيم طوال السهرة.",
          durationMinutes: 360,
          bufferMinutes: 60,
          price: "6500.00",
          depositAmount: "1000.00",
          currency: "LYD",
        },
        {
          organizationId: orgEvents.id,
          branchId: branchEvents1.id,
          nameAr: "حجز قاعة المؤتمرات والاجتماعات للشركات (يوم عمل كامل)",
          descriptionAr:
            "مجهزة بشاشات عرض ذكية، نظام ترجمة فورية، فترتين استراحة شاي وقهوة وغداء عمل لـ 70 مشاركاً.",
          durationMinutes: 480,
          bufferMinutes: 30,
          price: "2400.00",
          depositAmount: "500.00",
          currency: "LYD",
        },

        // Hospitality Services (Remaal Zuwarah)
        {
          organizationId: orgHosp.id,
          branchId: branchHosp1.id,
          nameAr: "إيجار شاليه عائلي VIP مع مسبح خاص مدفأ (يوم كامل)",
          descriptionAr:
            "دخول من 12:00 ظهراً حتى 10:00 صباح اليوم التالي، صالة فسيحة، غرفتي نوم ماستر، حديقة خاصة وشواية باربيكيو.",
          durationMinutes: 1320,
          bufferMinutes: 120,
          price: "450.00",
          currency: "LYD",
        },
        {
          organizationId: orgHosp.id,
          branchId: branchHosp1.id,
          nameAr: "فيلا رويال شاطئية بـ 4 أجنحة ومسبح أولمبي للأعياد",
          descriptionAr: "مساحة 800 متر مربع على الشاطئ مباشرة مع خدمات حراسة وضيافة ونظافة مستمرة.",
          durationMinutes: 1440,
          bufferMinutes: 180,
          price: "850.00",
          currency: "LYD",
        },

        // Beauty & Spa (Orchid)
        {
          organizationId: orgWell.id,
          branchId: branchWell1.id,
          nameAr: "جلسة الحمام المغربي الملكي بالأعشاب والزيوت العطرية",
          descriptionAr: "تقشير بصابون بلدي مغربي، ماسك طين البحر الميت، وتدليك مائي دافئ للاسترخاء وإشراقة البشرة.",
          durationMinutes: 75,
          bufferMinutes: 15,
          price: "140.00",
          currency: "LYD",
        },
        {
          organizationId: orgWell.id,
          branchId: branchWell1.id,
          nameAr: "جلسة مساج علاجي واسترخائي بالأحجار الساخنة (60 دقيقة)",
          descriptionAr: "تخفيف الإجهاد العضلي والتوتر بأيدي أخصائيات معتمدات مع زيوت اللافندر والسمسم الطبيعية.",
          durationMinutes: 60,
          bufferMinutes: 15,
          price: "110.00",
          currency: "LYD",
        },
      ])
      .returning();

    // 8. Create Subscriptions for Organizations
    for (const org of insertedOrgs) {
      await db.insert(subscriptions).values({
        organizationId: org.id,
        planId: planPro.id,
        status: "ACTIVE",
        startDate: new Date(),
        renewalDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days
        isTrial: false,
      });

      // Initialize Organization Wallet
      await db.insert(wallets).values({
        organizationId: org.id,
        balance: "1850.00",
        pendingSettlement: "420.00",
        totalEarned: "7400.00",
        totalCommissionPaid: "370.00",
        totalPaidOut: "5180.00",
        currency: "LYD",
      });
    }

    // 9. Create Real Sample Bookings & Ledger Entries
    const srv1 = insertedServices[0]; // Medical Cardo
    const srv2 = insertedServices[3]; // Wedding Hall

    const [b1] = await db
      .insert(bookings)
      .values({
        bookingRef: "RBT-2025-1082",
        organizationId: srv1.organizationId,
        branchId: srv1.branchId || branchMed1.id,
        serviceId: srv1.id,
        staffId: staffDoctor1.id,
        customerId: customer1.id,
        customerName: customer1.fullName,
        customerPhone: customer1.phone,
        customerEmail: customer1.email,
        bookingDate: "2025-05-18",
        startTime: "16:00",
        endTime: "16:45",
        price: srv1.price,
        customerFee: "3.00",
        discountAmount: "0.00",
        totalPrice: "123.00",
        commissionPercent: "5.00",
        platformFee: "6.00", // 5% of 120
        providerNet: "114.00",
        currency: "LYD",
        status: BookingStatus.CONFIRMED,
        paymentStatus: PaymentStatus.PAID,
        paymentMethod: "ONLINE",
        notes: "المريض يطلب مراجعة الفحوصات والتحاليل الأخيرة الصادرة من مختبر الشفاء",
      })
      .returning();

    const [b2] = await db
      .insert(bookings)
      .values({
        bookingRef: "RBT-2025-1083",
        organizationId: srv2.organizationId,
        branchId: srv2.branchId || branchEvents1.id,
        serviceId: srv2.id,
        staffId: staffEventsMgr.id,
        customerId: customer2.id,
        customerName: customer2.fullName,
        customerPhone: customer2.phone,
        customerEmail: customer2.email,
        bookingDate: "2025-06-25",
        startTime: "18:00",
        endTime: "23:59",
        price: srv2.price,
        customerFee: "25.00",
        discountAmount: "0.00",
        totalPrice: "6525.00",
        commissionPercent: "5.00",
        platformFee: "325.00",
        providerNet: "6175.00",
        currency: "LYD",
        status: BookingStatus.CONFIRMED,
        paymentStatus: PaymentStatus.PAID,
        paymentMethod: "ONLINE",
        notes: "حفل زفاف عائلي، تم الاتفاق على بوفيه رقم 2 وتنسيق كوشة الورود البيضاء",
      })
      .returning();

    // 10. Ledger Entries for Financial Auditability
    await db.insert(ledgerEntries).values([
      {
        organizationId: orgMed.id,
        bookingId: b1.id,
        transactionType: "BOOKING_PAYMENT",
        grossAmount: "120.00",
        platformFee: "6.00",
        netAmount: "114.00",
        currency: "LYD",
        description: `تسوية حجز مؤكد ${b1.bookingRef} لخدمة ${srv1.nameAr}`,
        reference: b1.bookingRef,
      },
      {
        organizationId: orgEvents.id,
        bookingId: b2.id,
        transactionType: "BOOKING_PAYMENT",
        grossAmount: "6500.00",
        platformFee: "325.00",
        netAmount: "6175.00",
        currency: "LYD",
        description: `تسوية حجز مؤكد ${b2.bookingRef} لخدمة ${srv2.nameAr}`,
        reference: b2.bookingRef,
      },
    ]);

    // 11. Customer Reviews
    await db.insert(reviews).values([
      {
        organizationId: orgMed.id,
        bookingId: b1.id,
        customerId: customer1.id,
        rating: 5,
        comment:
          "تجربة ممتازة جداً، الدكتور طارق استمع لي بدقة فائقة والمصحة في قمة النظافة والالتزام بالمواعيد بدون أي انتظار.",
        replyFromProvider: "شكراً لثقتكم بمصحة قرطبة، نسأل الله لكم دوام الصحة والعافية.",
        isPublished: true,
      },
      {
        organizationId: orgEvents.id,
        bookingId: b2.id,
        customerId: customer2.id,
        rating: 5,
        comment:
          "أجمل صالة مناسبات في مصراتة، تنظيم راقٍ جداً وإضاءة رائعة أبهرت جميع الضيوف، شكراً لمنصة رابط على سهولة الحجز.",
        isPublished: true,
      },
    ]);

    // 12. System Settings & Audit Log
    await db.insert(systemSettings).values([
      { key: "PLATFORM_NAME", value: "رابط للحجوزات – Rabit Bookings" },
      { key: "DEFAULT_CURRENCY", value: "LYD" },
      { key: "CUSTOMER_SERVICE_FEE_ENABLED", value: "true" },
      { key: "CUSTOMER_SERVICE_FEE_PERCENT", value: "2.00" },
      { key: "ALLOW_INSTANT_BOOKING", value: "true" },
      { key: "SMS_NOTIFICATIONS_ENABLED", value: "true" },
      { key: "WHATSAPP_REMINDERS_ENABLED", value: "true" },
    ]);

    await db.insert(auditLogs).values({
      userId: adminUser.id,
      action: "PLATFORM_INITIALIZATION",
      entity: "SYSTEM",
      entityId: "1",
      oldValue: null,
      newValue: "System bootstrapped successfully with Multi-Tenant architecture and seed records",
      ipAddress: "127.0.0.1",
    });

    console.log("✅ Seed completed successfully with verified users, organizations, services, and ledger entries!");
  } catch (error) {
    console.error("❌ Seeding Error:", error);
  }
}

/**
 * DEVELOPMENT SEED ONLY. Skipped automatically when NODE_ENV=production and SEED_DEMO!=true.
 */
export async function seedDatabase() {
  if (process.env.SEED_DEMO === "false") {
    await ensureMainCategories(); // real production: categories only
    return;
  }
  await seedCore();
  await seedRolesVipWallet();
  await ensureMainCategories();
  await seedMarketplace();
}

let v2Done = false;
async function seedRolesVipWallet() {
  if (v2Done) return;
  const existing = await db.select().from(vipTiers).limit(1);
  if (existing.length > 0) {
    v2Done = true;
    return;
  }
  const hash = await bcrypt.hash("123456", 10);

  // Super Admin (separate from platform admin)
  const [superAdmin] = await db
    .insert(users)
    .values({ role: UserRole.SUPER_ADMIN, fullName: "الإدارة العليا – رابط", phone: "+218910000001", passwordHash: hash })
    .onConflictDoNothing()
    .returning();

  // Staff users for Qurtuba clinic with limited permissions
  const [org] = await db.select().from(organizations).where(eq(organizations.slug, "qurtuba-clinic"));
  if (org) {
    const [reception] = await db.insert(users).values({ role: UserRole.STAFF, fullName: "أحمد الترهوني", phone: "+218920000002", passwordHash: hash }).onConflictDoNothing().returning();
    const [finance] = await db.insert(users).values({ role: UserRole.STAFF, fullName: "سارة المحاسبة", phone: "+218920000003", passwordHash: hash }).onConflictDoNothing().returning();
    if (reception)
      await db.insert(staff).values({ organizationId: org.id, userId: reception.id, fullName: reception.fullName, titleAr: "موظف استقبال", roleTitle: "استقبال", phone: reception.phone,
        permissionsJson: JSON.stringify(["bookings.view", "bookings.create", "bookings.edit", "bookings.checkin", "customers.view"]) });
    if (finance)
      await db.insert(staff).values({ organizationId: org.id, userId: finance.id, fullName: finance.fullName, titleAr: "موظفة مالية", roleTitle: "مالي", phone: finance.phone,
        permissionsJson: JSON.stringify(["finance.view", "reports.view", "bookings.view"]) });
  }

  // VIP tiers + admin-controllable benefits
  const [vip] = await db.insert(vipTiers).values({ slug: "vip", nameAr: "VIP", level: 1, priceLyd: "99.00", durationDays: 365 }).returning();
  const [vipPlus] = await db.insert(vipTiers).values({ slug: "vip-plus", nameAr: "VIP Plus", level: 2, priceLyd: "199.00", durationDays: 365 }).returning();
  const benefitRows = (tierId: number, fee: string, bonus: string) => [
    { tierId, key: VipBenefitKey.FEE_DISCOUNT_PERCENT, titleAr: "خصم على رسوم الحجز (%)", value: fee },
    { tierId, key: VipBenefitKey.RECHARGE_BONUS_PERCENT, titleAr: "مكافأة على شحن المحفظة (%)", value: bonus },
    { tierId, key: VipBenefitKey.EXCLUSIVE_OFFERS, titleAr: "عروض حصرية لأعضاء VIP", value: "0" },
    { tierId, key: VipBenefitKey.EARLY_ACCESS, titleAr: "وصول مبكر للعروض الموسمية", value: "0" },
    { tierId, key: VipBenefitKey.PRIORITY_BOOKING, titleAr: "أولوية في بعض الحجوزات", value: "0", isActive: false },
  ];
  await db.insert(vipBenefits).values([...benefitRows(vip.id, "50", "5"), ...benefitRows(vipPlus.id, "100", "10")]);

  // Customer wallets via ledger (never set balance directly)
  const [c1] = await db.select().from(users).where(eq(users.phone, "+218914441122"));
  const [c2] = await db.select().from(users).where(eq(users.phone, "+218923337788"));
  for (const c of [c1, c2].filter(Boolean)) {
    await db.transaction((tx) => applyWalletTx(tx, { userId: c.id, type: WalletTxType.BONUS, amount: 250, source: "CAMPAIGN", note: "رصيد ترحيبي (بيئة التطوير)" }));
  }
  if (c1) {
    await db.insert(vipMemberships).values({ userId: c1.id, tierId: vip.id, endsAt: new Date(Date.now() + 300 * 86400000), grantedBy: superAdmin?.id ?? null });
  }

  await db.insert(walletCampaigns).values({ titleAr: "اشحن 100 د.ل واحصل على 10 د.ل", minRecharge: "100.00", bonusAmount: "10.00" });

  // Demo card batch – dev codes are deterministic ONLY in development so testers can redeem them.
  const creator = superAdmin?.id ?? c1?.id;
  if (creator) {
    const [batch] = await db.insert(rechargeBatches).values({ batchRef: "B-DEV-001", faceValue: "50.00", quantity: 3, createdBy: creator }).returning();
    const devCodes = ["RBT2-DEMO-CARD-0050", "RBT2-DEMO-CARD-0051", "RBT2-DEMO-CARD-0052"];
    await db.insert(rechargeCards).values(
      devCodes.map((code, i) => ({ batchId: batch.id, codeHash: hashCardCode(code), last4: normalizeCode(code).slice(-4), serial: `B-DEV-001-0000${i + 1}`, value: "50.00" }))
    );
  }
  v2Done = true;
  console.log("✅ Roles/VIP/Wallet dev seed complete");
}

/** The 15 main categories (idempotent). Emoji stored in `icon`. Admin can edit/disable later. */
const MAIN_CATEGORIES = [
  { slug: "hotels", nameAr: "فنادق وإقامة", nameEn: "Hotels & Stays", icon: "🏨" },
  { slug: "hospitality", nameAr: "منتجعات واستراحات", nameEn: "Resorts & Chalets", icon: "🏖️" },
  { slug: "sports", nameAr: "رياضة وملاعب", nameEn: "Sports & Fields", icon: "⚽" },
  { slug: "events", nameAr: "أفراح ومناسبات", nameEn: "Weddings & Events", icon: "💍" },
  { slug: "medical", nameAr: "صحة وطب", nameEn: "Health & Medical", icon: "🏥" },
  { slug: "wellness", nameAr: "جمال وعناية", nameEn: "Beauty & Care", icon: "💆" },
  { slug: "restaurants", nameAr: "مطاعم ومقاهي", nameEn: "Restaurants & Cafes", icon: "🍽️" },
  { slug: "cars", nameAr: "سيارات ونقل", nameEn: "Cars & Transport", icon: "🚗" },
  { slug: "travel", nameAr: "سفر وسياحة", nameEn: "Travel & Tourism", icon: "✈️" },
  { slug: "entertainment", nameAr: "ترفيه وأنشطة", nameEn: "Entertainment", icon: "🎮" },
  { slug: "business", nameAr: "أعمال واجتماعات", nameEn: "Business & Meetings", icon: "🏢" },
  { slug: "photography", nameAr: "تصوير وإنتاج", nameEn: "Photo & Production", icon: "📸" },
  { slug: "kids", nameAr: "أطفال وعائلات", nameEn: "Kids & Family", icon: "👶" },
  { slug: "education", nameAr: "تعليم وتدريب", nameEn: "Education & Training", icon: "🎓" },
  { slug: "tickets", nameAr: "فعاليات وتذاكر", nameEn: "Events & Tickets", icon: "🎟️" },
];

let catsDone = false;
export async function ensureMainCategories() {
  if (catsDone) return;
  for (let i = 0; i < MAIN_CATEGORIES.length; i++) {
    const c = MAIN_CATEGORIES[i];
    await db
      .insert(categories)
      .values({ ...c, descriptionAr: c.nameAr, displayOrder: i + 1 })
      .onConflictDoUpdate({ target: categories.slug, set: { nameAr: c.nameAr, nameEn: c.nameEn, icon: c.icon, displayOrder: i + 1 } });
  }
  catsDone = true;
}

export { ensureBusTrips };
