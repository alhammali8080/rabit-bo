import {
  pgTable,
  text,
  serial,
  timestamp,
  integer,
  numeric,
  boolean,
  date,
  time,
  uniqueIndex,
  index,
} from "drizzle-orm/pg-core";

// ==========================================
// 1. USERS & ROLES
// ==========================================

export const UserRole = {
  CUSTOMER: "CUSTOMER",
  PROVIDER_OWNER: "PROVIDER_OWNER",
  PROVIDER_MANAGER: "PROVIDER_MANAGER",
  STAFF: "STAFF",
  PLATFORM_ADMIN: "PLATFORM_ADMIN",
  SUPPORT_AGENT: "SUPPORT_AGENT",
  SUPER_ADMIN: "SUPER_ADMIN",
} as const;

export type UserRoleType = (typeof UserRole)[keyof typeof UserRole];

export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    role: text("role").default(UserRole.CUSTOMER).notNull(),
    fullName: text("full_name").notNull(),
    phone: text("phone").notNull().unique(),
    email: text("email").unique(),
    passwordHash: text("password_hash").notNull(),
    avatarUrl: text("avatar_url"),
    city: text("city").default("طرابلس").notNull(),
    isActive: boolean("is_active").default(true).notNull(),
    isPhoneVerified: boolean("is_phone_verified").default(true).notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (table) => [
    index("users_role_idx").on(table.role),
    index("users_phone_idx").on(table.phone),
  ]
);

// ==========================================
// 2. SECTORS / CATEGORIES
// ==========================================

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  nameAr: text("name_ar").notNull(),
  nameEn: text("name_en").notNull(),
  descriptionAr: text("description_ar").notNull(),
  icon: text("icon").notNull(), // Lucide icon identifier
  defaultCommissionPercent: numeric("default_commission_percent", { precision: 5, scale: 2 }).default("7.00").notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  displayOrder: integer("display_order").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ==========================================
// 3. ORGANIZATIONS / PROVIDERS (Tenants)
// ==========================================

export const ProviderStatus = {
  PENDING: "PENDING",
  UNDER_REVIEW: "UNDER_REVIEW",
  VERIFIED: "VERIFIED",
  REJECTED: "REJECTED",
  SUSPENDED: "SUSPENDED",
} as const;

export const organizations = pgTable(
  "organizations",
  {
    id: serial("id").primaryKey(),
    ownerId: integer("owner_id").references(() => users.id).notNull(),
    categoryId: integer("category_id").references(() => categories.id).notNull(),
    nameAr: text("name_ar").notNull(),
    nameEn: text("name_en"),
    slug: text("slug").notNull().unique(),
    subtitleAr: text("subtitle_ar").notNull(),
    descriptionAr: text("description_ar").notNull(),
    city: text("city").default("طرابلس").notNull(),
    primaryAddress: text("primary_address").notNull(),
    phone: text("phone").notNull(),
    email: text("email").notNull(),
    logoUrl: text("logo_url"),
    coverUrl: text("cover_url"),
    status: text("status").default(ProviderStatus.VERIFIED).notNull(),
    rating: numeric("rating", { precision: 3, scale: 2 }).default("5.00").notNull(),
    reviewsCount: integer("reviews_count").default(0).notNull(),
    isFeatured: boolean("is_featured").default(false).notNull(),
    featuredExpiry: timestamp("featured_expiry"),
    customCommissionPercent: numeric("custom_commission_percent", { precision: 5, scale: 2 }), // Override category default if set
    cancellationPolicyAr: text("cancellation_policy_ar").default("إلغاء مجاني حتى 24 ساعة قبل الموعد").notNull(),
    requireDeposit: boolean("require_deposit").default(false).notNull(),
    depositPercent: numeric("deposit_percent", { precision: 5, scale: 2 }).default("0.00"),
    currency: text("currency").default("LYD").notNull(),
    allowInstantBooking: boolean("allow_instant_booking").default(true).notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (table) => [
    index("orgs_category_idx").on(table.categoryId),
    index("orgs_city_idx").on(table.city),
    index("orgs_slug_idx").on(table.slug),
  ]
);

// ==========================================
// 4. BRANCHES
// ==========================================

export const branches = pgTable("branches", {
  id: serial("id").primaryKey(),
  organizationId: integer("organization_id").references(() => organizations.id).notNull(),
  nameAr: text("name_ar").notNull(),
  city: text("city").notNull(),
  district: text("district").notNull(),
  address: text("address").notNull(),
  phone: text("phone").notNull(),
  isMain: boolean("is_main").default(false).notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  openingTime: text("opening_time").default("09:00").notNull(),
  closingTime: text("closing_time").default("21:00").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ==========================================
// 5. STAFF / EMPLOYEES
// ==========================================

export const staff = pgTable("staff", {
  id: serial("id").primaryKey(),
  organizationId: integer("organization_id").references(() => organizations.id).notNull(),
  branchId: integer("branch_id").references(() => branches.id),
  userId: integer("user_id").references(() => users.id), // If mapped to user login
  fullName: text("full_name").notNull(),
  titleAr: text("title_ar").notNull(), // e.g. "استشاري جراحة" / "منسق حفلات"
  phone: text("phone"),
  email: text("email"),
  avatarUrl: text("avatar_url"),
  roleTitle: text("role_title").default("موظف").notNull(), // e.g. استقبال / مالي
  permissionsJson: text("permissions_json").default("[]").notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ==========================================
// 6. SERVICES
// ==========================================

export const services = pgTable("services", {
  id: serial("id").primaryKey(),
  organizationId: integer("organization_id").references(() => organizations.id).notNull(),
  branchId: integer("branch_id").references(() => branches.id),
  nameAr: text("name_ar").notNull(),
  descriptionAr: text("description_ar").notNull(),
  durationMinutes: integer("duration_minutes").default(60).notNull(),
  bufferMinutes: integer("buffer_minutes").default(15).notNull(),
  price: numeric("price", { precision: 10, scale: 2 }).notNull(),
  depositAmount: numeric("deposit_amount", { precision: 10, scale: 2 }).default("0.00").notNull(),
  currency: text("currency").default("LYD").notNull(),
  requireApproval: boolean("require_approval").default(false).notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  customCommissionPercent: numeric("custom_commission_percent", { precision: 5, scale: 2 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const serviceStaff = pgTable("service_staff", {
  id: serial("id").primaryKey(),
  serviceId: integer("service_id").references(() => services.id).notNull(),
  staffId: integer("staff_id").references(() => staff.id).notNull(),
});

// ==========================================
// 7. BOOKINGS & SCHEDULE (Calendar Engine)
// ==========================================

export const BookingStatus = {
  PENDING: "PENDING",
  CONFIRMED: "CONFIRMED",
  CANCELLED: "CANCELLED",
  COMPLETED: "COMPLETED",
  NO_SHOW: "NO_SHOW",
  REJECTED: "REJECTED",
  RESCHEDULED: "RESCHEDULED",
} as const;

export const PaymentStatus = {
  PENDING: "PENDING",
  PAID: "PAID",
  PAY_AT_VENUE: "PAY_AT_VENUE",
  REFUNDED: "REFUNDED",
  FAILED: "FAILED",
} as const;

export const bookings = pgTable(
  "bookings",
  {
    id: serial("id").primaryKey(),
    bookingRef: text("booking_ref").notNull().unique(), // e.g. RBT-2025-1082
    organizationId: integer("organization_id").references(() => organizations.id).notNull(),
    branchId: integer("branch_id").references(() => branches.id).notNull(),
    serviceId: integer("service_id").references(() => services.id).notNull(),
    staffId: integer("staff_id").references(() => staff.id),
    customerId: integer("customer_id").references(() => users.id),
    customerName: text("customer_name").notNull(),
    customerPhone: text("customer_phone").notNull(),
    customerEmail: text("customer_email"),
    bookingDate: text("booking_date").notNull(), // YYYY-MM-DD
    startTime: text("start_time").notNull(), // HH:mm (e.g. "14:00")
    endTime: text("end_time").notNull(), // HH:mm (e.g. "15:00")
    
    // Financial Breakdown
    price: numeric("price", { precision: 10, scale: 2 }).notNull(),
    customerFee: numeric("customer_fee", { precision: 10, scale: 2 }).default("0.00").notNull(),
    discountAmount: numeric("discount_amount", { precision: 10, scale: 2 }).default("0.00").notNull(),
    totalPrice: numeric("total_price", { precision: 10, scale: 2 }).notNull(),
    commissionPercent: numeric("commission_percent", { precision: 5, scale: 2 }).notNull(),
    platformFee: numeric("platform_fee", { precision: 10, scale: 2 }).notNull(),
    providerNet: numeric("provider_net", { precision: 10, scale: 2 }).notNull(),
    currency: text("currency").default("LYD").notNull(),

    status: text("status").default(BookingStatus.CONFIRMED).notNull(),
    paymentStatus: text("payment_status").default(PaymentStatus.PAID).notNull(),
    paymentMethod: text("payment_method").default("ONLINE").notNull(), // ONLINE, CASH_AT_VENUE, WALLET
    cancellationReason: text("cancellation_reason"),
    notes: text("notes"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (table) => [
    index("bookings_org_date_idx").on(table.organizationId, table.bookingDate),
    index("bookings_customer_idx").on(table.customerId),
    index("bookings_status_idx").on(table.status),
    // Slot protection index to prevent double bookings on same service & branch & slot when active
    uniqueIndex("unique_active_slot_idx").on(
      table.organizationId,
      table.branchId,
      table.bookingDate,
      table.startTime,
      table.status
    ),
  ]
);

// ==========================================
// 8. FINANCIAL LEDGER & WALLET
// ==========================================

export const wallets = pgTable("wallets", {
  id: serial("id").primaryKey(),
  organizationId: integer("organization_id").references(() => organizations.id).notNull().unique(),
  balance: numeric("balance", { precision: 12, scale: 2 }).default("0.00").notNull(),
  pendingSettlement: numeric("pending_settlement", { precision: 12, scale: 2 }).default("0.00").notNull(),
  totalEarned: numeric("total_earned", { precision: 12, scale: 2 }).default("0.00").notNull(),
  totalCommissionPaid: numeric("total_commission_paid", { precision: 12, scale: 2 }).default("0.00").notNull(),
  totalPaidOut: numeric("total_paid_out", { precision: 12, scale: 2 }).default("0.00").notNull(),
  currency: text("currency").default("LYD").notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const ledgerEntries = pgTable(
  "ledger_entries",
  {
    id: serial("id").primaryKey(),
    organizationId: integer("organization_id").references(() => organizations.id).notNull(),
    bookingId: integer("bookingId").references(() => bookings.id),
    transactionType: text("transaction_type").notNull(), // BOOKING_PAYMENT, COMMISSION_DEDUCTION, PAYOUT, REFUND, SUBSCRIPTION_FEE
    grossAmount: numeric("gross_amount", { precision: 10, scale: 2 }).notNull(),
    platformFee: numeric("platform_fee", { precision: 10, scale: 2 }).default("0.00").notNull(),
    netAmount: numeric("net_amount", { precision: 10, scale: 2 }).notNull(),
    currency: text("currency").default("LYD").notNull(),
    description: text("description").notNull(),
    reference: text("reference").notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => [
    index("ledger_org_idx").on(table.organizationId),
    index("ledger_type_idx").on(table.transactionType),
  ]
);

export const payouts = pgTable("payouts", {
  id: serial("id").primaryKey(),
  payoutRef: text("payout_ref").notNull().unique(), // e.g. PO-LYD-1029
  organizationId: integer("organization_id").references(() => organizations.id).notNull(),
  amount: numeric("amount", { precision: 10, scale: 2 }).notNull(),
  currency: text("currency").default("LYD").notNull(),
  status: text("status").default("COMPLETED").notNull(), // PENDING, PROCESSING, COMPLETED, REJECTED
  bankDetails: text("bank_details").notNull(),
  processedByUserId: integer("processed_by_user_id").references(() => users.id),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ==========================================
// 9. SUBSCRIPTIONS & PLANS
// ==========================================

export const subscriptionPlans = pgTable("subscription_plans", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(), // free, pro, enterprise
  nameAr: text("name_ar").notNull(),
  monthlyPrice: numeric("monthly_price", { precision: 10, scale: 2 }).notNull(),
  yearlyPrice: numeric("yearly_price", { precision: 10, scale: 2 }).notNull(),
  currency: text("currency").default("LYD").notNull(),
  maxBranches: integer("max_branches").default(1).notNull(),
  maxStaff: integer("max_staff").default(3).notNull(),
  commissionRate: numeric("commission_rate", { precision: 5, scale: 2 }).default("7.00").notNull(),
  featuresJson: text("features_json").notNull(), // JSON string array of features
  isActive: boolean("is_active").default(true).notNull(),
});

export const subscriptions = pgTable("subscriptions", {
  id: serial("id").primaryKey(),
  organizationId: integer("organization_id").references(() => organizations.id).notNull().unique(),
  planId: integer("plan_id").references(() => subscriptionPlans.id).notNull(),
  status: text("status").default("ACTIVE").notNull(), // TRIAL, ACTIVE, PAST_DUE, CANCELLED
  startDate: timestamp("start_date").defaultNow().notNull(),
  renewalDate: timestamp("renewal_date").notNull(),
  isTrial: boolean("is_trial").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ==========================================
// 10. REVIEWS & RATINGS
// ==========================================

export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  organizationId: integer("organization_id").references(() => organizations.id).notNull(),
  bookingId: integer("booking_id").references(() => bookings.id).notNull(),
  customerId: integer("customer_id").references(() => users.id).notNull(),
  rating: integer("rating").notNull(), // 1 to 5
  comment: text("comment").notNull(),
  replyFromProvider: text("reply_from_provider"),
  isPublished: boolean("is_published").default(true).notNull(),
  isReported: boolean("is_reported").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ==========================================
// 11. NOTIFICATIONS
// ==========================================

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  organizationId: integer("organization_id").references(() => organizations.id),
  titleAr: text("title_ar").notNull(),
  bodyAr: text("body_ar").notNull(),
  type: text("type").notNull(), // BOOKING_CONFIRMED, REMINDER, PAYMENT_RECEIVED, CANCELLED, SYSTEM
  actionUrl: text("action_url"),
  isRead: boolean("is_read").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ==========================================
// 12. AUDIT LOGS
// ==========================================

export const auditLogs = pgTable(
  "audit_logs",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").references(() => users.id),
    action: text("action").notNull(),
    entity: text("entity").notNull(), // BOOKING, COMMISSION, PROVIDER, SUBSCRIPTION, SETTINGS
    entityId: text("entity_id"),
    oldValue: text("old_value"),
    newValue: text("new_value"),
    ipAddress: text("ip_address"),
    userAgent: text("user_agent"),
    result: text("result").default("SUCCESS").notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => [
    index("audit_entity_idx").on(table.entity),
    index("audit_created_idx").on(table.createdAt),
  ]
);

// ==========================================
// 13. SYSTEM SETTINGS & FEATURE FLAGS
// ==========================================

export const systemSettings = pgTable("system_settings", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  value: text("value").notNull(),
  description: text("description"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// ==========================================
// 14. SUPPORT TICKETS
// ==========================================

export const supportTickets = pgTable("support_tickets", {
  id: serial("id").primaryKey(),
  ticketRef: text("ticket_ref").notNull().unique(), // TKT-1002
  userId: integer("user_id").references(() => users.id).notNull(),
  subject: text("subject").notNull(),
  category: text("category").notNull(), // BOOKING_ISSUE, PAYMENT_DISPUTE, TECHNICAL, INQUIRY
  status: text("status").default("OPEN").notNull(), // OPEN, IN_PROGRESS, RESOLVED, CLOSED
  priority: text("priority").default("NORMAL").notNull(), // LOW, NORMAL, HIGH, URGENT
  message: text("message").notNull(),
  adminReply: text("admin_reply"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// ==========================================
// 15. AUTH: OTP CODES & ATTEMPTS
// ==========================================

export const otpCodes = pgTable(
  "otp_codes",
  {
    id: serial("id").primaryKey(),
    phone: text("phone").notNull(),
    codeHash: text("code_hash").notNull(),
    attempts: integer("attempts").default(0).notNull(),
    consumed: boolean("consumed").default(false).notNull(),
    ipAddress: text("ip_address"),
    expiresAt: timestamp("expires_at").notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (t) => [index("otp_phone_idx").on(t.phone, t.createdAt)]
);

// ==========================================
// 16. VIP (membership, NOT a role)
// ==========================================

export const vipTiers = pgTable("vip_tiers", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(), // vip, vip-plus, premium, business-vip
  nameAr: text("name_ar").notNull(),
  level: integer("level").default(1).notNull(),
  priceLyd: numeric("price_lyd", { precision: 10, scale: 2 }).default("0.00").notNull(),
  durationDays: integer("duration_days").default(365).notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const VipBenefitKey = {
  FEE_DISCOUNT_PERCENT: "FEE_DISCOUNT_PERCENT", // discount on customer service fee
  RECHARGE_BONUS_PERCENT: "RECHARGE_BONUS_PERCENT", // bonus on card recharge
  EXCLUSIVE_OFFERS: "EXCLUSIVE_OFFERS",
  EARLY_ACCESS: "EARLY_ACCESS",
  PRIORITY_BOOKING: "PRIORITY_BOOKING",
  VIP_COUPONS: "VIP_COUPONS",
} as const;

export const vipBenefits = pgTable("vip_benefits", {
  id: serial("id").primaryKey(),
  tierId: integer("tier_id").references(() => vipTiers.id).notNull(),
  key: text("key").notNull(),
  titleAr: text("title_ar").notNull(),
  value: numeric("value", { precision: 10, scale: 2 }).default("0.00").notNull(),
  isActive: boolean("is_active").default(true).notNull(),
});

export const vipMemberships = pgTable(
  "vip_memberships",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").references(() => users.id).notNull(),
    tierId: integer("tier_id").references(() => vipTiers.id).notNull(),
    status: text("status").default("ACTIVE").notNull(), // ACTIVE, EXPIRED, CANCELLED
    startsAt: timestamp("starts_at").defaultNow().notNull(),
    endsAt: timestamp("ends_at").notNull(),
    grantedBy: integer("granted_by").references(() => users.id),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (t) => [index("vip_user_idx").on(t.userId)]
);

// ==========================================
// 17. CUSTOMER WALLET + LEDGER
// ==========================================

export const WalletTxType = {
  CREDIT: "CREDIT",
  DEBIT: "DEBIT",
  REFUND: "REFUND",
  BONUS: "BONUS",
  VIP_BONUS: "VIP_BONUS",
  ADJUSTMENT: "ADJUSTMENT",
  CARD_RECHARGE: "CARD_RECHARGE",
} as const;

export const userWallets = pgTable("user_wallets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull().unique(),
  balance: numeric("balance", { precision: 12, scale: 2 }).default("0.00").notNull(),
  currency: text("currency").default("LYD").notNull(),
  isFrozen: boolean("is_frozen").default(false).notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const walletTransactions = pgTable(
  "wallet_transactions",
  {
    id: serial("id").primaryKey(),
    txRef: text("tx_ref").notNull().unique(),
    userId: integer("user_id").references(() => users.id).notNull(),
    walletId: integer("wallet_id").references(() => userWallets.id).notNull(),
    type: text("type").notNull(),
    amount: numeric("amount", { precision: 12, scale: 2 }).notNull(), // signed
    balanceBefore: numeric("balance_before", { precision: 12, scale: 2 }).notNull(),
    balanceAfter: numeric("balance_after", { precision: 12, scale: 2 }).notNull(),
    source: text("source").notNull(), // CARD, BOOKING, CANCELLATION, ADMIN, CAMPAIGN, VIP
    reference: text("reference"),
    note: text("note"),
    status: text("status").default("COMPLETED").notNull(),
    actorId: integer("actor_id").references(() => users.id),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (t) => [index("wtx_user_idx").on(t.userId, t.createdAt)]
);

// ==========================================
// 18. PREPAID RECHARGE CARDS
// ==========================================

export const rechargeBatches = pgTable("recharge_batches", {
  id: serial("id").primaryKey(),
  batchRef: text("batch_ref").notNull().unique(),
  faceValue: numeric("face_value", { precision: 10, scale: 2 }).notNull(),
  quantity: integer("quantity").notNull(),
  currency: text("currency").default("LYD").notNull(),
  status: text("status").default("ACTIVE").notNull(), // ACTIVE, SUSPENDED, CANCELLED
  expiresAt: timestamp("expires_at"),
  createdBy: integer("created_by").references(() => users.id).notNull(),
  exportedCount: integer("exported_count").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const CardStatus = {
  UNUSED: "UNUSED",
  USED: "USED",
  EXPIRED: "EXPIRED",
  SUSPENDED: "SUSPENDED",
  CANCELLED: "CANCELLED",
} as const;

export const rechargeCards = pgTable(
  "recharge_cards",
  {
    id: serial("id").primaryKey(),
    batchId: integer("batch_id").references(() => rechargeBatches.id).notNull(),
    codeHash: text("code_hash").notNull().unique(), // HMAC-SHA256, plaintext never stored
    last4: text("last4").notNull(),
    serial: text("serial").notNull().unique(),
    value: numeric("value", { precision: 10, scale: 2 }).notNull(),
    status: text("status").default(CardStatus.UNUSED).notNull(),
    usedBy: integer("used_by").references(() => users.id),
    usedAt: timestamp("used_at"),
    expiresAt: timestamp("expires_at"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (t) => [index("cards_batch_idx").on(t.batchId, t.status)]
);

export const rechargeAttempts = pgTable(
  "recharge_attempts",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").references(() => users.id),
    ipAddress: text("ip_address"),
    success: boolean("success").notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (t) => [index("ratt_user_idx").on(t.userId, t.createdAt), index("ratt_ip_idx").on(t.ipAddress, t.createdAt)]
);

export const walletCampaigns = pgTable("wallet_campaigns", {
  id: serial("id").primaryKey(),
  titleAr: text("title_ar").notNull(),
  minRecharge: numeric("min_recharge", { precision: 10, scale: 2 }).notNull(),
  bonusAmount: numeric("bonus_amount", { precision: 10, scale: 2 }).notNull(),
  vipOnly: boolean("vip_only").default(false).notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  endsAt: timestamp("ends_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ==========================================
// 19. HEALTH CARE REQUESTS (advisor-led flow, Pacific Prime style)
// ==========================================

export const careRequests = pgTable(
  "care_requests",
  {
    id: serial("id").primaryKey(),
    requestRef: text("request_ref").notNull().unique(),
    userId: integer("user_id").references(() => users.id),
    fullName: text("full_name").notNull(),
    phone: text("phone").notNull(),
    needType: text("need_type").notNull(),
    forWhom: text("for_whom").notNull(), // SELF, FAMILY, CHILD, PARENT
    age: integer("age"),
    city: text("city").notNull(),
    budget: text("budget"),
    preferredDate: text("preferred_date"),
    notes: text("notes"),
    status: text("status").default("NEW").notNull(), // NEW, CONTACTED, BOOKED, CLOSED
    assignedTo: integer("assigned_to").references(() => users.id),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (t) => [index("care_status_idx").on(t.status, t.createdAt)]
);

// ==========================================
// 20. AD BANNERS (admin-managed hero slots)
// ==========================================

export const banners = pgTable("banners", {
  id: serial("id").primaryKey(),
  titleAr: text("title_ar").notNull(),
  subtitleAr: text("subtitle_ar").notNull(),
  badgeAr: text("badge_ar"),
  imageUrl: text("image_url").notNull(),
  ctaLabel: text("cta_label").notNull(),
  href: text("href").notNull(),
  isSponsored: boolean("is_sponsored").default(true).notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  displayOrder: integer("display_order").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ==========================================
// 21. EVENTS & TICKETS (matches, concerts...)
// ==========================================

export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  titleAr: text("title_ar").notNull(),
  subtitleAr: text("subtitle_ar"),
  kind: text("kind").default("MATCH").notNull(), // MATCH, CONCERT, FESTIVAL, CONFERENCE
  venueAr: text("venue_ar").notNull(),
  city: text("city").notNull(),
  eventDate: text("event_date").notNull(),
  eventTime: text("event_time").notNull(),
  imageUrl: text("image_url").notNull(),
  homeTeam: text("home_team"),
  awayTeam: text("away_team"),
  descriptionAr: text("description_ar"),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const ticketTiers = pgTable("ticket_tiers", {
  id: serial("id").primaryKey(),
  eventId: integer("event_id").references(() => events.id).notNull(),
  nameAr: text("name_ar").notNull(), // الدرجة الأولى، VIP، المدرجات
  price: numeric("price", { precision: 10, scale: 2 }).notNull(),
  capacity: integer("capacity").notNull(),
  sold: integer("sold").default(0).notNull(),
  maxPerOrder: integer("max_per_order").default(6).notNull(),
});

export const ticketOrders = pgTable(
  "ticket_orders",
  {
    id: serial("id").primaryKey(),
    orderRef: text("order_ref").notNull().unique(),
    eventId: integer("event_id").references(() => events.id).notNull(),
    tierId: integer("tier_id").references(() => ticketTiers.id).notNull(),
    userId: integer("user_id").references(() => users.id).notNull(),
    quantity: integer("quantity").notNull(),
    unitPrice: numeric("unit_price", { precision: 10, scale: 2 }).notNull(),
    fee: numeric("fee", { precision: 10, scale: 2 }).notNull(),
    total: numeric("total", { precision: 10, scale: 2 }).notNull(),
    status: text("status").default("PAID").notNull(), // PAID, CANCELLED, USED
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (t) => [index("tickets_user_idx").on(t.userId)]
);

// ==========================================
// 22. INTERCITY BUS TRANSPORT
// ==========================================

export const busTrips = pgTable(
  "bus_trips",
  {
    id: serial("id").primaryKey(),
    operatorId: integer("operator_id").references(() => organizations.id).notNull(),
    fromCity: text("from_city").notNull(),
    toCity: text("to_city").notNull(),
    tripDate: text("trip_date").notNull(),
    departTime: text("depart_time").notNull(),
    arriveTime: text("arrive_time").notNull(),
    busType: text("bus_type").default("VIP").notNull(), // VIP (2+1), STANDARD (2+2)
    seatCount: integer("seat_count").default(40).notNull(),
    price: numeric("price", { precision: 10, scale: 2 }).notNull(),
    amenities: text("amenities").default("[]").notNull(),
    stationAr: text("station_ar").notNull(),
    isActive: boolean("is_active").default(true).notNull(),
  },
  (t) => [index("bus_route_idx").on(t.fromCity, t.toCity, t.tripDate)]
);

export const busSeats = pgTable(
  "bus_seats",
  {
    id: serial("id").primaryKey(),
    tripId: integer("trip_id").references(() => busTrips.id).notNull(),
    seatNo: integer("seat_no").notNull(),
    bookingRef: text("booking_ref").notNull(),
    userId: integer("user_id").references(() => users.id).notNull(),
    passengerName: text("passenger_name").notNull(),
    price: numeric("price", { precision: 10, scale: 2 }).notNull(),
    status: text("status").default("BOOKED").notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  // DB-level protection: a seat on a trip can only be booked once
  (t) => [uniqueIndex("bus_seat_unique").on(t.tripId, t.seatNo), index("bus_seats_user_idx").on(t.userId)]
);
