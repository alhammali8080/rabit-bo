"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import {
  Stethoscope, Smile, FlaskConical, HeartPulse, Scissors, Sparkles, HelpCircle, User, Users, Baby, HeartHandshake,
  ShieldCheck, Clock, Headphones, CheckCircle2, Star, MapPin, ArrowLeft, ArrowRight, Phone,
} from "lucide-react";
import SiteHeader from "@/components/site/SiteHeader";
import BookingSheet, { type Org, type Srv, type Branch } from "@/components/BookingSheet";
import { Btn, inputCls, lyd, postJson, useApi } from "@/components/ui";

const NEEDS = [
  { key: "CONSULT", label: "كشف استشاري", icon: Stethoscope, words: ["كشف", "استشاري"] },
  { key: "DENTAL", label: "الأسنان", icon: Smile, words: ["أسنان", "الأسنان"] },
  { key: "LAB", label: "تحاليل وأشعة", icon: FlaskConical, words: ["تحليل", "تحاليل", "أشعة", "موجات", "فحص"] },
  { key: "CHECKUP", label: "فحص شامل", icon: HeartPulse, words: ["فحص", "شامل", "تخطيط"] },
  { key: "SURGERY", label: "جراحة يوم واحد", icon: Scissors, words: ["جراحة", "عملية"] },
  { key: "DERMA", label: "جلدية وتجميل", icon: Sparkles, words: ["بشرة", "جلدية", "ليزر", "تجميل"] },
  { key: "OTHER", label: "غير متأكد", icon: HelpCircle, words: [] },
];
const WHO = [
  { key: "SELF", label: "لنفسي", icon: User },
  { key: "FAMILY", label: "للعائلة", icon: Users },
  { key: "CHILD", label: "لطفل", icon: Baby },
  { key: "PARENT", label: "لأحد الوالدين", icon: HeartHandshake },
];
const BUDGETS = [
  { key: "", label: "أي ميزانية", max: Infinity },
  { key: "100", label: "حتى 100 د.ل", max: 100 },
  { key: "250", label: "حتى 250 د.ل", max: 250 },
  { key: "500", label: "حتى 500 د.ل", max: 500 },
];

interface Data { categories: { id: number; slug: string }[]; organizations: Org[]; services: Srv[]; branches: Branch[] }

export default function HealthPage() {
  const me = useApi<{ user: { fullName: string; phone: string; role: string } | null }>("/api/me");
  const [data, setData] = useState<Data | null>(null);
  const [step, setStep] = useState(0); // 0 hero, 1 need, 2 who, 3 details, 4 results
  const [need, setNeed] = useState("");
  const [who, setWho] = useState("");
  const [age, setAge] = useState("");
  const [city, setCity] = useState("all");
  const [budget, setBudget] = useState("");
  const [compare, setCompare] = useState<number[]>([]);
  const [book, setBook] = useState<{ org: Org; srv: Srv } | null>(null);
  const [advisor, setAdvisor] = useState(false);

  useEffect(() => { fetch("/api/data").then((r) => r.json()).then(setData).catch(() => {}); }, []);

  const medical = useMemo(() => {
    if (!data) return { orgs: [] as Org[], cities: [] as string[] };
    const catIds = data.categories.filter((c) => c.slug === "medical").map((c) => c.id);
    const orgs = data.organizations.filter((o) => catIds.includes(o.categoryId));
    return { orgs, cities: [...new Set(orgs.map((o) => o.city))] };
  }, [data]);

  const results = useMemo(() => {
    if (!data) return [];
    const words = NEEDS.find((n) => n.key === need)?.words || [];
    const max = BUDGETS.find((b) => b.key === budget)?.max ?? Infinity;
    const rows = data.services
      .map((s) => ({ s, o: medical.orgs.find((o) => o.id === s.organizationId)! }))
      .filter(({ s, o }) => o && (city === "all" || o.city === city) && parseFloat(s.price) <= max);
    const matched = words.length ? rows.filter(({ s }) => words.some((w) => s.nameAr.includes(w) || s.descriptionAr.includes(w))) : rows;
    return (matched.length ? matched : rows).sort((a, b) => parseFloat(a.s.price) - parseFloat(b.s.price));
  }, [data, medical, need, city, budget]);

  const exact = useMemo(() => {
    const words = NEEDS.find((n) => n.key === need)?.words || [];
    return !words.length || results.some(({ s }) => words.some((w) => s.nameAr.includes(w)));
  }, [results, need]);

  const toggleCompare = (id: number) => setCompare((c) => (c.includes(id) ? c.filter((x) => x !== id) : c.length < 3 ? [...c, id] : c));
  const compared = results.filter(({ s }) => compare.includes(s.id));
  const loggedCustomer = me.data?.user?.role === "CUSTOMER";

  return (
    <div className="min-h-screen bg-slate-50">
      <SiteHeader />
      <div className="bg-white border-b border-slate-200"><div className="max-w-6xl mx-auto px-4 h-12 flex items-center justify-between"><span className="font-black text-emerald-700">🏥 رابط الصحي</span><button onClick={() => setAdvisor(true)} className="h-9 px-3 rounded-lg bg-emerald-600 text-white text-sm font-bold flex items-center gap-1"><Phone className="w-4 h-4" /> تحدث مع مستشار</button></div></div>

      {step === 0 && (
        <>
          <section className="bg-gradient-to-br from-blue-900 via-blue-800 to-emerald-700 text-white">
            <div className="max-w-6xl mx-auto px-4 py-12 sm:py-16 grid lg:grid-cols-2 gap-8 items-center">
              <div>
                <span className="inline-block text-xs font-bold bg-white/15 rounded-full px-3 py-1 mb-3">مستشارك الصحي المستقل في ليبيا</span>
                <h1 className="text-3xl sm:text-4xl font-black leading-tight">اعثر على الرعاية الصحية المناسبة لك ولعائلتك – وقارن قبل أن تحجز</h1>
                <p className="mt-3 text-blue-100">أخبرنا بما تحتاجه في أقل من دقيقة، ونعرض لك أفضل المصحات والعيادات الموثقة بالأسعار وأقرب المواعيد. أو دع مستشاراً صحياً يتصل بك مجاناً.</p>
                <div className="mt-6 flex flex-col sm:flex-row gap-3">
                  <button onClick={() => setStep(1)} className="min-h-[52px] px-6 rounded-xl bg-amber-500 hover:bg-amber-600 font-black">ابدأ – احصل على خيارات مخصصة</button>
                  <button onClick={() => setAdvisor(true)} className="min-h-[52px] px-6 rounded-xl bg-white/15 hover:bg-white/25 font-bold">اطلب اتصالاً من مستشار</button>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {[{ n: medical.orgs.length || "—", t: "منشأة طبية موثقة" }, { n: "0 د.ل", t: "رسوم الاستشارة" }, { n: "< 24 ساعة", t: "رد المستشار" }, { n: "4.9★", t: "تقييم العملاء" }].map((x) => (
                  <div key={x.t} className="bg-white/10 rounded-2xl p-5"><div className="text-2xl font-black">{x.n}</div><div className="text-sm text-blue-100">{x.t}</div></div>
                ))}
              </div>
            </div>
          </section>

          <section className="max-w-6xl mx-auto px-4 py-12">
            <h2 className="text-2xl font-black text-center">كيف نعمل؟</h2>
            <div className="grid sm:grid-cols-3 gap-4 mt-6">
              {[
                { i: HelpCircle, t: "1. أخبرنا باحتياجك", d: "نوع الخدمة، المستفيد، المدينة والميزانية." },
                { i: ShieldCheck, t: "2. قارن الخيارات", d: "أسعار شفافة، تقييمات حقيقية، وسياسات إلغاء واضحة جنباً إلى جنب." },
                { i: CheckCircle2, t: "3. احجز أو استشر", d: "احجز فوراً وادفع من محفظتك، أو دع المستشار يرتب كل شيء." },
              ].map(({ i: I, t, d }) => (
                <div key={t} className="bg-white rounded-2xl border border-slate-200 p-6"><I className="w-8 h-8 text-emerald-600 mb-3" /><div className="font-black">{t}</div><p className="text-sm text-slate-600 mt-1">{d}</p></div>
              ))}
            </div>
          </section>

          <section className="bg-white border-y border-slate-200">
            <div className="max-w-6xl mx-auto px-4 py-12 grid sm:grid-cols-3 gap-6">
              {[{ i: ShieldCheck, t: "مستقلون وحياديون", d: "نعرض كل الخيارات المتاحة ونميّز الإعلانات بوضوح." }, { i: Headphones, t: "دعم بشري حقيقي", d: "مستشارون يتحدثون لهجتك ويعرفون السوق المحلي." }, { i: Clock, t: "توفير الوقت", d: "لا اتصالات متكررة ولا انتظار – تأكيد فوري للموعد." }].map(({ i: I, t, d }) => (
                <div key={t} className="flex gap-3"><I className="w-7 h-7 text-blue-700 shrink-0" /><div><div className="font-black">{t}</div><p className="text-sm text-slate-600">{d}</p></div></div>
              ))}
            </div>
          </section>

          <section className="max-w-3xl mx-auto px-4 py-12">
            <h2 className="text-2xl font-black text-center mb-6">أسئلة شائعة</h2>
            {[
              ["هل خدمة المستشار مجانية؟", "نعم، الاستشارة ومقارنة الخيارات مجانية بالكامل للعميل."],
              ["كيف تختارون المنشآت الطبية؟", "نتحقق من ترخيص كل منشأة وبياناتها قبل ظهورها على المنصة، ونراقب التقييمات باستمرار."],
              ["هل يمكنني إلغاء الموعد؟", "نعم حسب سياسة كل منشأة، وتظهر السياسة بوضوح قبل الحجز. المبالغ المستردة تعود لمحفظتك فوراً."],
              ["هل تحجزون لأفراد العائلة؟", "بالتأكيد، اختر «للعائلة» أو «لطفل» في الخطوات وسيساعدك المستشار في تنسيق عدة مواعيد."],
            ].map(([q, a]) => (
              <details key={q} className="bg-white border border-slate-200 rounded-2xl p-4 mb-2"><summary className="font-bold cursor-pointer">{q}</summary><p className="text-sm text-slate-600 mt-2">{a}</p></details>
            ))}
          </section>
        </>
      )}

      {step > 0 && step < 4 && (
        <main className="max-w-2xl mx-auto px-4 py-8">
          <div className="flex items-center gap-2 mb-6">
            {[1, 2, 3].map((n) => <div key={n} className={`h-2 flex-1 rounded-full ${n <= step ? "bg-emerald-600" : "bg-slate-200"}`} />)}
          </div>
          {step === 1 && (
            <>
              <h2 className="text-xl font-black mb-4">ما نوع الرعاية التي تحتاجها؟</h2>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {NEEDS.map(({ key, label, icon: I }) => (
                  <button key={key} onClick={() => { setNeed(key); setStep(2); }} className={`min-h-[96px] rounded-2xl border-2 p-4 flex flex-col items-center justify-center gap-2 font-bold ${need === key ? "border-emerald-600 bg-emerald-50" : "border-slate-200 bg-white hover:border-emerald-400"}`}>
                    <I className="w-7 h-7 text-emerald-600" />{label}
                  </button>
                ))}
              </div>
            </>
          )}
          {step === 2 && (
            <>
              <h2 className="text-xl font-black mb-4">لمن هذه الرعاية؟</h2>
              <div className="grid grid-cols-2 gap-3">
                {WHO.map(({ key, label, icon: I }) => (
                  <button key={key} onClick={() => { setWho(key); setStep(3); }} className={`min-h-[96px] rounded-2xl border-2 p-4 flex flex-col items-center justify-center gap-2 font-bold ${who === key ? "border-emerald-600 bg-emerald-50" : "border-slate-200 bg-white hover:border-emerald-400"}`}>
                    <I className="w-7 h-7 text-emerald-600" />{label}
                  </button>
                ))}
              </div>
            </>
          )}
          {step === 3 && (
            <>
              <h2 className="text-xl font-black mb-4">بعض التفاصيل</h2>
              <div className="space-y-3 bg-white border border-slate-200 rounded-2xl p-5">
                <label className="block text-sm font-bold">عمر المستفيد (اختياري)<input className={`${inputCls} mt-1`} type="number" min={0} max={120} value={age} onChange={(e) => setAge(e.target.value)} /></label>
                <label className="block text-sm font-bold">المدينة
                  <select className={`${inputCls} mt-1`} value={city} onChange={(e) => setCity(e.target.value)}>
                    <option value="all">كل المدن</option>{medical.cities.map((c) => <option key={c}>{c}</option>)}
                  </select>
                </label>
                <div className="text-sm font-bold">الميزانية</div>
                <div className="grid grid-cols-2 gap-2">
                  {BUDGETS.map((b) => <button key={b.key} onClick={() => setBudget(b.key)} className={`min-h-[44px] rounded-xl border text-sm font-bold ${budget === b.key ? "border-emerald-600 bg-emerald-50" : "border-slate-200"}`}>{b.label}</button>)}
                </div>
                <Btn className="w-full min-h-[52px] !bg-emerald-600" onClick={() => setStep(4)}>عرض الخيارات المناسبة</Btn>
              </div>
            </>
          )}
          <button onClick={() => setStep(step - 1)} className="mt-6 flex items-center gap-1 text-sm font-bold text-slate-500"><ArrowRight className="w-4 h-4" /> رجوع</button>
        </main>
      )}

      {step === 4 && (
        <main className="max-w-6xl mx-auto px-4 py-8 space-y-5 pb-32">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="text-xl font-black">خياراتك المقترحة ({results.length})</h2>
              <p className="text-sm text-slate-500">{NEEDS.find((n) => n.key === need)?.label} • {WHO.find((w) => w.key === who)?.label} • مرتبة من الأقل سعراً • اختر حتى 3 للمقارنة</p>
            </div>
            <button onClick={() => setStep(1)} className="text-sm font-bold text-blue-700">تعديل البحث</button>
          </div>
          {!exact && <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-sm text-amber-900">لم نجد تطابقاً دقيقاً، هذه أقرب الخيارات. يمكن لمستشارنا البحث لك عن خيارات إضافية.</div>}

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {results.map(({ s, o }) => (
              <article key={s.id} className={`bg-white rounded-2xl border-2 p-4 space-y-2 ${compare.includes(s.id) ? "border-emerald-600" : "border-slate-200"}`}>
                <div className="flex items-center justify-between text-xs">
                  <span className="flex items-center gap-1 text-blue-700 font-bold"><ShieldCheck className="w-4 h-4" /> منشأة موثقة</span>
                  <span className="flex items-center gap-1"><Star className="w-4 h-4 fill-amber-400 text-amber-400" />{o.rating}</span>
                </div>
                <h3 className="font-black">{s.nameAr}</h3>
                <p className="text-sm text-slate-600">{o.nameAr}</p>
                <p className="text-xs text-slate-500 flex items-center gap-1"><MapPin className="w-3.5 h-3.5" />{o.city} • {s.durationMinutes} دقيقة</p>
                <div className="text-2xl font-black text-emerald-700">{lyd(s.price)}</div>
                <p className="text-xs text-slate-500">{o.cancellationPolicyAr}</p>
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <Btn variant="accent" onClick={() => setBook({ org: o, srv: s })}>احجز الآن</Btn>
                  <Btn variant="ghost" onClick={() => toggleCompare(s.id)}>{compare.includes(s.id) ? "إزالة" : "قارن"}</Btn>
                </div>
              </article>
            ))}
          </div>

          <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-5 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div><div className="font-black">محتار بين الخيارات؟</div><p className="text-sm text-slate-600">مستشارنا الصحي يساعدك مجاناً في اختيار الطبيب المناسب وترتيب الموعد.</p></div>
            <Btn className="!bg-emerald-600" onClick={() => setAdvisor(true)}>اطلب اتصالاً من مستشار</Btn>
          </div>

          {compared.length >= 2 && (
            <div className="bg-white border border-slate-200 rounded-2xl overflow-x-auto">
              <table className="w-full text-sm min-w-[520px]">
                <thead><tr className="bg-slate-50"><th className="p-3 text-right">المقارنة</th>{compared.map(({ s }) => <th key={s.id} className="p-3 text-right">{s.nameAr}</th>)}</tr></thead>
                <tbody>
                  {[
                    ["المنشأة", (x: typeof compared[0]) => x.o.nameAr],
                    ["السعر", (x: typeof compared[0]) => lyd(x.s.price)],
                    ["المدة", (x: typeof compared[0]) => `${x.s.durationMinutes} دقيقة`],
                    ["التقييم", (x: typeof compared[0]) => `${x.o.rating} (${x.o.reviewsCount})`],
                    ["المدينة", (x: typeof compared[0]) => x.o.city],
                    ["سياسة الإلغاء", (x: typeof compared[0]) => x.o.cancellationPolicyAr],
                  ].map(([label, fn]) => (
                    <tr key={label as string} className="border-t"><td className="p-3 font-bold">{label as string}</td>{compared.map((x) => <td key={x.s.id} className="p-3">{(fn as (x: typeof compared[0]) => string)(x)}</td>)}</tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </main>
      )}

      {step === 4 && compare.length > 0 && compared.length < 2 && (
        <div className="fixed bottom-4 inset-x-4 sm:inset-x-auto sm:left-4 z-30 bg-slate-900 text-white rounded-xl px-4 py-3 text-sm text-center">اختر خياراً آخر للمقارنة</div>
      )}

      {book && data && <BookingSheet org={book.org} service={book.srv} branches={data.branches} loggedIn={loggedCustomer} onClose={() => setBook(null)} />}
      {advisor && <AdvisorForm need={need} who={who} age={age} city={city} budget={budget} user={me.data?.user} onClose={() => setAdvisor(false)} />}
    </div>
  );
}

function AdvisorForm({ need, who, age, city, budget, user, onClose }: { need: string; who: string; age: string; city: string; budget: string; user?: { fullName: string; phone: string } | null; onClose: () => void }) {
  const [f, setF] = useState({ fullName: user?.fullName || "", phone: user?.phone || "", needType: need || "CONSULT", forWhom: who || "SELF", preferredDate: "", notes: "" });
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<string | null>(null);
  const [err, setErr] = useState("");
  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 flex items-end sm:items-center justify-center" role="dialog" aria-modal="true">
      <div className="bg-white w-full sm:max-w-md rounded-t-3xl sm:rounded-3xl p-5 max-h-[92vh] overflow-y-auto">
        {done ? (
          <div className="text-center space-y-3 py-4">
            <CheckCircle2 className="w-14 h-14 text-emerald-600 mx-auto" />
            <div className="font-black text-lg">تم استلام طلبك</div>
            <p className="text-sm text-slate-600">سيتصل بك مستشار صحي خلال 24 ساعة. رقم الطلب: <b className="font-mono">{done}</b></p>
            <Btn className="w-full" onClick={onClose}>تم</Btn>
          </div>
        ) : (
          <form className="space-y-3" onSubmit={async (e) => {
            e.preventDefault(); setBusy(true); setErr("");
            try { const r = await postJson("/api/care-requests", { ...f, age, city: city === "all" ? "طرابلس" : city, budget }); setDone(r.requestRef); }
            catch (er) { setErr((er as Error).message); } finally { setBusy(false); }
          }}>
            <div className="flex justify-between items-center"><div className="font-black text-lg">تحدث مع مستشار صحي</div><button type="button" onClick={onClose} className="p-2 text-slate-400">✕</button></div>
            <p className="text-sm text-slate-500">مجاني وبدون أي التزام. سنتصل بك لفهم حالتك واقتراح الأنسب.</p>
            {err && <div className="p-3 rounded-xl bg-red-50 text-red-700 text-sm">{err}</div>}
            <input className={inputCls} required placeholder="الاسم" value={f.fullName} onChange={(e) => setF({ ...f, fullName: e.target.value })} />
            <input className={inputCls} dir="ltr" required placeholder="09XXXXXXXX" value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} />
            <select className={inputCls} value={f.needType} onChange={(e) => setF({ ...f, needType: e.target.value })}>{NEEDS.map((n) => <option key={n.key} value={n.key}>{n.label}</option>)}</select>
            <select className={inputCls} value={f.forWhom} onChange={(e) => setF({ ...f, forWhom: e.target.value })}>{WHO.map((n) => <option key={n.key} value={n.key}>{n.label}</option>)}</select>
            <input className={inputCls} type="date" value={f.preferredDate} onChange={(e) => setF({ ...f, preferredDate: e.target.value })} />
            <textarea className={`${inputCls} py-2`} rows={3} placeholder="صف حالتك باختصار (اختياري)" value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} />
            <Btn className="w-full min-h-[50px] !bg-emerald-600" disabled={busy}>{busy ? "جاري الإرسال..." : "أرسل الطلب"} <ArrowLeft className="w-4 h-4 inline" /></Btn>
          </form>
        )}
      </div>
    </div>
  );
}
