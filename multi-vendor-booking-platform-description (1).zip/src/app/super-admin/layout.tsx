"use client";

import type { ReactNode } from "react";
import RoleShell, { type NavItem } from "@/components/RoleShell";
import RoleGate from "@/components/RoleGate";
import InlineLogin from "@/components/InlineLogin";

const nav: NavItem[] = [
  { href: "/super-admin?tab=home", label: "لوحة المؤشرات", icon: "LayoutDashboard" },
  { href: "/super-admin?tab=admins", label: "المدراء والصلاحيات", icon: "KeyRound" },
  { href: "/super-admin?tab=users", label: "المستخدمون والمحافظ", icon: "Users" },
  { href: "/super-admin?tab=cards", label: "كروت الشحن (كل الأحجام)", icon: "CreditCard" },
  { href: "/super-admin?tab=vip", label: "VIP والحملات", icon: "Crown" },
  { href: "/super-admin?tab=care", label: "طلبات صحية", icon: "Bell" },
  { href: "/super-admin?tab=audit", label: "سجل العمليات", icon: "FileText" },
];
const ROLES = ["SUPER_ADMIN"];

export default function SuperLayout({ children }: { children: ReactNode }) {
  return (
    <RoleGate roles={ROLES} portal="super" login={(p) => <InlineLogin portal={p} />}>
      {(u) => <RoleShell brand="👑 الإدارة العليا" subtitle={u.fullName} nav={nav} accent="amber">{children}</RoleShell>}
    </RoleGate>
  );
}
