"use client";

import { Suspense, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import AdminConsole from "@/components/AdminConsole";
import { Skeleton } from "@/components/ui";

function Inner() {
  const tab = useSearchParams().get("tab");
  const router = useRouter();
  useEffect(() => { if (!tab) router.replace("/super-admin?tab=home"); }, [tab, router]);
  if (!tab) return <Skeleton />;
  return (
    <>
      <div className="mb-4 p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs">👑 الإدارة العليا – كل عملية هنا تُسجَّل في سجل التدقيق.</div>
      <AdminConsole />
    </>
  );
}

export default function Page() {
  return <Suspense fallback={<Skeleton />}><Inner /></Suspense>;
}
