"use client";

import type { ReactNode } from "react";
import RoleShell, { type NavItem } from "@/components/RoleShell";
import RoleGate from "@/components/RoleGate";
import InlineLogin from "@/components/InlineLogin";
import { P } from "@/lib/rbac";

const ROLES = ["PLATFORM_ADMIN", "SUPPORT_AGENT", "SUPER_ADMIN"];

function adminNav(perms: string[]): NavItem[] {
  const can = (p: string) => perms.includes(p);
  const items: (NavItem & { p?: string })[] = [
    { href: "/admin?tab=home", label: "الرئيسية", icon: "LayoutDashboard" },
    { href: "/admin?tab=users", label: "المستخدمون والمحافظ", icon: "Users", p: P.USERS_MANAGE },
    { href: "/admin?tab=care", label: "طلبات صحية", icon: "Bell", p: P.USERS_MANAGE },
    { href: "/admin?tab=cards", label: "كروت الشحن", icon: "CreditCard", p: P.CARDS_VIEW },
    { href: "/admin?tab=vip", label: "VIP والحملات", icon: "Crown", p: P.VIP_MANAGE },
    { href: "/admin?tab=audit", label: "سجل العمليات", icon: "FileText", p: P.AUDIT_VIEW },
    { href: "/super-admin?tab=home", label: "الإدارة العليا", icon: "Shield", p: P.SUPER_ACCESS },
  ];
  return items.filter((i) => !i.p || can(i.p)).map(({ p: _p, ...i }) => i);
}

export default function AdminLayout({ children }: { children: ReactNode }) {
  return (
    <RoleGate roles={ROLES} portal="admin" login={(p) => <InlineLogin portal={p} />}>
      {(u) => <RoleShell brand="رابط – الإدارة" subtitle={u.fullName} nav={adminNav(u.permissions)} accent="purple">{children}</RoleShell>}
    </RoleGate>
  );
}
