import { Suspense } from "react";
import AdminConsole from "@/components/AdminConsole";
import { Skeleton } from "@/components/ui";

export default function Page() {
  return <Suspense fallback={<Skeleton rows={4} />}><AdminConsole /></Suspense>;
}
