import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "رابط للحجوزات | المنصة السحابية الموحدة لإدارة المواعيد وحجوزات القطاعات الحيوية",
  description:
    "منصة رابط للحجوزات (Multi-Vendor SaaS) - الوجهة الأولى لجدولة المواعيد في المصحات والعيادات، صالات الأفراح والفعاليات، الشاليهات والمنتجعات مع لوحات تحكم مستقلة لمزودي الخدمات وتأكيد لحظي للعملاء.",
  keywords: [
    "رابط للحجوزات",
    "منصة حجز عيادات",
    "حجز صالات أفراح",
    "حجز شاليهات ومنتجعات",
    "نظام إدارة المواعيد SaaS",
    "جدولة المواعيد السحابية",
  ],
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ar" dir="rtl" className="scroll-smooth">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800;900&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="font-['Tajawal',sans-serif] bg-slate-50 text-slate-900 antialiased selection:bg-blue-600 selection:text-white">
        {children}
      </body>
    </html>
  );
}
