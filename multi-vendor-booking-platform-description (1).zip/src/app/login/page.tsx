import Link from "next/link";
import { ChevronLeft } from "lucide-react";
import { PORTALS, PORTAL_KEYS } from "@/lib/portals";

export default function LoginHub() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-900 to-slate-900 p-4 flex items-center justify-center">
      <div className="w-full max-w-md">
        <Link href="/" className="flex items-center justify-center gap-2 mb-6 text-white">
          <span className="w-11 h-11 rounded-2xl bg-white text-blue-800 flex items-center justify-center font-black text-2xl">ر</span>
          <span className="font-black text-xl">رابط للحجوزات</span>
        </Link>
        <h1 className="text-white text-center font-black text-lg mb-4">اختر بوابة الدخول</h1>
        <div className="space-y-3">
          {PORTAL_KEYS.map((k) => {
            const p = PORTALS[k];
            return (
              <Link key={k} href={`/login/${k}`} className={`flex items-center gap-4 rounded-2xl p-4 text-white bg-gradient-to-l ${p.color} shadow-lg active:scale-[0.99] transition`}>
                <span className="text-3xl" aria-hidden>{p.emoji}</span>
                <span className="flex-1">
                  <span className="block font-black">{p.title}</span>
                  <span className="block text-xs opacity-90">{p.subtitle}</span>
                </span>
                <ChevronLeft className="w-5 h-5 opacity-80" />
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}
