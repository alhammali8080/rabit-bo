import { notFound } from "next/navigation";
import { PORTALS, PORTAL_KEYS, type PortalKey } from "@/lib/portals";
import PortalLogin from "./PortalLogin";

export function generateStaticParams() {
  return PORTAL_KEYS.map((portal) => ({ portal }));
}

export default async function Page({ params }: { params: Promise<{ portal: string }> }) {
  const { portal } = await params;
  if (!(portal in PORTALS)) notFound();
  return <PortalLogin portal={portal as PortalKey} />;
}
