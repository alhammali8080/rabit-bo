"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { setToken, clearToken, storageBlocked, QUERY as TK_QUERY } from "@/lib/clientAuth";
import Link from "next/link";
import { ArrowRight, Eye, EyeOff, Zap } from "lucide-react";
import { PORTALS, type PortalKey } from "@/lib/portals";
import { Btn, inputCls, postJson } from "@/components/ui";

const DEMO_PASSWORD = "123456";

export default function PortalLogin({ portal }: { portal: PortalKey }) {
  const cfg = PORTALS[portal];
  const router = useRouter();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [rightPortal, setRightPortal] = useState<PortalKey | null>(null);

  async function finish(r: { redirect: string; token: string }) {
    setToken(r.token);
    // The token travels in the address (?tk=...). Inside the preview panel the browser
    // blocks cookies AND storage, so the address bar is the only place a session can
    // survive a reload. clientAuth picks it up and re-appends it on every navigation.
    router.replace(`${r.redirect}?${TK_QUERY}=${encodeURIComponent(r.token)}`);
  }

  async function login(p: string, pw: string, tag: string) {
    setBusy(tag);
    setError("");
    setRightPortal(null);
    try {
      const r = mode === "register" && tag === "form"
        ? await postJson("/api/auth/register", { fullName, phone: p, password: pw })
        : await postJson("/api/auth/login", { phone: p, password: pw, portal });
      await finish(r);
    } catch (e) {
      clearToken();
      const d = (e as { data?: { rightPortal?: PortalKey } }).data;
      setRightPortal(d?.rightPortal ?? null);
      setError((e as Error).message);
      setBusy(null);
    }
  }

  return (
    <div className="min-h-screen bg-slate-100 flex items-center justify-center p-4">
      <div className="w-full max-w-sm bg-white rounded-3xl shadow-xl overflow-hidden">
        <div className={`bg-gradient-to-l ${cfg.color} text-white p-5`}>
          <Link href="/login" className="inline-flex items-center gap-1 text-xs font-bold opacity-90 mb-3"><ArrowRight className="w-4 h-4" /> كل البوابات</Link>
          <div className="flex items-center gap-3">
            <span className="text-4xl" aria-hidden>{cfg.emoji}</span>
            <div>
              <h1 className="font-black text-xl">{cfg.title}</h1>
              <p className="text-xs opacity-90">{cfg.subtitle}</p>
            </div>
          </div>
        </div>

        <div className="p-5 space-y-4">
          {/* One-tap login */}
          <div>
            <div className="text-xs font-bold text-slate-500 mb-2 flex items-center gap-1"><Zap className="w-4 h-4 text-amber-500" /> دخول بضغطة واحدة</div>
            <div className="space-y-2">
              {cfg.demo.map((d) => (
                <button key={d.phone} disabled={!!busy} onClick={() => login(d.phone, DEMO_PASSWORD, d.phone)}
                  className={`w-full min-h-[52px] rounded-xl text-white font-bold bg-gradient-to-l ${cfg.color} disabled:opacity-60`}>
                  {busy === d.phone ? "جاري الدخول..." : d.label}
                </button>
              ))}
            </div>
          </div>

          {error && (
            <div className="p-3 rounded-xl bg-red-50 text-red-700 text-sm border border-red-200 space-y-2">
              <p>{error}</p>
              {rightPortal && <Link href={`/login/${rightPortal}`} className="block text-center font-bold underline">الذهاب إلى {PORTALS[rightPortal].title}</Link>}
            </div>
          )}

          <div className="relative flex items-center gap-2 text-xs text-slate-400"><span className="flex-1 h-px bg-slate-200" />أو بحسابك<span className="flex-1 h-px bg-slate-200" /></div>

          {cfg.canRegister && (
            <div className="grid grid-cols-2 gap-1 bg-slate-100 p-1 rounded-xl">
              {(["login", "register"] as const).map((m) => (
                <button key={m} onClick={() => { setMode(m); setError(""); }} className={`min-h-[40px] rounded-lg font-bold text-sm ${mode === m ? "bg-white shadow" : "text-slate-500"}`}>
                  {m === "login" ? "دخول" : "حساب جديد"}
                </button>
              ))}
            </div>
          )}

          <form onSubmit={(e) => { e.preventDefault(); login(phone, password, "form"); }} className="space-y-3">
            {mode === "register" && <input className={inputCls} required placeholder="الاسم الكامل" value={fullName} onChange={(e) => setFullName(e.target.value)} />}
            <input className={inputCls} dir="ltr" inputMode="tel" required placeholder="09XXXXXXXX" value={phone} onChange={(e) => setPhone(e.target.value)} />
            <div className="relative">
              <input className={inputCls} dir="ltr" type={show ? "text" : "password"} required placeholder="كلمة المرور" value={password} onChange={(e) => setPassword(e.target.value)} />
              <button type="button" onClick={() => setShow(!show)} aria-label="إظهار كلمة المرور" className="absolute left-3 top-3 text-slate-400">{show ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}</button>
            </div>
            <Btn className="w-full min-h-[50px]" disabled={!!busy}>{busy === "form" ? "جاري الدخول..." : mode === "register" ? "إنشاء الحساب" : "دخول"}</Btn>
          </form>

          {storageBlocked() && (
            <div className="p-3 rounded-xl bg-blue-50 border border-blue-200 text-blue-900 text-xs leading-relaxed">
              هذه النافذة تمنع حفظ بيانات الدخول. الدخول سيعمل، لكن عند تحديث الصفحة قد تحتاج لتسجيل الدخول مرة أخرى. لجلسة مستقرة افتح الموقع في نافذة مستقلة.
            </div>
          )}

          <details className="text-xs text-slate-500 border-t border-slate-100 pt-3">
            <summary className="cursor-pointer font-bold">لا يستمر الدخول بعد الضغط؟</summary>
            <p className="mt-2 leading-relaxed">بعض المتصفحات تمنع حفظ الدخول داخل نافذة المعاينة. افتح الموقع في نافذة مستقلة ثم سجّل الدخول هناك:</p>
            <a href={typeof window !== "undefined" ? window.location.href : "/login"} target="_blank" rel="noopener" className="mt-2 block text-center h-11 leading-[44px] rounded-xl bg-slate-100 font-bold text-slate-800">فتح في نافذة مستقلة</a>
          </details>
        </div>
      </div>
    </div>
  );
}
