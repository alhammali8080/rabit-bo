"use client";

import type { ReactNode } from "react";
import RoleShell from "@/components/RoleShell";
import RoleGate from "@/components/RoleGate";
import InlineLogin from "@/components/InlineLogin";
import { workspaceNav } from "@/lib/navs";

const ROLES = ["STAFF", "PROVIDER_MANAGER"];

export default function StaffLayout({ children }: { children: ReactNode }) {
  return (
    <RoleGate roles={ROLES} portal="staff" login={(p) => <InlineLogin portal={p} />}>
      {(u) => <RoleShell brand="رابط – الموظف" subtitle={u.fullName} nav={workspaceNav("/staff", u.permissions).nav} accent="slate">{children}</RoleShell>}
    </RoleGate>
  );
}
