import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { vipTiers, vipBenefits } from "@/db/schema";
import { guard } from "@/lib/server/session";
import { getActiveVip } from "@/lib/server/wallet";

export async function GET() {
  const g = await guard({ roles: ["CUSTOMER"] });
  if (g instanceof NextResponse) return g;
  const vip = await getActiveVip(g.userId);
  const tiers = await db.select().from(vipTiers).where(eq(vipTiers.isActive, true));
  const benefits = await db.select().from(vipBenefits).where(eq(vipBenefits.isActive, true));
  let tier = null;
  if (vip) [tier] = await db.select().from(vipTiers).where(eq(vipTiers.id, vip.membership.tierId));
  return NextResponse.json({
    active: vip ? { ...vip.membership, tier, benefits: vip.benefits } : null,
    tiers: tiers.map((t) => ({ ...t, benefits: benefits.filter((b) => b.tierId === t.id) })),
  });
}
