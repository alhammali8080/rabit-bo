import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { randomBytes } from "crypto";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { staff, users, UserRole } from "@/db/schema";
import { guard, safeError, UserError } from "@/lib/server/session";
import { audit } from "@/lib/server/audit";
import { DELEGABLE_PERMISSIONS, P } from "@/lib/rbac";

const VALID = new Set<string>(DELEGABLE_PERMISSIONS.map((d) => d.key));
const clean = (arr: unknown) => (Array.isArray(arr) ? [...new Set(arr.map(String).filter((p) => VALID.has(p)))] : []);

// Create a staff member (links/creates a STAFF user by phone so they can log in with OTP)
export async function POST(req: Request) {
  const g = await guard({ tenant: true, perm: P.STAFF_MANAGE });
  if (g instanceof NextResponse) return g;
  try {
    const { fullName, phone, roleTitle, permissions } = await req.json();
    const ph = String(phone || "").replace(/\s/g, "");
    if (!fullName || !/^\+?[0-9]{9,15}$/.test(ph)) throw new UserError("الاسم ورقم الهاتف مطلوبان");
    const perms = clean(permissions);

    const created = await db.transaction(async (tx) => {
      let [u] = await tx.select().from(users).where(eq(users.phone, ph));
      if (u && u.role !== UserRole.CUSTOMER && u.role !== UserRole.STAFF) throw new UserError("هذا الرقم مرتبط بحساب إداري أو منشأة أخرى", 409);
      if (u) {
        const [existing] = await tx.select().from(staff).where(eq(staff.userId, u.id));
        if (existing) throw new UserError("هذا الموظف مسجل مسبقاً في منشأة", 409);
        await tx.update(users).set({ role: UserRole.STAFF }).where(eq(users.id, u.id));
      } else {
        [u] = await tx
          .insert(users)
          .values({ phone: ph, fullName, role: UserRole.STAFF, passwordHash: await bcrypt.hash(randomBytes(16).toString("hex"), 10) })
          .returning();
      }
      const [st] = await tx
        .insert(staff)
        .values({ organizationId: g.organizationId!, userId: u.id, fullName, phone: ph, titleAr: roleTitle || "موظف", roleTitle: roleTitle || "موظف", permissionsJson: JSON.stringify(perms) })
        .returning();
      return st;
    });
    await audit({ userId: g.userId, action: "STAFF_CREATED", entity: "STAFF", entityId: created.id, newValue: { perms } });
    return NextResponse.json(created, { status: 201 });
  } catch (e) {
    return safeError(e);
  }
}

// Update permissions of a staff member (same tenant only)
export async function PATCH(req: Request) {
  const g = await guard({ tenant: true, perm: P.STAFF_MANAGE });
  if (g instanceof NextResponse) return g;
  try {
    const { staffId, permissions, isActive } = await req.json();
    const [st] = await db.select().from(staff).where(and(eq(staff.id, Number(staffId)), eq(staff.organizationId, g.organizationId!)));
    if (!st) throw new UserError("الموظف غير موجود", 404);
    if (st.id === g.staffId) throw new UserError("لا يمكنك تعديل صلاحياتك بنفسك", 403);
    const perms = clean(permissions);
    await db
      .update(staff)
      .set({ permissionsJson: JSON.stringify(perms), ...(typeof isActive === "boolean" ? { isActive } : {}) })
      .where(eq(staff.id, st.id));
    await audit({ userId: g.userId, action: "PERMISSIONS_CHANGED", entity: "STAFF", entityId: st.id, oldValue: st.permissionsJson, newValue: perms });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return safeError(e);
  }
}
