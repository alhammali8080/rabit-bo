import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { organizations, branches, staff, services, bookings, wallets, subscriptions, subscriptionPlans } from "@/db/schema";
import { guard, hasPerm, safeError } from "@/lib/server/session";
import { P } from "@/lib/rbac";

// Tenant comes ONLY from the session – never from query params (tenant isolation).
export async function GET() {
  const g = await guard({ tenant: true });
  if (g instanceof NextResponse) return g;
  try {
    const id = g.organizationId!;
    const canFinance = hasPerm(g, P.FINANCE_VIEW);
    const canBookings = hasPerm(g, P.BOOKINGS_VIEW);
    const canCustomers = hasPerm(g, P.CUSTOMERS_VIEW);

    const [org] = await db.select().from(organizations).where(eq(organizations.id, id));
    const orgBranches = await db.select().from(branches).where(eq(branches.organizationId, id));
    const orgServices = await db.select().from(services).where(eq(services.organizationId, id));
    const orgStaff = hasPerm(g, P.STAFF_MANAGE) ? await db.select().from(staff).where(eq(staff.organizationId, id)) : [];

    let orgBookings: Record<string, unknown>[] = [];
    if (canBookings) {
      const rows = await db.select().from(bookings).where(eq(bookings.organizationId, id)).orderBy(desc(bookings.bookingDate), desc(bookings.startTime)).limit(200);
      orgBookings = rows.map((b) => {
        const base: Record<string, unknown> = {
          id: b.id, bookingRef: b.bookingRef, serviceId: b.serviceId, staffId: b.staffId, branchId: b.branchId,
          customerName: b.customerName, bookingDate: b.bookingDate, startTime: b.startTime, endTime: b.endTime,
          status: b.status, paymentStatus: b.paymentStatus, paymentMethod: b.paymentMethod, notes: b.notes,
          // Privacy: phone only for users allowed to see customers
          customerPhone: canCustomers ? b.customerPhone : b.customerPhone.slice(0, 5) + "•••••",
        };
        if (canFinance) Object.assign(base, { totalPrice: b.totalPrice, platformFee: b.platformFee, providerNet: b.providerNet });
        return base;
      });
    }

    let finance = null;
    if (canFinance) {
      const [wallet] = await db.select().from(wallets).where(eq(wallets.organizationId, id));
      const [sub] = await db.select().from(subscriptions).where(eq(subscriptions.organizationId, id));
      const plan = sub ? (await db.select().from(subscriptionPlans).where(eq(subscriptionPlans.id, sub.planId)))[0] : null;
      finance = { wallet, subscription: sub ? { ...sub, plan } : null };
    }

    return NextResponse.json({
      me: { fullName: g.fullName, role: g.role, permissions: g.permissions },
      organization: { id: org.id, nameAr: org.nameAr, slug: org.slug, city: org.city, currency: org.currency },
      branches: orgBranches,
      services: orgServices,
      staff: orgStaff.map((s) => ({ ...s, permissions: JSON.parse(s.permissionsJson || "[]") })),
      bookings: orgBookings,
      finance,
    });
  } catch (e) {
    return safeError(e);
  }
}
