import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { bookings, BookingStatus } from "@/db/schema";
import { guard, hasPerm, forbidden, safeError } from "@/lib/server/session";
import { audit } from "@/lib/server/audit";
import { P } from "@/lib/rbac";

const ALLOWED = [BookingStatus.COMPLETED, BookingStatus.NO_SHOW, BookingStatus.CONFIRMED] as string[];

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const g = await guard({ tenant: true });
  if (g instanceof NextResponse) return g;
  try {
    const { id } = await ctx.params;
    const { status } = await req.json();
    if (!ALLOWED.includes(status)) return NextResponse.json({ error: "حالة غير مسموحة" }, { status: 400 });
    const need = status === BookingStatus.CONFIRMED ? P.BOOKINGS_EDIT : P.BOOKINGS_CHECKIN;
    if (!hasPerm(g, need)) return forbidden();

    const [b] = await db.select().from(bookings).where(and(eq(bookings.id, Number(id)), eq(bookings.organizationId, g.organizationId!)));
    if (!b) return NextResponse.json({ error: "الحجز غير موجود" }, { status: 404 });
    await db.update(bookings).set({ status, updatedAt: new Date() }).where(eq(bookings.id, b.id));
    await audit({ userId: g.userId, action: "BOOKING_STATUS_CHANGED", entity: "BOOKING", entityId: b.bookingRef, oldValue: b.status, newValue: status });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return safeError(e);
  }
}
