import { NextResponse } from "next/server";
import { and, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import { bookings, services, branches, organizations, BookingStatus, PaymentStatus } from "@/db/schema";
import { guard, safeError, UserError } from "@/lib/server/session";
import { audit } from "@/lib/server/audit";
import { P } from "@/lib/rbac";

// Manual / walk-in booking created by provider or staff with bookings.create
export async function POST(req: Request) {
  const g = await guard({ tenant: true, perm: P.BOOKINGS_CREATE });
  if (g instanceof NextResponse) return g;
  try {
    const { serviceId, bookingDate, startTime, customerName, customerPhone } = await req.json();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(bookingDate || "") || !/^([01]\d|2[0-3]):[0-5]\d$/.test(startTime || "") || !customerName || !customerPhone) {
      throw new UserError("أكمل بيانات الحجز");
    }
    const orgId = g.organizationId!;
    const [srv] = await db.select().from(services).where(and(eq(services.id, Number(serviceId)), eq(services.organizationId, orgId)));
    if (!srv) throw new UserError("الخدمة غير موجودة", 404);
    const [org] = await db.select().from(organizations).where(eq(organizations.id, orgId));
    const [br] = await db.select().from(branches).where(eq(branches.organizationId, orgId)).limit(1);
    const [h, m] = startTime.split(":").map(Number);
    const endTotal = h * 60 + m + srv.durationMinutes;
    const endTime = `${String(Math.floor(endTotal / 60) % 24).padStart(2, "0")}:${String(endTotal % 60).padStart(2, "0")}`;
    const price = parseFloat(srv.price);
    const pct = parseFloat(srv.customCommissionPercent || org.customCommissionPercent || "5");
    const fee = Math.round(price * pct) / 100;

    const b = await db.transaction(async (tx) => {
      await tx.execute(sql`SELECT pg_advisory_xact_lock(${br.id}::int, ${Number(bookingDate.replace(/-/g, "")) % 2147483647}::int)`);
      const existing = await tx.select().from(bookings).where(and(eq(bookings.branchId, br.id), eq(bookings.bookingDate, bookingDate), inArray(bookings.status, [BookingStatus.CONFIRMED, BookingStatus.PENDING])));
      const toMin = (t: string) => Number(t.slice(0, 2)) * 60 + Number(t.slice(3, 5));
      if (existing.some((e) => h * 60 + m < toMin(e.endTime) && toMin(e.startTime) < endTotal)) throw new UserError("الموعد محجوز مسبقاً", 409);
      const [row] = await tx.insert(bookings).values({
        bookingRef: `RBT-${new Date().getFullYear()}-${Math.floor(100000 + Math.random() * 900000)}`,
        organizationId: orgId, branchId: br.id, serviceId: srv.id, customerName: String(customerName).slice(0, 80), customerPhone: String(customerPhone).slice(0, 20),
        bookingDate, startTime, endTime, price: price.toFixed(2), totalPrice: price.toFixed(2), commissionPercent: pct.toFixed(2),
        platformFee: fee.toFixed(2), providerNet: (price - fee).toFixed(2), currency: org.currency,
        status: BookingStatus.CONFIRMED, paymentStatus: PaymentStatus.PAY_AT_VENUE, paymentMethod: "CASH", notes: "حجز يدوي من المنشأة",
      }).returning();
      return row;
    });
    await audit({ userId: g.userId, action: "MANUAL_BOOKING_CREATED", entity: "BOOKING", entityId: b.bookingRef });
    return NextResponse.json(b, { status: 201 });
  } catch (e) {
    return safeError(e);
  }
}
