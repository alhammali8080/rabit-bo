import { NextResponse } from "next/server";
import { randomBytes } from "crypto";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { events, ticketTiers, ticketOrders, organizations, notifications, WalletTxType } from "@/db/schema";
import { guard, safeError, UserError } from "@/lib/server/session";
import { applyWalletTx } from "@/lib/server/wallet";
import { creditProvider } from "@/lib/server/providerCredit";
import { audit } from "@/lib/server/audit";

const FEE_PER_TICKET = 1;

export async function POST(req: Request, ctx: { params: Promise<{ slug: string }> }) {
  const g = await guard({ roles: ["CUSTOMER"] });
  if (g instanceof NextResponse) return g;
  try {
    const { slug } = await ctx.params;
    const { tierId, quantity } = await req.json();
    const qty = Math.floor(Number(quantity));
    const [ev] = await db.select().from(events).where(eq(events.slug, slug));
    if (!ev || !ev.isActive) throw new UserError("الفعالية غير متاحة", 404);
    if (ev.eventDate < new Date().toISOString().slice(0, 10)) throw new UserError("انتهت هذه الفعالية");

    const order = await db.transaction(async (tx) => {
      // Lock the tier row so concurrent buyers can't oversell
      const [tier] = await tx.select().from(ticketTiers).where(and(eq(ticketTiers.id, Number(tierId)), eq(ticketTiers.eventId, ev.id))).for("update");
      if (!tier) throw new UserError("فئة التذكرة غير موجودة", 404);
      if (!(qty >= 1 && qty <= tier.maxPerOrder)) throw new UserError(`يمكن شراء من 1 إلى ${tier.maxPerOrder} تذاكر`);
      if (tier.capacity - tier.sold < qty) throw new UserError("عذراً، التذاكر المتبقية غير كافية", 409);
      const unit = parseFloat(tier.price);
      const fee = FEE_PER_TICKET * qty;
      const total = unit * qty + fee;
      const ref = `TKT-${randomBytes(4).toString("hex").toUpperCase()}`;

      await tx.update(ticketTiers).set({ sold: tier.sold + qty }).where(eq(ticketTiers.id, tier.id));
      const [o] = await tx.insert(ticketOrders).values({
        orderRef: ref, eventId: ev.id, tierId: tier.id, userId: g.userId, quantity: qty,
        unitPrice: unit.toFixed(2), fee: fee.toFixed(2), total: total.toFixed(2),
      }).returning();
      await applyWalletTx(tx, { userId: g.userId, type: WalletTxType.DEBIT, amount: -total, source: "TICKET", reference: ref, note: `${qty} × تذكرة ${ev.titleAr}`, actorId: g.userId });
      const [venue] = await tx.select({ id: organizations.id }).from(organizations).where(eq(organizations.slug, "tripoli-international-stadium"));
      if (venue) await creditProvider(tx, venue.id, unit * qty, ref, `بيع تذاكر ${ev.titleAr}`);
      await tx.insert(notifications).values({ userId: g.userId, titleAr: "تم شراء التذاكر", bodyAr: `${qty} تذكرة (${tier.nameAr}) – ${ev.titleAr} يوم ${ev.eventDate} الساعة ${ev.eventTime}. رقم الطلب ${ref}`, type: "TICKET", actionUrl: "/app/bookings" });
      return { ...o, tierName: tier.nameAr };
    });
    await audit({ userId: g.userId, action: "TICKETS_PURCHASED", entity: "TICKET_ORDER", entityId: order.orderRef, newValue: { qty: order.quantity, total: order.total } });
    return NextResponse.json(order, { status: 201 });
  } catch (e) {
    return safeError(e);
  }
}
