import { NextResponse } from "next/server";
import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { events, ticketTiers } from "@/db/schema";
import { safeError } from "@/lib/server/session";

export async function GET(_: Request, ctx: { params: Promise<{ slug: string }> }) {
  try {
    const { slug } = await ctx.params;
    const [e] = await db.select().from(events).where(eq(events.slug, slug));
    if (!e) return NextResponse.json({ error: "الفعالية غير موجودة" }, { status: 404 });
    const tiers = await db.select().from(ticketTiers).where(eq(ticketTiers.eventId, e.id)).orderBy(asc(ticketTiers.price));
    return NextResponse.json({ ...e, tiers: tiers.map((t) => ({ ...t, left: t.capacity - t.sold })) });
  } catch (e) {
    return safeError(e);
  }
}
