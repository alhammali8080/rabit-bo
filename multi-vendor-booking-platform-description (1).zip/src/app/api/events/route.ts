import { NextResponse } from "next/server";
import { and, asc, eq, gte, sql } from "drizzle-orm";
import { db } from "@/db";
import { events, ticketTiers } from "@/db/schema";
import { seedDatabase } from "@/db/seed";
import { safeError } from "@/lib/server/session";

export async function GET() {
  try {
    await seedDatabase();
    const today = new Date().toISOString().slice(0, 10);
    const rows = await db
      .select({ e: events, minPrice: sql<string>`min(${ticketTiers.price})`, left: sql<number>`sum(${ticketTiers.capacity} - ${ticketTiers.sold})::int` })
      .from(events)
      .leftJoin(ticketTiers, eq(ticketTiers.eventId, events.id))
      .where(and(eq(events.isActive, true), gte(events.eventDate, today)))
      .groupBy(events.id)
      .orderBy(asc(events.eventDate));
    return NextResponse.json(rows.map((r) => ({ ...r.e, minPrice: r.minPrice, left: r.left })));
  } catch (e) {
    return safeError(e);
  }
}
