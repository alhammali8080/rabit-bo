import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { busTrips, busSeats, organizations } from "@/db/schema";
import { safeError } from "@/lib/server/session";

export async function GET(_: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await ctx.params;
    const [row] = await db.select({ t: busTrips, operator: organizations.nameAr }).from(busTrips).innerJoin(organizations, eq(organizations.id, busTrips.operatorId)).where(eq(busTrips.id, Number(id)));
    if (!row) return NextResponse.json({ error: "الرحلة غير موجودة" }, { status: 404 });
    const taken = await db.select({ seatNo: busSeats.seatNo }).from(busSeats).where(eq(busSeats.tripId, row.t.id));
    return NextResponse.json({ ...row.t, operator: row.operator, amenities: JSON.parse(row.t.amenities), taken: taken.map((s) => s.seatNo) });
  } catch (e) {
    return safeError(e);
  }
}
