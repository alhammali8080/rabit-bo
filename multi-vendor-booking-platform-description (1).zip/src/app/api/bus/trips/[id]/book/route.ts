import { NextResponse } from "next/server";
import { randomBytes } from "crypto";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { busTrips, busSeats, notifications, WalletTxType } from "@/db/schema";
import { guard, safeError, UserError } from "@/lib/server/session";
import { applyWalletTx } from "@/lib/server/wallet";
import { creditProvider } from "@/lib/server/providerCredit";
import { audit } from "@/lib/server/audit";

const FEE_PER_SEAT = 1;

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const g = await guard({ roles: ["CUSTOMER"] });
  if (g instanceof NextResponse) return g;
  try {
    const { id } = await ctx.params;
    const body = await req.json();
    const seats: number[] = [...new Set((Array.isArray(body.seats) ? body.seats : []).map(Number))].filter((n) => Number.isInteger(n)) as number[];
    const passengerName = String(body.passengerName || g.fullName).trim().slice(0, 80);
    const [trip] = await db.select().from(busTrips).where(eq(busTrips.id, Number(id)));
    if (!trip || !trip.isActive) throw new UserError("الرحلة غير متاحة", 404);
    if (new Date(`${trip.tripDate}T${trip.departTime}:00`) < new Date()) throw new UserError("انطلقت هذه الرحلة");
    if (seats.length < 1 || seats.length > 6) throw new UserError("اختر من 1 إلى 6 مقاعد");
    if (seats.some((s) => s < 1 || s > trip.seatCount)) throw new UserError("رقم مقعد غير صالح");

    const price = parseFloat(trip.price);
    const total = price * seats.length + FEE_PER_SEAT * seats.length;
    const ref = `BUS-${randomBytes(4).toString("hex").toUpperCase()}`;

    try {
      await db.transaction(async (tx) => {
        // Unique index (trip_id, seat_no) guarantees a seat can't be sold twice, even under concurrency
        await tx.insert(busSeats).values(seats.map((seatNo) => ({ tripId: trip.id, seatNo, bookingRef: ref, userId: g.userId, passengerName, price: price.toFixed(2) })));
        await applyWalletTx(tx, { userId: g.userId, type: WalletTxType.DEBIT, amount: -total, source: "BUS", reference: ref, note: `رحلة ${trip.fromCity} ← ${trip.toCity} (${seats.length} مقعد)`, actorId: g.userId });
        await creditProvider(tx, trip.operatorId, price * seats.length, ref, `حجز مقاعد رحلة ${trip.fromCity}-${trip.toCity} ${trip.tripDate}`);
        await tx.insert(notifications).values({ userId: g.userId, titleAr: "تم حجز رحلتك", bodyAr: `${trip.fromCity} ← ${trip.toCity} يوم ${trip.tripDate} الساعة ${trip.departTime} – المقاعد ${seats.join("، ")}. رقم الحجز ${ref}`, type: "BUS", actionUrl: "/app/bookings" });
      });
    } catch (e) {
      if ((e as { code?: string; cause?: { code?: string } }).code === "23505" || (e as { cause?: { code?: string } }).cause?.code === "23505") {
        throw new UserError("أحد المقاعد المختارة حُجز للتو، اختر مقعداً آخر", 409);
      }
      throw e;
    }
    await audit({ userId: g.userId, action: "BUS_SEATS_BOOKED", entity: "BUS_TRIP", entityId: ref, newValue: { tripId: trip.id, seats, total } });
    return NextResponse.json({ bookingRef: ref, seats, total: total.toFixed(2) }, { status: 201 });
  } catch (e) {
    return safeError(e);
  }
}
