import { NextResponse } from "next/server";
import { and, asc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { busTrips, busSeats, organizations } from "@/db/schema";
import { seedDatabase, ensureBusTrips } from "@/db/seed";
import { safeError } from "@/lib/server/session";

export async function GET(req: Request) {
  try {
    await seedDatabase();
    await ensureBusTrips();
    const sp = new URL(req.url).searchParams;
    const from = sp.get("from"), to = sp.get("to"), date = sp.get("date");
    if (!from && !to && !date) {
      const cities = await db.selectDistinct({ c: busTrips.fromCity }).from(busTrips);
      return NextResponse.json({ cities: cities.map((c) => c.c).sort() });
    }
    const now = new Date();
    const today = now.toISOString().slice(0, 10);
    const hhmm = now.toISOString().slice(11, 16);
    const rows = await db
      .select({ t: busTrips, operator: organizations.nameAr, booked: sql<number>`count(${busSeats.id})::int` })
      .from(busTrips)
      .innerJoin(organizations, eq(organizations.id, busTrips.operatorId))
      .leftJoin(busSeats, eq(busSeats.tripId, busTrips.id))
      .where(and(
        eq(busTrips.isActive, true),
        from ? eq(busTrips.fromCity, from) : undefined,
        to ? eq(busTrips.toCity, to) : undefined,
        date ? eq(busTrips.tripDate, date) : undefined,
        date === today ? sql`${busTrips.departTime} > ${hhmm}` : undefined,
      ))
      .groupBy(busTrips.id, organizations.nameAr)
      .orderBy(asc(busTrips.tripDate), asc(busTrips.departTime))
      .limit(50);
    return NextResponse.json({ trips: rows.map((r) => ({ ...r.t, operator: r.operator, seatsLeft: r.t.seatCount - r.booked, amenities: JSON.parse(r.t.amenities) })) });
  } catch (e) {
    return safeError(e);
  }
}
