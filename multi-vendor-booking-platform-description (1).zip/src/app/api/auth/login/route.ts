import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { and, eq, gt, sql } from "drizzle-orm";
import { db } from "@/db";
import { users, auditLogs } from "@/db/schema";
import { createSessionCookie, safeError } from "@/lib/server/session";
import { audit } from "@/lib/server/audit";
import { homeForRole } from "@/lib/rbac";
import { normalizePhone } from "@/lib/phone";
import { seedDatabase } from "@/db/seed";
import { PORTALS, portalForRole, type PortalKey } from "@/lib/portals";

export async function POST(req: Request) {
  try {
    await seedDatabase();
    const body = await req.json().catch(() => ({}));
    const phone = normalizePhone(body.phone);
    const password = String(body.password || "");
    if (!phone || !password) return NextResponse.json({ error: "أدخل رقم الهاتف وكلمة المرور" }, { status: 400 });

    // Brute-force protection: 5 failed attempts per phone in 15 minutes
    const [{ n }] = await db
      .select({ n: sql<number>`count(*)::int` })
      .from(auditLogs)
      .where(and(eq(auditLogs.action, "LOGIN_FAILED"), eq(auditLogs.entityId, phone), gt(auditLogs.createdAt, sql`now() - interval '15 minutes'`)));
    if (n >= 5) return NextResponse.json({ error: "محاولات كثيرة، حاول بعد 15 دقيقة" }, { status: 429 });

    const [user] = await db.select().from(users).where(eq(users.phone, phone));
    const ok = user ? await bcrypt.compare(password, user.passwordHash) : false;
    if (!user || !ok) {
      await audit({ action: "LOGIN_FAILED", entity: "AUTH", entityId: phone, result: "FAILED" });
      return NextResponse.json({ error: "رقم الهاتف أو كلمة المرور غير صحيحة" }, { status: 401 });
    }
    if (!user.isActive) return NextResponse.json({ error: "الحساب موقوف، تواصل مع الدعم" }, { status: 403 });

    // Each portal accepts only its own roles
    const portal = body.portal as PortalKey | undefined;
    if (portal && PORTALS[portal] && !PORTALS[portal].roles.includes(user.role)) {
      const right = portalForRole(user.role);
      return NextResponse.json(
        { error: `هذا الحساب يخص «${PORTALS[right].title}». استخدم البوابة الصحيحة.`, rightPortal: right },
        { status: 403 }
      );
    }

    const token = await createSessionCookie(user);
    await audit({ userId: user.id, action: "LOGIN", entity: "AUTH", entityId: user.id });
    return NextResponse.json({ ok: true, redirect: homeForRole(user.role), token });
  } catch (e) {
    return safeError(e);
  }
}
