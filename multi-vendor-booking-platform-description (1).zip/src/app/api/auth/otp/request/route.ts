import { NextResponse } from "next/server";
import { randomInt } from "crypto";
import { and, eq, gt, sql } from "drizzle-orm";
import { db } from "@/db";
import { otpCodes } from "@/db/schema";
import { hashOtp } from "@/lib/server/cards";
import { requestMeta, safeError } from "@/lib/server/session";
import { seedDatabase } from "@/db/seed";

const PHONE_RE = /^\+?[0-9]{9,15}$/;

export async function POST(req: Request) {
  try {
    await seedDatabase();
    const { phone: raw } = await req.json();
    const phone = String(raw || "").replace(/\s/g, "");
    if (!PHONE_RE.test(phone)) return NextResponse.json({ error: "رقم الهاتف غير صالح" }, { status: 400 });

    const { ip } = await requestMeta();
    // Rate limit: max 3 per phone / 10 min, max 10 per IP / 10 min
    const since = sql`now() - interval '10 minutes'`;
    const [{ n: perPhone }] = await db
      .select({ n: sql<number>`count(*)::int` })
      .from(otpCodes)
      .where(and(eq(otpCodes.phone, phone), gt(otpCodes.createdAt, since)));
    const [{ n: perIp }] = await db
      .select({ n: sql<number>`count(*)::int` })
      .from(otpCodes)
      .where(and(eq(otpCodes.ipAddress, ip), gt(otpCodes.createdAt, since)));
    if (perPhone >= 3 || perIp >= 10) {
      return NextResponse.json({ error: "طلبات كثيرة، يرجى المحاولة بعد 10 دقائق" }, { status: 429 });
    }

    const code = String(randomInt(100000, 999999));
    await db.insert(otpCodes).values({
      phone,
      codeHash: hashOtp(phone, code),
      ipAddress: ip,
      expiresAt: new Date(Date.now() + 5 * 60 * 1000),
    });

    // TODO(SMS): when SMS_API_KEY is configured, send `code` via the Libyan SMS gateway
    // (e.g. Libyana/Almadar aggregator) and never return it in the response.
    const smsConfigured = !!process.env.SMS_API_KEY;
    return NextResponse.json({
      ok: true,
      message: "تم إرسال رمز التحقق",
      ...(smsConfigured ? {} : { devCode: code }),
    });
  } catch (e) {
    return safeError(e);
  }
}
