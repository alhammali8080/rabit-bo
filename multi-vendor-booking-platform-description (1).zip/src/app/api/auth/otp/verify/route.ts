import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { randomBytes } from "crypto";
import { and, desc, eq, gt, sql } from "drizzle-orm";
import { db } from "@/db";
import { otpCodes, users, UserRole } from "@/db/schema";
import { hashOtp } from "@/lib/server/cards";
import { createSessionCookie, safeError } from "@/lib/server/session";
import { audit } from "@/lib/server/audit";
import { homeForRole } from "@/lib/rbac";
import { getWallet } from "@/lib/server/wallet";

export async function POST(req: Request) {
  try {
    const { phone: raw, code, fullName } = await req.json();
    const phone = String(raw || "").replace(/\s/g, "");
    const [otp] = await db
      .select()
      .from(otpCodes)
      .where(and(eq(otpCodes.phone, phone), eq(otpCodes.consumed, false), gt(otpCodes.expiresAt, sql`now()`)))
      .orderBy(desc(otpCodes.createdAt))
      .limit(1);

    if (!otp) return NextResponse.json({ error: "انتهت صلاحية الرمز، اطلب رمزاً جديداً" }, { status: 400 });
    if (otp.attempts >= 5) {
      await db.update(otpCodes).set({ consumed: true }).where(eq(otpCodes.id, otp.id));
      return NextResponse.json({ error: "محاولات كثيرة، اطلب رمزاً جديداً" }, { status: 429 });
    }
    if (otp.codeHash !== hashOtp(phone, String(code || "").trim())) {
      await db.update(otpCodes).set({ attempts: otp.attempts + 1 }).where(eq(otpCodes.id, otp.id));
      await audit({ action: "LOGIN_FAILED", entity: "AUTH", entityId: phone, result: "FAILED" });
      return NextResponse.json({ error: "رمز التحقق غير صحيح" }, { status: 401 });
    }
    await db.update(otpCodes).set({ consumed: true }).where(eq(otpCodes.id, otp.id));

    let [user] = await db.select().from(users).where(eq(users.phone, phone));
    if (!user) {
      if (!fullName || String(fullName).trim().length < 3) {
        return NextResponse.json({ needsName: true, error: "أدخل اسمك لإكمال إنشاء الحساب" }, { status: 422 });
      }
      [user] = await db
        .insert(users)
        .values({
          phone,
          fullName: String(fullName).trim().slice(0, 80),
          role: UserRole.CUSTOMER, // self-signup is ALWAYS a customer
          passwordHash: await bcrypt.hash(randomBytes(16).toString("hex"), 10),
          isPhoneVerified: true,
        })
        .returning();
      await getWallet(user.id);
    }
    if (!user.isActive) return NextResponse.json({ error: "الحساب موقوف" }, { status: 403 });

    await createSessionCookie(user);
    await audit({ userId: user.id, action: "LOGIN", entity: "AUTH", entityId: user.id });
    return NextResponse.json({ ok: true, redirect: homeForRole(user.role) });
  } catch (e) {
    return safeError(e);
  }
}
