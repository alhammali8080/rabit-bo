import { NextResponse } from "next/server";
import { clearSessionCookie, getSession } from "@/lib/server/session";
import { audit } from "@/lib/server/audit";

export async function POST() {
  const s = await getSession();
  if (s) await audit({ userId: s.userId, action: "LOGOUT", entity: "AUTH", entityId: s.userId });
  await clearSessionCookie();
  return NextResponse.json({ ok: true });
}
