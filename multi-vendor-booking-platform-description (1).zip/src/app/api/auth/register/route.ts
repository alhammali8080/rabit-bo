import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users, UserRole } from "@/db/schema";
import { createSessionCookie, safeError } from "@/lib/server/session";
import { audit } from "@/lib/server/audit";
import { getWallet } from "@/lib/server/wallet";
import { normalizePhone, isValidPhone } from "@/lib/phone";

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => ({}));
    const phone = normalizePhone(body.phone);
    const fullName = String(body.fullName || "").trim().slice(0, 80);
    const password = String(body.password || "");
    if (fullName.length < 3) return NextResponse.json({ error: "أدخل الاسم كاملاً" }, { status: 400 });
    if (!isValidPhone(phone)) return NextResponse.json({ error: "رقم الهاتف غير صحيح (مثال: 0912345678)" }, { status: 400 });
    if (password.length < 6) return NextResponse.json({ error: "كلمة المرور 6 أحرف على الأقل" }, { status: 400 });

    const [exists] = await db.select({ id: users.id }).from(users).where(eq(users.phone, phone));
    if (exists) return NextResponse.json({ error: "هذا الرقم مسجل مسبقاً، سجّل الدخول" }, { status: 409 });

    const [user] = await db
      .insert(users)
      .values({ fullName, phone, role: UserRole.CUSTOMER, passwordHash: await bcrypt.hash(password, 10) })
      .returning();
    await getWallet(user.id);
    const token = await createSessionCookie(user);
    await audit({ userId: user.id, action: "REGISTER", entity: "AUTH", entityId: user.id });
    return NextResponse.json({ ok: true, redirect: "/app", token });
  } catch (e) {
    return safeError(e);
  }
}
