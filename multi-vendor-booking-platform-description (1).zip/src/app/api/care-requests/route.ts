import { NextResponse } from "next/server";
import { randomBytes } from "crypto";
import { and, desc, eq, gt, sql } from "drizzle-orm";
import { db } from "@/db";
import { careRequests, users, notifications, UserRole } from "@/db/schema";
import { getSession, guard, safeError, UserError } from "@/lib/server/session";
import { audit } from "@/lib/server/audit";
import { normalizePhone, isValidPhone } from "@/lib/phone";
import { P } from "@/lib/rbac";

const NEEDS = ["CONSULT", "DENTAL", "LAB", "CHECKUP", "SURGERY", "DERMA", "OTHER"];
const WHO = ["SELF", "FAMILY", "CHILD", "PARENT"];

// Public: submit a request for a health advisor to call back
export async function POST(req: Request) {
  try {
    const b = await req.json().catch(() => ({}));
    const phone = normalizePhone(b.phone);
    if (!b.fullName || String(b.fullName).trim().length < 3) throw new UserError("أدخل الاسم");
    if (!isValidPhone(phone)) throw new UserError("رقم الهاتف غير صحيح");
    if (!NEEDS.includes(b.needType) || !WHO.includes(b.forWhom)) throw new UserError("اختر نوع الخدمة والمستفيد");

    // Anti-spam: max 3 requests per phone per day
    const [{ n }] = await db
      .select({ n: sql<number>`count(*)::int` })
      .from(careRequests)
      .where(and(eq(careRequests.phone, phone), gt(careRequests.createdAt, sql`now() - interval '1 day'`)));
    if (n >= 3) throw new UserError("تم استلام طلباتك، سيتواصل معك المستشار قريباً", 429);

    const s = await getSession();
    const [row] = await db
      .insert(careRequests)
      .values({
        requestRef: `CARE-${randomBytes(3).toString("hex").toUpperCase()}`,
        userId: s?.userId ?? null,
        fullName: String(b.fullName).trim().slice(0, 80),
        phone,
        needType: b.needType,
        forWhom: b.forWhom,
        age: b.age ? Math.max(0, Math.min(120, Number(b.age))) : null,
        city: String(b.city || "طرابلس").slice(0, 40),
        budget: b.budget ? String(b.budget).slice(0, 20) : null,
        preferredDate: b.preferredDate ? String(b.preferredDate).slice(0, 10) : null,
        notes: b.notes ? String(b.notes).slice(0, 500) : null,
      })
      .returning();

    // Notify admins & support agents
    const staffUsers = await db.select({ id: users.id }).from(users).where(sql`${users.role} in (${UserRole.PLATFORM_ADMIN}, ${UserRole.SUPPORT_AGENT})`);
    if (staffUsers.length) {
      await db.insert(notifications).values(
        staffUsers.map((u) => ({ userId: u.id, titleAr: "طلب استشارة صحية جديد", bodyAr: `${row.fullName} – ${row.city} (${row.requestRef})`, type: "CARE_REQUEST", actionUrl: "/admin?tab=care" }))
      );
    }
    return NextResponse.json({ ok: true, requestRef: row.requestRef }, { status: 201 });
  } catch (e) {
    return safeError(e);
  }
}

// Admin/support: list & update requests
export async function GET() {
  const g = await guard({ perm: P.USERS_MANAGE });
  if (g instanceof NextResponse) return g;
  const rows = await db.select().from(careRequests).orderBy(desc(careRequests.createdAt)).limit(100);
  return NextResponse.json(rows);
}

export async function PATCH(req: Request) {
  const g = await guard({ perm: P.USERS_MANAGE });
  if (g instanceof NextResponse) return g;
  try {
    const { id, status } = await req.json();
    if (!["NEW", "CONTACTED", "BOOKED", "CLOSED"].includes(status)) throw new UserError("حالة غير صالحة");
    await db.update(careRequests).set({ status, assignedTo: g.userId }).where(eq(careRequests.id, Number(id)));
    await audit({ userId: g.userId, action: "CARE_REQUEST_STATUS", entity: "CARE_REQUEST", entityId: id, newValue: status });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return safeError(e);
  }
}
