import { NextResponse } from "next/server";
import { getSession } from "@/lib/server/session";
import { getActiveVip } from "@/lib/server/wallet";
import { homeForRole } from "@/lib/rbac";

export async function GET() {
  const s = await getSession();
  if (!s) return NextResponse.json({ user: null });
  const vip = s.role === "CUSTOMER" ? await getActiveVip(s.userId) : null;
  return NextResponse.json({
    user: { ...s, home: homeForRole(s.role) },
    vip: vip ? { endsAt: vip.membership.endsAt, startsAt: vip.membership.startsAt } : null,
  });
}
