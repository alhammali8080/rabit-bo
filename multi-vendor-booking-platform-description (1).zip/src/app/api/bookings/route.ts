import { NextResponse } from "next/server";
import { and, desc, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  bookings,
  organizations,
  services,
  branches,
  wallets,
  ledgerEntries,
  notifications,
  BookingStatus,
  PaymentStatus,
  WalletTxType,
  VipBenefitKey,
} from "@/db/schema";
import { getSession, safeError, UserError } from "@/lib/server/session";
import { applyWalletTx, getActiveVip } from "@/lib/server/wallet";
import { audit } from "@/lib/server/audit";

const BASE_CUSTOMER_FEE = 2.0;
const TIME_RE = /^([01]\d|2[0-3]):[0-5]\d$/;
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

// GET: public lookup by ref (limited fields) OR the signed-in customer's own bookings
export async function GET(req: Request) {
  try {
    const ref = new URL(req.url).searchParams.get("bookingRef");
    if (ref) {
      const [b] = await db.select().from(bookings).where(eq(bookings.bookingRef, ref.trim().toUpperCase()));
      if (!b) return NextResponse.json({ error: "لم يتم العثور على الحجز" }, { status: 404 });
      return NextResponse.json({
        bookingRef: b.bookingRef,
        bookingDate: b.bookingDate,
        startTime: b.startTime,
        status: b.status,
        totalPrice: b.totalPrice,
        customerName: b.customerName.split(" ")[0] + " ***", // privacy
      });
    }
    const s = await getSession();
    if (!s) return NextResponse.json({ error: "يرجى تسجيل الدخول" }, { status: 401 });
    const rows = await db
      .select({
        b: bookings,
        orgName: organizations.nameAr,
        serviceName: services.nameAr,
        policy: organizations.cancellationPolicyAr,
      })
      .from(bookings)
      .innerJoin(organizations, eq(organizations.id, bookings.organizationId))
      .innerJoin(services, eq(services.id, bookings.serviceId))
      .where(eq(bookings.customerId, s.userId))
      .orderBy(desc(bookings.createdAt))
      .limit(100);
    return NextResponse.json(rows.map((r) => ({ ...r.b, organizationName: r.orgName, serviceName: r.serviceName, policy: r.policy })));
  } catch (e) {
    return safeError(e);
  }
}

export async function POST(req: Request) {
  try {
    const s = await getSession();
    if (!s) return NextResponse.json({ error: "يرجى تسجيل الدخول لإتمام الحجز" }, { status: 401 });
    if (s.role !== "CUSTOMER") return NextResponse.json({ error: "الحجز من هذه الواجهة متاح للعملاء فقط" }, { status: 403 });

    const body = await req.json();
    const { organizationId, branchId, serviceId, staffId, bookingDate, startTime, notes } = body;
    const paymentMethod: "WALLET" | "CASH" = body.paymentMethod === "WALLET" ? "WALLET" : "CASH";
    if (!organizationId || !serviceId || !DATE_RE.test(bookingDate || "") || !TIME_RE.test(startTime || "")) {
      return NextResponse.json({ error: "بيانات الحجز غير مكتملة" }, { status: 400 });
    }
    if (new Date(`${bookingDate}T${startTime}:00`) < new Date()) {
      return NextResponse.json({ error: "لا يمكن الحجز في وقت سابق" }, { status: 400 });
    }

    const [org] = await db.select().from(organizations).where(eq(organizations.id, Number(organizationId)));
    const [srv] = await db.select().from(services).where(eq(services.id, Number(serviceId)));
    if (!org || !srv || srv.organizationId !== org.id) return NextResponse.json({ error: "الخدمة غير متاحة" }, { status: 404 });

    let branchToUse = branchId ? Number(branchId) : srv.branchId;
    if (!branchToUse) {
      const [b] = await db.select().from(branches).where(eq(branches.organizationId, org.id)).limit(1);
      branchToUse = b?.id ?? null;
    }
    if (!branchToUse) return NextResponse.json({ error: "لا يوجد فرع متاح" }, { status: 400 });

    const [h, m] = startTime.split(":").map(Number);
    const endTotal = h * 60 + m + (srv.durationMinutes || 60);
    const endTime = `${String(Math.floor(endTotal / 60) % 24).padStart(2, "0")}:${String(endTotal % 60).padStart(2, "0")}`;

    // Pricing (server-side only; client values are ignored)
    const vip = await getActiveVip(s.userId);
    const feeDiscount = vip?.map[VipBenefitKey.FEE_DISCOUNT_PERCENT] ?? 0;
    const price = parseFloat(srv.price);
    const customerFee = Math.max(0, Math.round(BASE_CUSTOMER_FEE * (100 - feeDiscount)) / 100);
    const commissionPercent = parseFloat(srv.customCommissionPercent || org.customCommissionPercent || "5.00");
    const platformFee = Math.round(price * commissionPercent) / 100;
    const providerNet = price - platformFee;
    const total = price + customerFee;
    const bookingRef = `RBT-${new Date().getFullYear()}-${Math.floor(100000 + Math.random() * 900000)}`;

    const created = await db.transaction(async (tx) => {
      // Serialize concurrent attempts for the same branch/day (Postgres advisory xact lock)
      await tx.execute(sql`SELECT pg_advisory_xact_lock(${Number(branchToUse)}::int, ${Number(bookingDate.replace(/-/g, "")) % 2147483647}::int)`);
      const clash = await tx
        .select({ id: bookings.id, startTime: bookings.startTime, endTime: bookings.endTime })
        .from(bookings)
        .where(
          and(
            eq(bookings.branchId, branchToUse!),
            eq(bookings.bookingDate, bookingDate),
            inArray(bookings.status, [BookingStatus.CONFIRMED, BookingStatus.PENDING]),
            staffId ? eq(bookings.staffId, Number(staffId)) : undefined
          )
        );
      const toMin = (t: string) => Number(t.slice(0, 2)) * 60 + Number(t.slice(3, 5));
      const sMin = h * 60 + m;
      if (clash.some((c) => sMin < toMin(c.endTime) && toMin(c.startTime) < endTotal)) {
        throw new UserError("عذراً، هذا الموعد لم يعد متاحاً. يرجى اختيار موعد آخر.", 409);
      }

      const [b] = await tx
        .insert(bookings)
        .values({
          bookingRef,
          organizationId: org.id,
          branchId: branchToUse!,
          serviceId: srv.id,
          staffId: staffId ? Number(staffId) : null,
          customerId: s.userId,
          customerName: s.fullName,
          customerPhone: s.phone,
          bookingDate,
          startTime,
          endTime,
          price: price.toFixed(2),
          customerFee: customerFee.toFixed(2),
          totalPrice: total.toFixed(2),
          commissionPercent: commissionPercent.toFixed(2),
          platformFee: platformFee.toFixed(2),
          providerNet: providerNet.toFixed(2),
          currency: org.currency,
          status: BookingStatus.CONFIRMED,
          paymentStatus: paymentMethod === "WALLET" ? PaymentStatus.PAID : PaymentStatus.PAY_AT_VENUE,
          paymentMethod,
          notes: String(notes || "").slice(0, 500),
        })
        .returning();

      if (paymentMethod === "WALLET") {
        // Same transaction: if the debit fails (insufficient funds), the booking is rolled back too.
        await applyWalletTx(tx, {
          userId: s.userId,
          type: WalletTxType.DEBIT,
          amount: -total,
          source: "BOOKING",
          reference: bookingRef,
          note: `حجز ${srv.nameAr}`,
          actorId: s.userId,
        });
        await tx.insert(ledgerEntries).values({
          organizationId: org.id,
          bookingId: b.id,
          transactionType: "BOOKING_PAYMENT",
          grossAmount: price.toFixed(2),
          platformFee: platformFee.toFixed(2),
          netAmount: providerNet.toFixed(2),
          currency: org.currency,
          description: `حجز مدفوع بالمحفظة ${bookingRef}`,
          reference: bookingRef,
        });
        const [pw] = await tx.select().from(wallets).where(eq(wallets.organizationId, org.id)).for("update");
        if (pw) {
          await tx
            .update(wallets)
            .set({
              pendingSettlement: (parseFloat(pw.pendingSettlement) + providerNet).toFixed(2),
              totalEarned: (parseFloat(pw.totalEarned) + price).toFixed(2),
              totalCommissionPaid: (parseFloat(pw.totalCommissionPaid) + platformFee).toFixed(2),
              updatedAt: new Date(),
            })
            .where(eq(wallets.id, pw.id));
        }
      }

      await tx.insert(notifications).values([
        { userId: org.ownerId, organizationId: org.id, titleAr: "حجز جديد", bodyAr: `${s.fullName} حجز ${srv.nameAr} يوم ${bookingDate} الساعة ${startTime}`, type: "BOOKING_CREATED", actionUrl: "/provider" },
        { userId: s.userId, titleAr: "تم تأكيد حجزك", bodyAr: `حجزك ${bookingRef} في ${org.nameAr} يوم ${bookingDate} الساعة ${startTime}`, type: "BOOKING_CONFIRMED", actionUrl: "/app/bookings" },
      ]);
      return b;
    });

    await audit({ userId: s.userId, action: "BOOKING_CREATED", entity: "BOOKING", entityId: created.bookingRef, newValue: { total, paymentMethod } });
    return NextResponse.json({ ...created, serviceName: srv.nameAr, organizationName: org.nameAr }, { status: 201 });
  } catch (e) {
    return safeError(e);
  }
}
