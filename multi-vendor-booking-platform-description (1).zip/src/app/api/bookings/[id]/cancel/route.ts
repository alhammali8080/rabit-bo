import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { bookings, ledgerEntries, notifications, BookingStatus, PaymentStatus, WalletTxType } from "@/db/schema";
import { getSession, hasPerm, forbidden, safeError, UserError } from "@/lib/server/session";
import { applyWalletTx } from "@/lib/server/wallet";
import { audit } from "@/lib/server/audit";
import { P } from "@/lib/rbac";
import { refundPercent } from "@/lib/policy";


export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const s = await getSession();
    if (!s) return NextResponse.json({ error: "يرجى تسجيل الدخول" }, { status: 401 });
    const { id } = await ctx.params;
    const { reason } = await req.json().catch(() => ({ reason: "" }));

    const [pre] = await db.select().from(bookings).where(eq(bookings.id, Number(id)));
    if (!pre) return NextResponse.json({ error: "الحجز غير موجود" }, { status: 404 });

    const isOwner = s.role === "CUSTOMER" && pre.customerId === s.userId;
    const isProvider = s.organizationId === pre.organizationId && hasPerm(s, P.BOOKINGS_CANCEL);
    if (!isOwner && !isProvider) return forbidden();

    const result = await db.transaction(async (tx) => {
      const [b] = await tx.select().from(bookings).where(eq(bookings.id, pre.id)).for("update");
      if (b.status !== BookingStatus.CONFIRMED && b.status !== BookingStatus.PENDING) {
        throw new UserError("لا يمكن إلغاء هذا الحجز في حالته الحالية", 409);
      }
      const hours = (new Date(`${b.bookingDate}T${b.startTime}:00`).getTime() - Date.now()) / 3600000;
      const pct = refundPercent(hours, isProvider && !isOwner);
      const paidByWallet = b.paymentMethod === "WALLET" && b.paymentStatus === PaymentStatus.PAID;
      const refund = paidByWallet ? Math.round(parseFloat(b.totalPrice) * pct) / 100 : 0;

      await tx
        .update(bookings)
        .set({
          status: BookingStatus.CANCELLED,
          paymentStatus: refund > 0 ? PaymentStatus.REFUNDED : b.paymentStatus,
          cancellationReason: `${String(reason || "بدون سبب").slice(0, 200)} | سياسة: استرداد ${pct}%`,
          updatedAt: new Date(),
        })
        .where(eq(bookings.id, b.id));

      if (refund > 0 && b.customerId) {
        await applyWalletTx(tx, {
          userId: b.customerId,
          type: WalletTxType.REFUND,
          amount: refund,
          source: "CANCELLATION",
          reference: b.bookingRef,
          note: `استرداد ${pct}% لإلغاء الحجز`,
          actorId: s.userId,
        });
        await tx.insert(ledgerEntries).values({
          organizationId: b.organizationId,
          bookingId: b.id,
          transactionType: "REFUND",
          grossAmount: (-refund).toFixed(2),
          netAmount: (-refund).toFixed(2),
          currency: b.currency,
          description: `استرداد ${pct}% للحجز ${b.bookingRef}`,
          reference: b.bookingRef,
        });
      }
      if (b.customerId) {
        await tx.insert(notifications).values({
          userId: b.customerId,
          titleAr: "تم إلغاء الحجز",
          bodyAr: `تم إلغاء الحجز ${b.bookingRef}${refund ? `، وتم إرجاع ${refund.toFixed(2)} د.ل إلى محفظتك` : ""}`,
          type: "BOOKING_CANCELLED",
          actionUrl: "/app/bookings",
        });
      }
      return { refund, pct, ref: b.bookingRef };
    });

    await audit({ userId: s.userId, action: "BOOKING_CANCELLED", entity: "BOOKING", entityId: result.ref, newValue: result });
    return NextResponse.json({ ok: true, ...result });
  } catch (e) {
    return safeError(e);
  }
}
