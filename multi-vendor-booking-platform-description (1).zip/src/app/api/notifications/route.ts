import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { guard, safeError } from "@/lib/server/session";

export async function GET() {
  const g = await guard();
  if (g instanceof NextResponse) return g;
  const rows = await db.select().from(notifications).where(eq(notifications.userId, g.userId)).orderBy(desc(notifications.createdAt)).limit(50);
  return NextResponse.json(rows);
}

export async function POST() {
  const g = await guard();
  if (g instanceof NextResponse) return g;
  try {
    await db.update(notifications).set({ isRead: true }).where(eq(notifications.userId, g.userId));
    return NextResponse.json({ ok: true });
  } catch (e) {
    return safeError(e);
  }
}
