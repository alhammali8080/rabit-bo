import { NextResponse } from "next/server";
import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { bookings, ledgerEntries } from "@/db/schema";
import { guard, safeError } from "@/lib/server/session";
import { P } from "@/lib/rbac";

// Returns 403 for anyone without finance.view – data is never sent.
export async function GET() {
  const g = await guard({ tenant: true, perm: P.FINANCE_VIEW });
  if (g instanceof NextResponse) return g;
  try {
    const org = g.organizationId!;
    const [sum] = await db
      .select({
        gross: sql<string>`coalesce(sum(${bookings.price}),0)`,
        fees: sql<string>`coalesce(sum(${bookings.platformFee}),0)`,
        net: sql<string>`coalesce(sum(${bookings.providerNet}),0)`,
        count: sql<number>`count(*)::int`,
      })
      .from(bookings)
      .where(and(eq(bookings.organizationId, org), sql`${bookings.status} in ('CONFIRMED','COMPLETED')`));
    const ledger = await db.select().from(ledgerEntries).where(eq(ledgerEntries.organizationId, org)).orderBy(sql`${ledgerEntries.createdAt} desc`).limit(30);
    return NextResponse.json({ summary: sum, ledger });
  } catch (e) {
    return safeError(e);
  }
}
