import { NextResponse } from "next/server";
import { db } from "@/db";
import { services } from "@/db/schema";
import { guard, safeError, UserError } from "@/lib/server/session";
import { audit } from "@/lib/server/audit";
import { P } from "@/lib/rbac";

export async function POST(req: Request) {
  const g = await guard({ tenant: true, perm: P.SERVICES_MANAGE });
  if (g instanceof NextResponse) return g;
  try {
    const { nameAr, descriptionAr, durationMinutes, price } = await req.json();
    const pr = parseFloat(price);
    const dur = Number(durationMinutes) || 60;
    if (!nameAr || !(pr > 0) || dur < 5 || dur > 1440) throw new UserError("بيانات الخدمة غير صحيحة");
    const [srv] = await db
      .insert(services)
      .values({ organizationId: g.organizationId!, nameAr: String(nameAr).slice(0, 120), descriptionAr: String(descriptionAr || "").slice(0, 500), durationMinutes: dur, price: pr.toFixed(2) })
      .returning();
    await audit({ userId: g.userId, action: "SERVICE_CREATED", entity: "SERVICE", entityId: srv.id, newValue: { nameAr, price: pr } });
    return NextResponse.json(srv, { status: 201 });
  } catch (e) {
    return safeError(e);
  }
}
