import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { ticketOrders, ticketTiers, events, busSeats, busTrips, organizations } from "@/db/schema";
import { guard, safeError } from "@/lib/server/session";

export async function GET() {
  const g = await guard({ roles: ["CUSTOMER"] });
  if (g instanceof NextResponse) return g;
  try {
    const tickets = await db
      .select({ o: ticketOrders, title: events.titleAr, venue: events.venueAr, date: events.eventDate, time: events.eventTime, tier: ticketTiers.nameAr })
      .from(ticketOrders).innerJoin(events, eq(events.id, ticketOrders.eventId)).innerJoin(ticketTiers, eq(ticketTiers.id, ticketOrders.tierId))
      .where(eq(ticketOrders.userId, g.userId)).orderBy(desc(ticketOrders.createdAt));
    const seats = await db
      .select({ s: busSeats, t: busTrips, operator: organizations.nameAr })
      .from(busSeats).innerJoin(busTrips, eq(busTrips.id, busSeats.tripId)).innerJoin(organizations, eq(organizations.id, busTrips.operatorId))
      .where(eq(busSeats.userId, g.userId)).orderBy(desc(busSeats.createdAt));
    const trips = new Map<string, { ref: string; from: string; to: string; date: string; time: string; operator: string; station: string; seats: number[]; total: number }>();
    for (const r of seats) {
      const x = trips.get(r.s.bookingRef) || { ref: r.s.bookingRef, from: r.t.fromCity, to: r.t.toCity, date: r.t.tripDate, time: r.t.departTime, operator: r.operator, station: r.t.stationAr, seats: [], total: 0 };
      x.seats.push(r.s.seatNo); x.total += parseFloat(r.s.price) + 1;
      trips.set(r.s.bookingRef, x);
    }
    return NextResponse.json({ tickets: tickets.map((t) => ({ ...t.o, title: t.title, venue: t.venue, date: t.date, time: t.time, tier: t.tier })), trips: [...trips.values()] });
  } catch (e) {
    return safeError(e);
  }
}
