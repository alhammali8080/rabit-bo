import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { randomBytes } from "crypto";
import { eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { users, UserRole } from "@/db/schema";
import { guard, safeError, UserError } from "@/lib/server/session";
import { audit } from "@/lib/server/audit";
import { P } from "@/lib/rbac";

const ADMIN_ROLES = [UserRole.PLATFORM_ADMIN, UserRole.SUPPORT_AGENT, UserRole.SUPER_ADMIN];

export async function GET() {
  const g = await guard({ perm: P.ADMINS_MANAGE });
  if (g instanceof NextResponse) return g;
  const rows = await db
    .select({ id: users.id, fullName: users.fullName, phone: users.phone, role: users.role, isActive: users.isActive })
    .from(users)
    .where(inArray(users.role, ADMIN_ROLES));
  return NextResponse.json(rows);
}

// Create an admin / support agent
export async function POST(req: Request) {
  const g = await guard({ perm: P.ADMINS_MANAGE });
  if (g instanceof NextResponse) return g;
  try {
    const { fullName, phone, role } = await req.json();
    const ph = String(phone || "").replace(/\s/g, "");
    if (![UserRole.PLATFORM_ADMIN, UserRole.SUPPORT_AGENT].includes(role)) throw new UserError("الدور غير مسموح");
    if (!fullName || !/^\+?[0-9]{9,15}$/.test(ph)) throw new UserError("الاسم ورقم الهاتف مطلوبان");
    const [ex] = await db.select().from(users).where(eq(users.phone, ph));
    if (ex && ex.role !== UserRole.CUSTOMER) throw new UserError("الرقم مرتبط بدور آخر", 409);
    if (ex) await db.update(users).set({ role }).where(eq(users.id, ex.id));
    else await db.insert(users).values({ fullName, phone: ph, role, passwordHash: await bcrypt.hash(randomBytes(16).toString("hex"), 10) });
    await audit({ userId: g.userId, action: "ADMIN_CREATED", entity: "USER", entityId: ph, oldValue: ex?.role ?? null, newValue: role });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return safeError(e);
  }
}

// Change role or deactivate an admin (demote to CUSTOMER removes admin access)
export async function PATCH(req: Request) {
  const g = await guard({ perm: P.ADMINS_MANAGE });
  if (g instanceof NextResponse) return g;
  try {
    const { userId, role, isActive } = await req.json();
    if (Number(userId) === g.userId) throw new UserError("لا يمكنك تعديل حسابك", 403);
    const [u] = await db.select().from(users).where(eq(users.id, Number(userId)));
    if (!u || !(ADMIN_ROLES as string[]).includes(u.role)) throw new UserError("ليس حساباً إدارياً", 404);
    if (u.role === UserRole.SUPER_ADMIN) throw new UserError("لا يمكن تعديل Super Admin من الواجهة", 403);
    const next: { role?: string; isActive?: boolean } = {};
    if (role && [UserRole.PLATFORM_ADMIN, UserRole.SUPPORT_AGENT, UserRole.CUSTOMER].includes(role)) next.role = role;
    if (typeof isActive === "boolean") next.isActive = isActive;
    await db.update(users).set(next).where(eq(users.id, u.id));
    await audit({ userId: g.userId, action: "ADMIN_UPDATED", entity: "USER", entityId: u.id, oldValue: { role: u.role, isActive: u.isActive }, newValue: next });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return safeError(e);
  }
}
