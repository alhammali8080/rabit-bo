import { NextResponse } from "next/server";
import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { vipTiers, vipBenefits, vipMemberships, users, walletCampaigns, notifications } from "@/db/schema";
import { guard, safeError, UserError } from "@/lib/server/session";
import { audit } from "@/lib/server/audit";
import { P } from "@/lib/rbac";

export async function GET() {
  const g = await guard({ perm: P.VIP_MANAGE });
  if (g instanceof NextResponse) return g;
  try {
    const tiers = await db.select().from(vipTiers);
    const benefits = await db.select().from(vipBenefits);
    const members = await db
      .select({ m: vipMemberships, name: users.fullName, phone: users.phone })
      .from(vipMemberships)
      .innerJoin(users, eq(users.id, vipMemberships.userId))
      .orderBy(desc(vipMemberships.createdAt))
      .limit(100);
    const campaigns = await db.select().from(walletCampaigns).orderBy(desc(walletCampaigns.createdAt));
    return NextResponse.json({
      tiers: tiers.map((t) => ({ ...t, benefits: benefits.filter((b) => b.tierId === t.id) })),
      members: members.map((r) => ({ ...r.m, name: r.name, phone: r.phone })),
      campaigns,
    });
  } catch (e) {
    return safeError(e);
  }
}

// actions: grant | revoke | benefit | campaign | campaignToggle
export async function POST(req: Request) {
  const g = await guard({ perm: P.VIP_MANAGE });
  if (g instanceof NextResponse) return g;
  try {
    const body = await req.json();
    switch (body.action) {
      case "grant": {
        const [u] = await db.select().from(users).where(eq(users.phone, String(body.phone || "").replace(/\s/g, "")));
        if (!u || u.role !== "CUSTOMER") throw new UserError("لا يوجد عميل بهذا الرقم", 404);
        const [tier] = await db.select().from(vipTiers).where(eq(vipTiers.id, Number(body.tierId)));
        if (!tier) throw new UserError("المستوى غير موجود", 404);
        await db.update(vipMemberships).set({ status: "CANCELLED" }).where(and(eq(vipMemberships.userId, u.id), eq(vipMemberships.status, "ACTIVE")));
        const days = Number(body.days) || tier.durationDays;
        const [m] = await db
          .insert(vipMemberships)
          .values({ userId: u.id, tierId: tier.id, endsAt: new Date(Date.now() + days * 86400000), grantedBy: g.userId })
          .returning();
        await db.insert(notifications).values({ userId: u.id, titleAr: "مرحباً بك في VIP", bodyAr: `تم تفعيل عضوية ${tier.nameAr} حتى ${m.endsAt.toLocaleDateString("ar-LY")}`, type: "VIP", actionUrl: "/app/vip" });
        await audit({ userId: g.userId, action: "VIP_GRANTED", entity: "VIP", entityId: u.id, newValue: { tier: tier.slug, days } });
        return NextResponse.json({ ok: true });
      }
      case "revoke": {
        await db.update(vipMemberships).set({ status: "CANCELLED" }).where(eq(vipMemberships.id, Number(body.membershipId)));
        await audit({ userId: g.userId, action: "VIP_REVOKED", entity: "VIP", entityId: body.membershipId });
        return NextResponse.json({ ok: true });
      }
      case "benefit": {
        const [b] = await db.select().from(vipBenefits).where(eq(vipBenefits.id, Number(body.benefitId)));
        if (!b) throw new UserError("الميزة غير موجودة", 404);
        const value = body.value != null ? Math.max(0, Math.min(100, parseFloat(body.value))) : parseFloat(b.value);
        const isActive = typeof body.isActive === "boolean" ? body.isActive : b.isActive;
        await db.update(vipBenefits).set({ value: value.toFixed(2), isActive }).where(eq(vipBenefits.id, b.id));
        await audit({ userId: g.userId, action: "VIP_BENEFIT_CHANGED", entity: "VIP_BENEFIT", entityId: b.id, oldValue: { value: b.value, isActive: b.isActive }, newValue: { value, isActive } });
        return NextResponse.json({ ok: true });
      }
      case "campaign": {
        const min = parseFloat(body.minRecharge), bonus = parseFloat(body.bonusAmount);
        if (!body.titleAr || !(min > 0) || !(bonus > 0) || bonus > min) throw new UserError("بيانات الحملة غير صحيحة");
        const [c] = await db.insert(walletCampaigns).values({ titleAr: body.titleAr, minRecharge: min.toFixed(2), bonusAmount: bonus.toFixed(2), vipOnly: !!body.vipOnly }).returning();
        await audit({ userId: g.userId, action: "CAMPAIGN_CREATED", entity: "CAMPAIGN", entityId: c.id, newValue: c });
        return NextResponse.json({ ok: true });
      }
      case "campaignToggle": {
        await db.update(walletCampaigns).set({ isActive: !!body.isActive }).where(eq(walletCampaigns.id, Number(body.campaignId)));
        await audit({ userId: g.userId, action: "CAMPAIGN_TOGGLED", entity: "CAMPAIGN", entityId: body.campaignId, newValue: body.isActive });
        return NextResponse.json({ ok: true });
      }
      default:
        throw new UserError("عملية غير معروفة");
    }
  } catch (e) {
    return safeError(e);
  }
}
