import { NextResponse } from "next/server";
import { desc, eq, ilike, or } from "drizzle-orm";
import { db } from "@/db";
import { users, userWallets, WalletTxType } from "@/db/schema";
import { guard, hasPerm, forbidden, safeError, UserError } from "@/lib/server/session";
import { applyWalletTx } from "@/lib/server/wallet";
import { audit } from "@/lib/server/audit";
import { P } from "@/lib/rbac";

export async function GET(req: Request) {
  const g = await guard({ perm: P.USERS_MANAGE });
  if (g instanceof NextResponse) return g;
  try {
    const q = new URL(req.url).searchParams.get("q")?.trim();
    const rows = await db
      .select({ id: users.id, fullName: users.fullName, phone: users.phone, role: users.role, isActive: users.isActive, createdAt: users.createdAt, balance: userWallets.balance })
      .from(users)
      .leftJoin(userWallets, eq(userWallets.userId, users.id))
      .where(q ? or(ilike(users.fullName, `%${q}%`), ilike(users.phone, `%${q}%`)) : undefined)
      .orderBy(desc(users.createdAt))
      .limit(50);
    return NextResponse.json(rows);
  } catch (e) {
    return safeError(e);
  }
}

// Administrative wallet adjustment – always through the ledger with a mandatory reason
export async function POST(req: Request) {
  const g = await guard({ perm: P.WALLETS_ADJUST });
  if (g instanceof NextResponse) return g;
  try {
    const { userId, amount, reason } = await req.json();
    const amt = parseFloat(amount);
    if (!reason || String(reason).trim().length < 5) throw new UserError("سبب التعديل إلزامي (5 أحرف على الأقل)");
    if (!Number.isFinite(amt) || amt === 0 || Math.abs(amt) > 5000) throw new UserError("قيمة غير صالحة (الحد 5000 د.ل)");
    if (Math.abs(amt) > 1000 && !hasPerm(g, P.SETTINGS_SYSTEM)) return forbidden();
    const [u] = await db.select().from(users).where(eq(users.id, Number(userId)));
    if (!u) throw new UserError("المستخدم غير موجود", 404);
    const tx = await db.transaction((t) =>
      applyWalletTx(t, { userId: u.id, type: WalletTxType.ADJUSTMENT, amount: amt, source: "ADMIN", note: String(reason).slice(0, 200), actorId: g.userId })
    );
    await audit({ userId: g.userId, action: "WALLET_ADJUSTED", entity: "WALLET", entityId: u.id, oldValue: tx.balanceBefore, newValue: { after: tx.balanceAfter, reason } });
    return NextResponse.json({ ok: true, balance: tx.balanceAfter });
  } catch (e) {
    return safeError(e);
  }
}
