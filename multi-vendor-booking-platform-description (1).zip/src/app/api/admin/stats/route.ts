import { NextResponse } from "next/server";
import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { users, organizations, bookings, auditLogs, userWallets, rechargeCards } from "@/db/schema";
import { guard, hasPerm, safeError } from "@/lib/server/session";
import { P } from "@/lib/rbac";

export async function GET() {
  const g = await guard({ perm: P.ADMIN_ACCESS });
  if (g instanceof NextResponse) return g;
  try {
    const [u] = await db.select({ n: sql<number>`count(*)::int` }).from(users);
    const [o] = await db.select({ n: sql<number>`count(*)::int` }).from(organizations);
    const [b] = await db
      .select({ n: sql<number>`count(*)::int`, gmv: sql<string>`coalesce(sum(${bookings.totalPrice}),0)`, rev: sql<string>`coalesce(sum(${bookings.platformFee} + ${bookings.customerFee}),0)` })
      .from(bookings);
    const [w] = await db.select({ total: sql<string>`coalesce(sum(${userWallets.balance}),0)` }).from(userWallets);
    const [c] = await db.select({ redeemed: sql<string>`coalesce(sum(${rechargeCards.value}) filter (where ${rechargeCards.status}='USED'),0)` }).from(rechargeCards);
    const recentBookings = await db.select().from(bookings).orderBy(desc(bookings.createdAt)).limit(8);
    const logs = hasPerm(g, P.AUDIT_VIEW)
      ? await db
          .select({ l: auditLogs, name: users.fullName })
          .from(auditLogs)
          .leftJoin(users, eq(users.id, auditLogs.userId))
          .orderBy(desc(auditLogs.createdAt))
          .limit(40)
      : [];
    return NextResponse.json({
      metrics: { users: u.n, orgs: o.n, bookings: b.n, gmv: b.gmv, platformRevenue: b.rev, walletLiability: w.total, cardsRedeemed: c.redeemed },
      recentBookings,
      auditLogs: logs.map((r) => ({ ...r.l, userName: r.name })),
    });
  } catch (e) {
    return safeError(e);
  }
}
