import { NextResponse } from "next/server";
import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { rechargeBatches, rechargeCards, CardStatus } from "@/db/schema";
import { guard, hasPerm, forbidden, safeError, UserError } from "@/lib/server/session";
import { generateCardCode, hashCardCode, normalizeCode } from "@/lib/server/cards";
import { audit } from "@/lib/server/audit";
import { P } from "@/lib/rbac";

const LARGE_COUNT = 1000;
const LARGE_TOTAL = 20000; // LYD

export async function GET() {
  const g = await guard({ perm: P.CARDS_VIEW });
  if (g instanceof NextResponse) return g;
  try {
    const rows = await db
      .select({
        batch: rechargeBatches,
        used: sql<number>`count(*) filter (where ${rechargeCards.status} = 'USED')::int`,
        unused: sql<number>`count(*) filter (where ${rechargeCards.status} = 'UNUSED')::int`,
      })
      .from(rechargeBatches)
      .leftJoin(rechargeCards, eq(rechargeCards.batchId, rechargeBatches.id))
      .groupBy(rechargeBatches.id)
      .orderBy(desc(rechargeBatches.createdAt));
    return NextResponse.json(
      rows.map((r) => ({ ...r.batch, used: r.used, remaining: r.unused, totalValue: (parseFloat(r.batch.faceValue) * r.batch.quantity).toFixed(2) }))
    );
  } catch (e) {
    return safeError(e);
  }
}

/**
 * Create a batch. Plaintext codes are returned ONCE in this response (for print/export)
 * and are never stored – only their HMAC hashes are.
 */
export async function POST(req: Request) {
  const g = await guard({ perm: P.CARDS_CREATE });
  if (g instanceof NextResponse) return g;
  try {
    const { faceValue, quantity, expiresInDays } = await req.json();
    const value = parseFloat(faceValue);
    const qty = Math.floor(Number(quantity));
    if (![5, 10, 20, 50, 100, 200].includes(value)) throw new UserError("فئة الكرت غير مسموحة");
    if (!(qty >= 1 && qty <= 5000)) throw new UserError("العدد يجب أن يكون بين 1 و 5000");
    if ((qty > LARGE_COUNT || qty * value > LARGE_TOTAL) && !hasPerm(g, P.CARDS_CREATE_LARGE)) {
      await audit({ userId: g.userId, action: "CARD_BATCH_DENIED", entity: "RECHARGE_BATCH", newValue: { value, qty }, result: "DENIED" });
      return forbidden();
    }
    const expiresAt = expiresInDays ? new Date(Date.now() + Number(expiresInDays) * 86400000) : null;

    const out = await db.transaction(async (tx) => {
      const [batch] = await tx
        .insert(rechargeBatches)
        .values({ batchRef: `B${Date.now().toString().slice(-7)}`, faceValue: value.toFixed(2), quantity: qty, createdBy: g.userId, expiresAt, exportedCount: qty })
        .returning();
      const codes: { serial: string; code: string }[] = [];
      const seen = new Set<string>();
      while (codes.length < qty) {
        const code = generateCardCode();
        const n = normalizeCode(code);
        if (seen.has(n)) continue;
        seen.add(n);
        codes.push({ serial: `${batch.batchRef}-${String(codes.length + 1).padStart(5, "0")}`, code });
      }
      for (let i = 0; i < codes.length; i += 500) {
        await tx.insert(rechargeCards).values(
          codes.slice(i, i + 500).map((c) => ({
            batchId: batch.id,
            codeHash: hashCardCode(c.code),
            last4: normalizeCode(c.code).slice(-4),
            serial: c.serial,
            value: value.toFixed(2),
            status: CardStatus.UNUSED,
            expiresAt,
          }))
        );
      }
      return { batch, codes };
    });

    await audit({ userId: g.userId, action: "CARD_BATCH_CREATED", entity: "RECHARGE_BATCH", entityId: out.batch.batchRef, newValue: { value, qty } });
    return NextResponse.json(out, { status: 201 });
  } catch (e) {
    return safeError(e);
  }
}

// Suspend / reactivate / cancel a batch
export async function PATCH(req: Request) {
  const g = await guard({ perm: P.CARDS_CREATE });
  if (g instanceof NextResponse) return g;
  try {
    const { batchId, status } = await req.json();
    if (!["ACTIVE", "SUSPENDED", "CANCELLED"].includes(status)) throw new UserError("حالة غير صالحة");
    const [b] = await db.select().from(rechargeBatches).where(eq(rechargeBatches.id, Number(batchId)));
    if (!b) throw new UserError("الدفعة غير موجودة", 404);
    if (b.status === "CANCELLED") throw new UserError("الدفعة ملغاة نهائياً");
    await db.update(rechargeBatches).set({ status }).where(eq(rechargeBatches.id, b.id));
    if (status === "CANCELLED") {
      await db.update(rechargeCards).set({ status: CardStatus.CANCELLED }).where(sql`${rechargeCards.batchId} = ${b.id} and ${rechargeCards.status} = 'UNUSED'`);
    }
    await audit({ userId: g.userId, action: "CARD_BATCH_STATUS", entity: "RECHARGE_BATCH", entityId: b.batchRef, oldValue: b.status, newValue: status });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return safeError(e);
  }
}
