import { NextResponse } from "next/server";
import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { banners } from "@/db/schema";
import { seedDatabase } from "@/db/seed";
import { safeError } from "@/lib/server/session";

export async function GET() {
  try {
    await seedDatabase();
    const rows = await db.select().from(banners).where(eq(banners.isActive, true)).orderBy(asc(banners.displayOrder));
    return NextResponse.json(rows, { headers: { "Cache-Control": "s-maxage=60, stale-while-revalidate=300" } });
  } catch (e) {
    return safeError(e);
  }
}
