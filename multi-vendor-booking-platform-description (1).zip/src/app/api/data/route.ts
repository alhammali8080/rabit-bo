import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  categories,
  organizations,
  branches,
  staff,
  services,
  reviews,
  systemSettings,
  subscriptionPlans,
} from "@/db/schema";
import { seedDatabase } from "@/db/seed";
import { eq, desc } from "drizzle-orm";

export async function GET(request: Request) {
  try {
    await seedDatabase();

    const { searchParams } = new URL(request.url);
    const categorySlug = searchParams.get("category");
    const city = searchParams.get("city");
    const search = searchParams.get("q");

    const allCategories = await db
      .select()
      .from(categories)
      .where(eq(categories.isActive, true))
      .orderBy(categories.displayOrder);

    const allOrgs = await db
      .select()
      .from(organizations)
      .orderBy(desc(organizations.isFeatured), desc(organizations.rating));

    const allBranches = await db.select().from(branches).where(eq(branches.isActive, true));
    const allStaff = await db.select().from(staff).where(eq(staff.isActive, true));
    const allServices = await db.select().from(services).where(eq(services.isActive, true));
    const allReviews = await db.select().from(reviews).where(eq(reviews.isPublished, true)).limit(20);
    const plans = await db.select().from(subscriptionPlans).where(eq(subscriptionPlans.isActive, true));

    return NextResponse.json({
      categories: allCategories,
      organizations: allOrgs,
      branches: allBranches,
      staff: allStaff,
      services: allServices,
      reviews: allReviews,
      plans,
    });
  } catch (error: any) {
    console.error("API /api/data error:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
