import { NextResponse } from "next/server";
import { and, desc, eq, gt, lte, or, isNull, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  rechargeCards,
  rechargeBatches,
  rechargeAttempts,
  walletCampaigns,
  notifications,
  CardStatus,
  WalletTxType,
  VipBenefitKey,
} from "@/db/schema";
import { guard, requestMeta, safeError, UserError } from "@/lib/server/session";
import { hashCardCode, normalizeCode } from "@/lib/server/cards";
import { applyWalletTx, getActiveVip } from "@/lib/server/wallet";
import { audit } from "@/lib/server/audit";

const MAX_FAILS_USER = 5;
const MAX_FAILS_IP = 15;

export async function POST(req: Request) {
  const g = await guard({ roles: ["CUSTOMER"] });
  if (g instanceof NextResponse) return g;
  const { ip } = await requestMeta();

  try {
    // Brute-force protection: failures in the last 15 minutes by user & by IP
    const since = sql`now() - interval '15 minutes'`;
    const [{ u }] = await db
      .select({ u: sql<number>`count(*)::int` })
      .from(rechargeAttempts)
      .where(and(eq(rechargeAttempts.userId, g.userId), eq(rechargeAttempts.success, false), gt(rechargeAttempts.createdAt, since)));
    const [{ i }] = await db
      .select({ i: sql<number>`count(*)::int` })
      .from(rechargeAttempts)
      .where(and(eq(rechargeAttempts.ipAddress, ip), eq(rechargeAttempts.success, false), gt(rechargeAttempts.createdAt, since)));
    if (u >= MAX_FAILS_USER || i >= MAX_FAILS_IP) {
      await audit({ userId: g.userId, action: "CARD_RECHARGE_BLOCKED", entity: "WALLET", result: "DENIED" });
      return NextResponse.json(
        { error: "تم إيقاف محاولات الشحن مؤقتاً بسبب محاولات فاشلة متكررة. حاول بعد 15 دقيقة." },
        { status: 429 }
      );
    }

    const { code } = await req.json();
    const normalized = normalizeCode(String(code || ""));
    if (normalized.length !== 16) {
      await db.insert(rechargeAttempts).values({ userId: g.userId, ipAddress: ip, success: false });
      return NextResponse.json({ error: "صيغة الكرت غير صحيحة (16 خانة)" }, { status: 400 });
    }
    const hash = hashCardCode(normalized);

    const result = await db.transaction(async (tx) => {
      // Lock the card row so two concurrent redemptions cannot both succeed
      const [card] = await tx.select().from(rechargeCards).where(eq(rechargeCards.codeHash, hash)).for("update");
      if (!card) throw new UserError("رقم الكرت غير صحيح", 404);
      const [batch] = await tx.select().from(rechargeBatches).where(eq(rechargeBatches.id, card.batchId));

      if (card.status === CardStatus.USED) throw new UserError("هذا الكرت مستخدم مسبقاً", 409);
      if (card.status !== CardStatus.UNUSED || batch.status !== "ACTIVE") throw new UserError("هذا الكرت موقوف أو ملغي", 410);
      if (card.expiresAt && card.expiresAt < new Date()) {
        await tx.update(rechargeCards).set({ status: CardStatus.EXPIRED }).where(eq(rechargeCards.id, card.id));
        throw new UserError("انتهت صلاحية هذا الكرت", 410);
      }

      await tx
        .update(rechargeCards)
        .set({ status: CardStatus.USED, usedBy: g.userId, usedAt: new Date() })
        .where(and(eq(rechargeCards.id, card.id), eq(rechargeCards.status, CardStatus.UNUSED)));

      const value = parseFloat(card.value);
      const main = await applyWalletTx(tx, {
        userId: g.userId,
        type: WalletTxType.CARD_RECHARGE,
        amount: value,
        source: "CARD",
        reference: card.serial,
        note: `شحن بكرت •••• ${card.last4}`,
        actorId: g.userId,
      });

      const bonuses: { title: string; amount: number }[] = [];
      const vip = await getActiveVip(g.userId, tx);

      // VIP recharge bonus (percentage, admin-controlled)
      const pct = vip?.map[VipBenefitKey.RECHARGE_BONUS_PERCENT];
      if (pct && pct > 0) {
        const amt = Math.round(value * pct) / 100;
        if (amt > 0) {
          await applyWalletTx(tx, { userId: g.userId, type: WalletTxType.VIP_BONUS, amount: amt, source: "VIP", reference: card.serial, note: `مكافأة VIP ${pct}% على الشحن` });
          bonuses.push({ title: `مكافأة VIP ${pct}%`, amount: amt });
        }
      }

      // Best matching active campaign (admin-controlled)
      const [camp] = await tx
        .select()
        .from(walletCampaigns)
        .where(
          and(
            eq(walletCampaigns.isActive, true),
            lte(walletCampaigns.minRecharge, value.toFixed(2)),
            or(isNull(walletCampaigns.endsAt), gt(walletCampaigns.endsAt, sql`now()`))
          )
        )
        .orderBy(desc(walletCampaigns.bonusAmount))
        .limit(5)
        .then((rows) => rows.filter((r) => !r.vipOnly || vip));
      if (camp) {
        const amt = parseFloat(camp.bonusAmount);
        await applyWalletTx(tx, { userId: g.userId, type: WalletTxType.BONUS, amount: amt, source: "CAMPAIGN", reference: `CMP-${camp.id}`, note: camp.titleAr });
        bonuses.push({ title: camp.titleAr, amount: amt });
      }

      const totalBonus = bonuses.reduce((s, b) => s + b.amount, 0);
      const finalBalance = (parseFloat(main.balanceAfter) + totalBonus).toFixed(2);
      await tx.insert(notifications).values({
        userId: g.userId,
        titleAr: "تم شحن المحفظة",
        bodyAr: `تم شحن محفظتك بـ ${value.toFixed(2)} د.ل بنجاح${totalBonus ? ` + مكافأة ${totalBonus.toFixed(2)} د.ل` : ""}. رصيدك الحالي ${finalBalance} د.ل`,
        type: "WALLET_RECHARGE",
        actionUrl: "/app/wallet",
      });
      return { value, bonuses, balance: finalBalance, serial: card.serial };
    });

    await db.insert(rechargeAttempts).values({ userId: g.userId, ipAddress: ip, success: true });
    await audit({ userId: g.userId, action: "CARD_REDEEMED", entity: "RECHARGE_CARD", entityId: result.serial, newValue: { value: result.value, bonuses: result.bonuses } });
    return NextResponse.json({ ok: true, ...result });
  } catch (e) {
    if (e instanceof UserError) {
      await db.insert(rechargeAttempts).values({ userId: g.userId, ipAddress: ip, success: false });
      await audit({ userId: g.userId, action: "CARD_REDEEM_FAILED", entity: "RECHARGE_CARD", newValue: e.message, result: "FAILED" });
    }
    return safeError(e);
  }
}
