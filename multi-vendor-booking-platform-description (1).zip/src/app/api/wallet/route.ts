import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { walletTransactions } from "@/db/schema";
import { guard, safeError } from "@/lib/server/session";
import { getWallet } from "@/lib/server/wallet";

export async function GET(req: Request) {
  const g = await guard({ roles: ["CUSTOMER"] });
  if (g instanceof NextResponse) return g;
  try {
    const limit = Math.min(Number(new URL(req.url).searchParams.get("limit") || 20), 100);
    const wallet = await getWallet(g.userId);
    const txs = await db
      .select()
      .from(walletTransactions)
      .where(eq(walletTransactions.userId, g.userId))
      .orderBy(desc(walletTransactions.createdAt))
      .limit(limit);
    return NextResponse.json({ wallet, transactions: txs });
  } catch (e) {
    return safeError(e);
  }
}
