"use client";

import { useState } from "react";
import { Plus, History, CheckCircle2 } from "lucide-react";
import { Btn, Card, Empty, ErrorBox, Skeleton, TX_AR, inputCls, lyd, postJson, useApi } from "@/components/ui";

interface Tx { id: number; txRef: string; type: string; amount: string; balanceAfter: string; note: string | null; createdAt: string }

export default function WalletPage() {
  const [limit, setLimit] = useState(10);
  const { data, loading, error, reload } = useApi<{ wallet: { balance: string }; transactions: Tx[] }>(`/api/wallet?limit=${limit}`);
  const [open, setOpen] = useState(false);
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  function format(v: string) {
    const c = v.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 16);
    return c.match(/.{1,4}/g)?.join("-") || "";
  }

  async function recharge(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setMsg(null);
    try {
      const r = await postJson("/api/wallet/recharge", { code });
      const bonus = r.bonuses?.reduce((s: number, b: { amount: number }) => s + b.amount, 0) || 0;
      setMsg({ ok: true, text: `تمت إضافة ${lyd(r.value)} إلى محفظتك بنجاح${bonus ? ` + مكافأة ${lyd(bonus)}` : ""}. رصيدك الآن ${lyd(r.balance)}` });
      setCode("");
      reload();
    } catch (err) {
      setMsg({ ok: false, text: (err as Error).message });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-5">
      <div className="bg-gradient-to-br from-blue-800 to-blue-600 text-white rounded-3xl p-6 text-center">
        <div className="text-sm opacity-80">رصيدك</div>
        <div className="text-4xl font-black mt-1">{data ? lyd(data.wallet.balance) : "..."}</div>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <Btn variant="accent" className="min-h-[56px] text-base flex items-center justify-center gap-2" onClick={() => { setOpen(!open); setMsg(null); }}><Plus className="w-5 h-5" /> شحن المحفظة</Btn>
        <Btn variant="ghost" className="min-h-[56px] text-base flex items-center justify-center gap-2" onClick={() => setLimit(100)}><History className="w-5 h-5" /> سجل العمليات</Btn>
      </div>

      {open && (
        <Card>
          <div className="font-black mb-1">طريقة الشحن: كرت شحن</div>
          <p className="text-xs text-slate-500 mb-3">أدخل الكود المكون من 16 خانة الموجود على الكرت.</p>
          <form onSubmit={recharge} className="space-y-3">
            <input dir="ltr" className={`${inputCls} text-center font-mono tracking-widest text-lg`} placeholder="XXXX-XXXX-XXXX-XXXX" value={code} onChange={(e) => setCode(format(e.target.value))} autoComplete="off" />
            <Btn className="w-full" disabled={busy || code.replace(/-/g, "").length !== 16}>{busy ? "جاري الشحن..." : "شحن الآن"}</Btn>
          </form>
          {msg && (
            <div className={`mt-3 p-3 rounded-xl text-sm flex gap-2 ${msg.ok ? "bg-emerald-50 text-emerald-800" : "bg-red-50 text-red-700"}`}>
              {msg.ok && <CheckCircle2 className="w-5 h-5 shrink-0" />} {msg.text}
            </div>
          )}
        </Card>
      )}

      <div>
        <h2 className="font-black mb-3">{limit > 10 ? "سجل العمليات" : "آخر العمليات"}</h2>
        {loading && !data ? <Skeleton /> : error ? <ErrorBox message={error} onRetry={reload} /> : data!.transactions.length === 0 ? <Empty title="لا توجد عمليات بعد" /> : (
          <div className="space-y-2">
            {data!.transactions.map((t) => {
              const amt = parseFloat(t.amount);
              return (
                <div key={t.id} className="bg-white border border-slate-200 rounded-2xl p-3 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="text-sm font-bold">{TX_AR[t.type] || t.type}</div>
                    <div className="text-xs text-slate-500 truncate">{t.note}</div>
                    <div className="text-[11px] text-slate-400">{new Date(t.createdAt).toLocaleString("ar-LY")}</div>
                  </div>
                  <div className="text-left shrink-0">
                    <div className={`font-black ${amt > 0 ? "text-emerald-600" : "text-red-600"}`} dir="ltr">{amt > 0 ? "+" : ""}{amt.toFixed(2)}</div>
                    <div className="text-[11px] text-slate-400">الرصيد {Number(t.balanceAfter).toFixed(2)}</div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
