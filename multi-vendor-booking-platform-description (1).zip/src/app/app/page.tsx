"use client";

import Link from "next/link";
import { Crown, Wallet, ChevronLeft } from "lucide-react";
import ProviderBrowser from "@/components/ProviderBrowser";
import CategoryGrid from "@/components/site/CategoryGrid";
import BannerCarousel from "@/components/site/BannerCarousel";
import { useApi, lyd } from "@/components/ui";

export default function CustomerHome() {
  const me = useApi<{ user: { fullName: string } | null; vip: { endsAt: string } | null }>("/api/me");
  const w = useApi<{ wallet: { balance: string } }>("/api/wallet?limit=1");

  return (
    <div className="space-y-5">
      <div>
        <p className="text-sm text-slate-500">أهلاً</p>
        <h1 className="text-xl font-black">{me.data?.user?.fullName?.split(" ")[0] || "..."}</h1>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <Link href="/app/wallet" className="bg-blue-700 text-white rounded-2xl p-4">
          <Wallet className="w-5 h-5 mb-2 opacity-80" />
          <div className="text-xs opacity-80">رصيد المحفظة</div>
          <div className="text-lg font-black">{w.data ? lyd(w.data.wallet.balance) : "..."}</div>
        </Link>
        {me.data?.vip ? (
          <Link href="/app/vip" className="bg-gradient-to-br from-amber-400 to-amber-600 text-white rounded-2xl p-4">
            <Crown className="w-5 h-5 mb-2" />
            <div className="text-xs opacity-90">أنت عضو VIP</div>
            <div className="text-sm font-black">حتى {new Date(me.data.vip.endsAt).toLocaleDateString("ar-LY")}</div>
          </Link>
        ) : (
          <Link href="/app/search" className="bg-white border border-slate-200 rounded-2xl p-4 flex flex-col justify-between">
            <div className="text-sm font-black">ابحث واحجز</div>
            <ChevronLeft className="w-5 h-5 text-slate-400 self-end" />
          </Link>
        )}
      </div>
      <BannerCarousel />
      <h2 className="font-black text-lg">ماذا تريد أن تحجز؟</h2>
      <CategoryGrid />
      <h2 className="font-black text-lg">الأعلى تقييماً</h2>
      <ProviderBrowser loggedIn limit={6} showSearch={false} excludeSlugs={["sahel-bus", "najm-express-bus"]} />
    </div>
  );
}
