"use client";

import { Crown, Check } from "lucide-react";
import { Card, ErrorBox, Skeleton, useApi } from "@/components/ui";

interface Benefit { id: number; key: string; titleAr: string; value: string }
interface Tier { id: number; nameAr: string; priceLyd: string; benefits: Benefit[] }
interface Resp { active: { startsAt: string; endsAt: string; tier: Tier; benefits: Benefit[] } | null; tiers: Tier[] }

const label = (b: Benefit) => (["FEE_DISCOUNT_PERCENT", "RECHARGE_BONUS_PERCENT"].includes(b.key) ? `${b.titleAr.replace(" (%)", "")}: ${Number(b.value)}%` : b.titleAr);

export default function VipPage() {
  const { data, loading, error, reload } = useApi<Resp>("/api/vip");
  if (loading) return <Skeleton />;
  if (error) return <ErrorBox message={error} onRetry={reload} />;
  const a = data!.active;
  return (
    <div className="space-y-5">
      {a ? (
        <div className="bg-gradient-to-br from-amber-400 to-amber-600 text-white rounded-3xl p-6">
          <Crown className="w-8 h-8 mb-2" />
          <div className="text-2xl font-black">{a.tier.nameAr}</div>
          <div className="text-sm opacity-90 mt-1">أنت عضو VIP – عضويتك فعالة حتى {new Date(a.endsAt).toLocaleDateString("ar-LY")}</div>
          <div className="text-xs opacity-80">بدأت في {new Date(a.startsAt).toLocaleDateString("ar-LY")}</div>
        </div>
      ) : (
        <Card><div className="font-black">لست عضو VIP حالياً</div><p className="text-sm text-slate-500 mt-1">تواصل مع الدعم لتفعيل العضوية. {/* TODO: self-purchase VIP via wallet */}</p></Card>
      )}
      {a && (
        <Card>
          <div className="font-black mb-3">مزاياك الحالية</div>
          <ul className="space-y-2">{a.benefits.map((b) => <li key={b.id} className="flex gap-2 text-sm"><Check className="w-5 h-5 text-emerald-600" />{label(b)}</li>)}</ul>
        </Card>
      )}
      <h2 className="font-black">مستويات العضوية</h2>
      {data!.tiers.map((t) => (
        <Card key={t.id}>
          <div className="flex justify-between"><b>{t.nameAr}</b><span className="text-sm text-slate-500">{Number(t.priceLyd)} د.ل / سنة</span></div>
          <ul className="mt-2 space-y-1">{t.benefits.map((b) => <li key={b.id} className="text-sm text-slate-600">• {label(b)}</li>)}</ul>
        </Card>
      ))}
    </div>
  );
}
