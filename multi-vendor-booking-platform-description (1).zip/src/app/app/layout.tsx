"use client";

import type { ReactNode } from "react";
import RoleShell, { type NavItem } from "@/components/RoleShell";
import RoleGate from "@/components/RoleGate";
import InlineLogin from "@/components/InlineLogin";

const nav: NavItem[] = [
  { href: "/app", label: "الرئيسية", icon: "Home" },
  { href: "/app/search", label: "البحث", icon: "Search" },
  { href: "/app/bookings", label: "الحجوزات", icon: "CalendarDays" },
  { href: "/app/wallet", label: "المحفظة", icon: "Wallet" },
  { href: "/bus", label: "حجز حافلة", icon: "Bus" },
  { href: "/events", label: "تذاكر المباريات", icon: "Ticket" },
  { href: "/app/vip", label: "VIP", icon: "Crown" },
  { href: "/notifications", label: "الإشعارات", icon: "Bell" },
  { href: "/app/account", label: "حسابي", icon: "User" },
];
const ROLES = ["CUSTOMER"];

export default function CustomerLayout({ children }: { children: ReactNode }) {
  return (
    <RoleGate roles={ROLES} portal="customer" login={(p) => <InlineLogin portal={p} />}>
      {(u) => <RoleShell brand="حسابي – رابط" subtitle={u.fullName} nav={nav}>{children}</RoleShell>}
    </RoleGate>
  );
}
