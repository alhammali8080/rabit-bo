"use client";

import ProviderBrowser from "@/components/ProviderBrowser";
import CategoryGrid from "@/components/site/CategoryGrid";

export default function SearchPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-xl font-black">البحث والتصنيفات</h1>
      <CategoryGrid />
      <ProviderBrowser loggedIn excludeSlugs={["sahel-bus", "najm-express-bus"]} />
    </div>
  );
}
