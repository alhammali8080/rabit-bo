"use client";

import Link from "next/link";
import { User, CalendarDays, Wallet, Crown, Bell, LifeBuoy, Settings, LogOut, ChevronLeft } from "lucide-react";
import { useApi } from "@/components/ui";
import { logout } from "@/lib/clientAuth";

const ITEMS = [
  { href: "/app/account", label: "بياناتي", icon: User },
  { href: "/app/bookings", label: "حجوزاتي", icon: CalendarDays },
  { href: "/app/wallet", label: "المحفظة", icon: Wallet },
  { href: "/app/vip", label: "VIP", icon: Crown },
  { href: "/notifications", label: "الإشعارات", icon: Bell },
  { href: "mailto:support@rabit.ly", label: "الدعم", icon: LifeBuoy },
  { href: "/app/account", label: "الإعدادات", icon: Settings },
];

export default function AccountPage() {
  const me = useApi<{ user: { fullName: string; phone: string } | null; vip: unknown }>("/api/me");
  return (
    <div className="space-y-4">
      <div className="bg-white rounded-2xl border border-slate-200 p-5 flex items-center gap-4">
        <div className="w-14 h-14 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center font-black text-xl">{me.data?.user?.fullName?.[0] || "؟"}</div>
        <div>
          <div className="font-black flex items-center gap-2">{me.data?.user?.fullName}{me.data?.vip ? <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500 text-white">VIP</span> : null}</div>
          <div className="text-sm text-slate-500" dir="ltr">{me.data?.user?.phone}</div>
        </div>
      </div>
      <div className="bg-white rounded-2xl border border-slate-200 divide-y">
        {ITEMS.map((i) => (
          <Link key={i.label} href={i.href} className="flex items-center justify-between px-4 min-h-[56px]">
            <span className="flex items-center gap-3 text-sm font-bold"><i.icon className="w-5 h-5 text-slate-500" />{i.label}</span>
            <ChevronLeft className="w-4 h-4 text-slate-400" />
          </Link>
        ))}
        <button onClick={logout} className="w-full flex items-center gap-3 px-4 min-h-[56px] text-sm font-bold text-red-600">
          <LogOut className="w-5 h-5" /> تسجيل الخروج
        </button>
      </div>
    </div>
  );
}
