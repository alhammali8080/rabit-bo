"use client";

import { useState } from "react";
import { Btn, Card, Empty, ErrorBox, Skeleton, STATUS_AR, lyd, postJson, useApi, useToast } from "@/components/ui";

interface B { id: number; bookingRef: string; organizationName: string; serviceName: string; bookingDate: string; startTime: string; status: string; totalPrice: string; paymentMethod: string; policy: string }

export default function BookingsPage() {
  const { data, loading, error, reload } = useApi<B[]>("/api/bookings");
  const [tab, setTab] = useState<"up" | "past">("up");
  const [kind, setKind] = useState<"svc" | "tkt" | "bus">("svc");
  const my = useApi<{ tickets: { id: number; orderRef: string; title: string; venue: string; date: string; time: string; tier: string; quantity: number; total: string }[]; trips: { ref: string; from: string; to: string; date: string; time: string; operator: string; station: string; seats: number[]; total: number }[] }>("/api/my/tickets");
  const [confirmId, setConfirmId] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const toast = useToast();
  const today = new Date().toISOString().slice(0, 10);
  const list = (data || []).filter((b) => {
    const upcoming = b.bookingDate >= today && ["CONFIRMED", "PENDING"].includes(b.status);
    return tab === "up" ? upcoming : !upcoming;
  });

  async function cancel(id: number) {
    setBusy(true);
    try {
      const r = await postJson(`/api/bookings/${id}/cancel`, { reason: "إلغاء من العميل" });
      toast.show(r.refund > 0 ? `تم الإلغاء وإرجاع ${lyd(r.refund)} للمحفظة` : `تم الإلغاء (سياسة الاسترداد: ${r.pct}%)`);
      setConfirmId(null);
      reload();
    } catch (e) {
      toast.show((e as Error).message, false);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-black">حجوزاتي</h1>
      <div className="grid grid-cols-3 gap-2">
        {([["svc", "📅 المواعيد"], ["tkt", "🎟️ التذاكر"], ["bus", "🚌 الحافلات"]] as const).map(([k, l]) => (
          <button key={k} onClick={() => setKind(k)} className={`h-11 rounded-xl text-sm font-bold border ${kind === k ? "bg-blue-700 text-white border-blue-700" : "bg-white border-slate-200"}`}>{l}</button>
        ))}
      </div>
      {kind === "tkt" && (my.loading ? <Skeleton /> : !my.data?.tickets.length ? <Empty title="لا توجد تذاكر" hint="تصفح المباريات والفعاليات القادمة" /> : my.data.tickets.map((t) => (
        <Card key={t.id} className="border-r-4 border-r-amber-500">
          <div className="flex justify-between gap-2"><b className="text-sm">{t.title}</b><span className="text-xs font-bold bg-amber-100 text-amber-800 rounded px-2 py-0.5 h-fit">{t.quantity} × {t.tier}</span></div>
          <div className="text-xs text-slate-500 mt-1">{t.venue} • {t.date} • {t.time}</div>
          <div className="flex justify-between items-center mt-3"><span className="font-mono font-black text-blue-700 text-lg tracking-wider">{t.orderRef}</span><b className="text-sm">{lyd(t.total)}</b></div>
          <p className="text-[11px] text-slate-400 mt-1">اعرض هذا الرقم عند بوابة الدخول</p>
        </Card>
      )))}
      {kind === "bus" && (my.loading ? <Skeleton /> : !my.data?.trips.length ? <Empty title="لا توجد رحلات" hint="احجز مقعدك في رحلات الحافلات بين المدن" /> : my.data.trips.map((t) => (
        <Card key={t.ref} className="border-r-4 border-r-blue-600">
          <div className="flex justify-between gap-2"><b>{t.from} ← {t.to}</b><span className="text-xs text-slate-500">{t.operator}</span></div>
          <div className="text-sm text-slate-600 mt-1">{t.date} • انطلاق {t.time} • المقاعد: <b>{t.seats.join("، ")}</b></div>
          <div className="text-xs text-slate-500 mt-1">{t.station}</div>
          <div className="flex justify-between items-center mt-3"><span className="font-mono font-black text-blue-700 tracking-wider">{t.ref}</span><b className="text-sm">{lyd(t.total)}</b></div>
        </Card>
      )))}
      {kind === "svc" && <>
      <div className="grid grid-cols-2 gap-2 bg-slate-100 p-1 rounded-xl">
        {(["up", "past"] as const).map((t) => (
          <button key={t} onClick={() => setTab(t)} className={`min-h-[40px] rounded-lg text-sm font-bold ${tab === t ? "bg-white shadow" : "text-slate-500"}`}>{t === "up" ? "القادمة" : "السابقة"}</button>
        ))}
      </div>
      {loading ? <Skeleton /> : error ? <ErrorBox message={error} onRetry={reload} /> : list.length === 0 ? <Empty title="لا توجد حجوزات" hint="ابحث عن خدمة واحجز خلال ثوانٍ" /> : list.map((b) => (
        <Card key={b.id}>
          <div className="flex justify-between gap-2">
            <div>
              <div className="font-black text-sm">{b.serviceName}</div>
              <div className="text-xs text-slate-500">{b.organizationName}</div>
            </div>
            <span className="text-xs font-bold px-2 py-1 rounded-lg bg-slate-100 h-fit">{STATUS_AR[b.status] || b.status}</span>
          </div>
          <div className="flex justify-between text-sm mt-3">
            <span>{b.bookingDate} • {b.startTime}</span>
            <b>{lyd(b.totalPrice)}</b>
          </div>
          <div className="text-[11px] text-slate-400 mt-1 font-mono">{b.bookingRef} • {b.paymentMethod === "WALLET" ? "مدفوع بالمحفظة" : "الدفع في المكان"}</div>
          {tab === "up" && (confirmId === b.id ? (
            <div className="mt-3 p-3 bg-red-50 rounded-xl space-y-2">
              <p className="text-xs text-red-800">تأكيد الإلغاء؟ الاسترداد حسب السياسة: كامل قبل 24 ساعة، 50% قبل 6 ساعات، وإلا لا يوجد استرداد.</p>
              <div className="flex gap-2">
                <Btn variant="danger" disabled={busy} onClick={() => cancel(b.id)} className="flex-1">تأكيد الإلغاء</Btn>
                <Btn variant="ghost" onClick={() => setConfirmId(null)} className="flex-1">تراجع</Btn>
              </div>
            </div>
          ) : (
            <Btn variant="ghost" className="w-full mt-3" onClick={() => setConfirmId(b.id)}>إلغاء الحجز</Btn>
          ))}
        </Card>
      ))}
      </>}
      {toast.node}
    </div>
  );
}
