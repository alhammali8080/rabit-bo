import SiteHeader from "@/components/site/SiteHeader";
import SiteFooter from "@/components/site/SiteFooter";
import CategoryGrid from "@/components/site/CategoryGrid";

export const metadata = { title: "كل التصنيفات | رابط للحجوزات" };

export default function Page() {
  return (
    <div className="min-h-screen bg-slate-50">
      <SiteHeader />
      <main className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="text-2xl sm:text-3xl font-black mb-2">كل التصنيفات</h1>
        <p className="text-slate-500 mb-6">اختر القسم وشاهد المنشآت والخدمات المتاحة للحجز الفوري.</p>
        <CategoryGrid />
      </main>
      <SiteFooter />
    </div>
  );
}
