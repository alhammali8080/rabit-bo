"use client";

import type { ReactNode } from "react";
import RoleShell from "@/components/RoleShell";
import RoleGate from "@/components/RoleGate";
import InlineLogin from "@/components/InlineLogin";
import { workspaceNav } from "@/lib/navs";

const ROLES = ["PROVIDER_OWNER"];

export default function ProviderLayout({ children }: { children: ReactNode }) {
  return (
    <RoleGate roles={ROLES} portal="provider" login={(p) => <InlineLogin portal={p} />}>
      {(u) => <RoleShell brand="رابط للأعمال" subtitle={u.fullName} nav={workspaceNav("/provider", u.permissions).nav}>{children}</RoleShell>}
    </RoleGate>
  );
}
