import { Suspense } from "react";
import Workspace from "@/components/Workspace";
import { Skeleton } from "@/components/ui";

export default function Page() {
  return <Suspense fallback={<Skeleton rows={5} />}><Workspace /></Suspense>;
}
