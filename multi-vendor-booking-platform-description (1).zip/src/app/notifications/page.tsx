"use client";

import { useState } from "react";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { Btn, Card, Empty, ErrorBox, Skeleton, postJson, useApi } from "@/components/ui";

interface N { id: number; titleAr: string; bodyAr: string; isRead: boolean; createdAt: string }

export default function NotificationsPage() {
  const { data, loading, error, reload } = useApi<N[]>("/api/notifications");
  const me = useApi<{ user: { home: string } | null }>("/api/me");
  const [filter, setFilter] = useState<"all" | "unread" | "read">("all");
  const list = (data || []).filter((n) => (filter === "all" ? true : filter === "unread" ? !n.isRead : n.isRead));

  return (
    <div className="min-h-screen bg-slate-50 p-4 max-w-2xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <Link href={me.data?.user?.home || "/"} className="flex items-center gap-1 text-sm font-bold text-blue-700"><ArrowRight className="w-4 h-4" /> رجوع</Link>
        <Btn variant="ghost" onClick={async () => { await postJson("/api/notifications", {}); reload(); }}>تحديد الكل كمقروء</Btn>
      </div>
      <h1 className="text-xl font-black">الإشعارات</h1>
      <div className="flex gap-2">
        {(["all", "unread", "read"] as const).map((f) => (
          <button key={f} onClick={() => setFilter(f)} className={`px-3 py-2 rounded-xl text-sm font-bold ${filter === f ? "bg-blue-700 text-white" : "bg-white border border-slate-200"}`}>
            {{ all: "الكل", unread: "غير مقروءة", read: "مقروءة" }[f]}
          </button>
        ))}
      </div>
      {loading ? <Skeleton /> : error ? <ErrorBox message={error} onRetry={reload} /> : list.length === 0 ? <Empty title="لا توجد إشعارات" /> : (
        list.map((n) => (
          <Card key={n.id} className={n.isRead ? "" : "border-blue-300 bg-blue-50/40"}>
            <div className="font-bold text-sm">{n.titleAr}</div>
            <p className="text-sm text-slate-600 mt-1">{n.bodyAr}</p>
            <div className="text-[11px] text-slate-400 mt-2">{new Date(n.createdAt).toLocaleString("ar-LY")}</div>
          </Card>
        ))
      )}
    </div>
  );
}
