"use client";

import Link from "next/link";
import { Bus } from "lucide-react";
import ProviderBrowser from "@/components/ProviderBrowser";
import BusSearch from "@/components/site/BusSearch";
import { useMe } from "@/components/site/SiteHeader";

export default function CategoryBody({ slug }: { slug: string }) {
  const me = useMe();
  return (
    <div className="space-y-6">
      {slug === "cars" && (
        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <div className="font-black mb-3 flex items-center gap-2"><Bus className="w-5 h-5 text-blue-700" /> رحلات الحافلات بين المدن</div>
          <BusSearch />
        </div>
      )}
      {slug === "medical" && (
        <Link href="/health" className="block rounded-2xl bg-emerald-50 border border-emerald-200 p-4 font-bold text-emerald-800">🏥 محتار؟ استخدم «رابط الصحي» للمقارنة والاستشارة المجانية ←</Link>
      )}
      <ProviderBrowser loggedIn={me?.user?.role === "CUSTOMER"} categorySlug={slug} excludeSlugs={["sahel-bus", "najm-express-bus"]} />
    </div>
  );
}
