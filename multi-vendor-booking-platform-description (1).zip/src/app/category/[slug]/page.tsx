import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { categories } from "@/db/schema";
import { seedDatabase } from "@/db/seed";
import SiteHeader from "@/components/site/SiteHeader";
import SiteFooter from "@/components/site/SiteFooter";
import CategoryBody from "./CategoryBody";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const [c] = await db.select().from(categories).where(eq(categories.slug, slug));
  return { title: c ? `${c.nameAr} | رابط للحجوزات` : "رابط للحجوزات" };
}

export default async function Page({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  if (slug === "tickets") redirect("/events");
  await seedDatabase();
  const [c] = await db.select().from(categories).where(eq(categories.slug, slug));
  if (!c || !c.isActive) notFound();
  return (
    <div className="min-h-screen bg-slate-50">
      <SiteHeader />
      <div className="bg-gradient-to-l from-blue-900 to-blue-700 text-white">
        <div className="max-w-7xl mx-auto px-4 py-8 sm:py-10">
          <nav className="text-xs text-blue-200 mb-2"><Link href="/" className="hover:text-white">الرئيسية</Link> / <Link href="/categories" className="hover:text-white">التصنيفات</Link></nav>
          <h1 className="text-2xl sm:text-4xl font-black flex items-center gap-3"><span aria-hidden>{c.icon}</span>{c.nameAr}</h1>
        </div>
      </div>
      <main className="max-w-7xl mx-auto px-4 py-8"><CategoryBody slug={slug} /></main>
      <SiteFooter />
    </div>
  );
}
