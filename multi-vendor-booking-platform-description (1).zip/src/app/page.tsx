"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Bus, ShieldCheck, Wallet, Zap, HeartPulse, ChevronLeft } from "lucide-react";
import SiteHeader, { useMe } from "@/components/site/SiteHeader";
import SiteFooter from "@/components/site/SiteFooter";
import BannerCarousel from "@/components/site/BannerCarousel";
import CategoryGrid from "@/components/site/CategoryGrid";
import BusSearch from "@/components/site/BusSearch";
import EventCard, { type EventRow } from "@/components/site/EventCard";
import ProviderBrowser from "@/components/ProviderBrowser";
import JoinVendorModal from "@/lib/JoinVendorModal";

function Section({ title, href, children }: { title: string; href?: string; children: React.ReactNode }) {
  return (
    <section className="mt-12">
      <div className="flex items-end justify-between mb-4">
        <h2 className="text-xl sm:text-2xl font-black text-slate-900">{title}</h2>
        {href && <Link href={href} className="text-sm font-bold text-blue-700 flex items-center">عرض الكل <ChevronLeft className="w-4 h-4" /></Link>}
      </div>
      {children}
    </section>
  );
}

export default function Home() {
  const me = useMe();
  const [events, setEvents] = useState<EventRow[] | null>(null);
  const [join, setJoin] = useState(false);
  useEffect(() => { fetch("/api/events").then((r) => r.json()).then((d) => setEvents(Array.isArray(d) ? d : [])).catch(() => setEvents([])); }, []);

  return (
    <div className="min-h-screen bg-slate-50">
      <SiteHeader />
      <main className="max-w-7xl mx-auto px-4 pt-5">
        <BannerCarousel />

        <div className="relative -mt-8 sm:-mt-10 mx-2 sm:mx-8 bg-white rounded-2xl shadow-xl border border-slate-200 p-4 sm:p-5 z-10">
          <div className="flex items-center gap-2 mb-3 font-black text-slate-900"><Bus className="w-5 h-5 text-blue-700" /> احجز رحلتك بالحافلة بين المدن</div>
          <BusSearch />
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mt-8">
          {[{ i: ShieldCheck, t: "منشآت موثقة", d: "نتحقق من كل شريك" }, { i: Zap, t: "تأكيد فوري", d: "بدون اتصالات أو انتظار" }, { i: Wallet, t: "محفظة وكروت شحن", d: "ادفع بأمان بضغطة" }, { i: HeartPulse, t: "مستشار صحي", d: "استشارة مجانية" }].map(({ i: I, t, d }) => (
            <div key={t} className="flex items-center gap-3 bg-white rounded-2xl border border-slate-200 p-4">
              <span className="w-10 h-10 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center shrink-0"><I className="w-5 h-5" /></span>
              <div><div className="font-bold text-sm">{t}</div><div className="text-xs text-slate-500">{d}</div></div>
            </div>
          ))}
        </div>

        <Section title="ماذا تريد أن تحجز؟" href="/categories"><CategoryGrid /></Section>

        <Section title="المباريات والفعاليات القادمة" href="/events">
          {!events ? <div className="grid sm:grid-cols-3 gap-5">{[0, 1, 2].map((k) => <div key={k} className="h-72 rounded-2xl bg-slate-200 animate-pulse" />)}</div>
            : <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{events.slice(0, 3).map((e) => <EventCard key={e.id} e={e} />)}</div>}
        </Section>

        <Section title="الأعلى تقييماً" href="/categories">
          <ProviderBrowser loggedIn={me?.user?.role === "CUSTOMER"} limit={6} showSearch={false} excludeSlugs={["sahel-bus", "najm-express-bus"]} />
        </Section>

        <section className="mt-12 grid lg:grid-cols-2 gap-5">
          <Link href="/health" className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-emerald-700 to-teal-600 text-white p-7 min-h-[200px] flex flex-col justify-end">
            <span className="text-5xl absolute top-6 left-6 opacity-30" aria-hidden>🏥</span>
            <span className="text-xs font-bold bg-white/20 rounded-full px-3 py-1 w-fit">رابط الصحي</span>
            <div className="text-2xl font-black mt-2">قارن المصحات واحصل على استشارة مجانية</div>
            <div className="text-sm text-emerald-50 mt-1">أجب على 3 أسئلة ونقترح لك الأنسب بالسعر والتقييم</div>
          </Link>
          <div id="join" className="rounded-3xl bg-gradient-to-br from-slate-900 to-blue-900 text-white p-7 min-h-[200px] flex flex-col justify-end">
            <span className="text-xs font-bold bg-white/15 rounded-full px-3 py-1 w-fit">لأصحاب الأعمال</span>
            <div className="text-2xl font-black mt-2">أدر حجوزاتك وموظفيك وإيراداتك من مكان واحد</div>
            <div className="flex flex-wrap gap-2 mt-4">
              <button onClick={() => setJoin(true)} className="h-11 px-5 rounded-xl bg-amber-500 text-slate-950 font-black">انضم كمزود خدمة</button>
              <Link href="/login/provider" className="h-11 px-5 rounded-xl bg-white/15 font-bold flex items-center">دخول المزودين</Link>
            </div>
          </div>
        </section>
      </main>
      <SiteFooter />
      <JoinVendorModal isOpen={join} onClose={() => setJoin(false)} categories={[]} />
    </div>
  );
}
