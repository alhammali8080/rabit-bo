"use client";

import Link from "next/link";
import { Suspense, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Clock, Wifi, Users, ArrowLeft } from "lucide-react";
import SiteHeader from "@/components/site/SiteHeader";
import SiteFooter from "@/components/site/SiteFooter";
import BusSearch from "@/components/site/BusSearch";
import { Empty, ErrorBox, Skeleton, lyd } from "@/components/ui";

interface Trip { id: number; operator: string; fromCity: string; toCity: string; tripDate: string; departTime: string; arriveTime: string; busType: string; price: string; seatsLeft: number; amenities: string[]; stationAr: string }

const dur = (a: string, b: string) => { let m = (Number(b.slice(0, 2)) * 60 + Number(b.slice(3))) - (Number(a.slice(0, 2)) * 60 + Number(a.slice(3))); if (m < 0) m += 1440; return `${Math.floor(m / 60)} س${m % 60 ? ` ${m % 60} د` : ""}`; };

function Results() {
  const sp = useSearchParams();
  const from = sp.get("from") || "", to = sp.get("to") || "", date = sp.get("date") || "";
  const [trips, setTrips] = useState<Trip[] | null>(null);
  const [err, setErr] = useState("");
  useEffect(() => {
    if (!from) { setTrips(null); return; }
    setTrips(null); setErr("");
    fetch(`/api/bus/search?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}&date=${date}`).then(async (r) => { const j = await r.json(); if (!r.ok) throw new Error(j.error); setTrips(j.trips); }).catch((e) => setErr(e.message));
  }, [from, to, date]);

  return (
    <>
      <div className="bg-gradient-to-l from-blue-900 to-blue-700">
        <div className="max-w-5xl mx-auto px-4 py-8">
          <h1 className="text-2xl sm:text-3xl font-black text-white mb-4">🚌 رحلات الحافلات بين المدن</h1>
          <div className="bg-white rounded-2xl p-4 shadow-xl"><BusSearch initial={{ from, to, date }} /></div>
        </div>
      </div>
      <main className="max-w-5xl mx-auto px-4 py-8 space-y-3">
        {!from ? (
          <div className="grid sm:grid-cols-3 gap-3">
            {[["طرابلس", "بنغازي"], ["طرابلس", "مصراتة"], ["طرابلس", "سبها"], ["بنغازي", "طبرق"], ["مصراتة", "طرابلس"], ["طرابلس", "الزاوية"]].map(([a, b]) => (
              <Link key={a + b} href={`/bus?from=${a}&to=${b}&date=${new Date().toISOString().slice(0, 10)}`} className="bg-white rounded-2xl border border-slate-200 p-4 font-bold flex items-center justify-between hover:border-blue-400">
                <span>{a} <ArrowLeft className="w-4 h-4 inline text-slate-400" /> {b}</span><span className="text-xs text-blue-700">رحلات اليوم</span>
              </Link>
            ))}
          </div>
        ) : err ? <ErrorBox message={err} /> : !trips ? <Skeleton rows={4} /> : trips.length === 0 ? <Empty title="لا توجد رحلات متاحة في هذا اليوم" hint="جرّب تاريخاً آخر" /> : (
          <>
            <p className="text-sm text-slate-500">{trips.length} رحلة من {from} إلى {to}</p>
            {trips.map((t) => (
              <div key={t.id} className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 grid sm:grid-cols-[1fr_auto] gap-4 hover:shadow-lg transition">
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <span className="font-black">{t.operator}</span>
                    <span className={`text-[11px] font-bold rounded px-2 py-0.5 ${t.busType === "VIP" ? "bg-amber-100 text-amber-800" : "bg-slate-100 text-slate-600"}`}>{t.busType === "VIP" ? "VIP 2+1" : "عادي 2+2"}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="text-center"><div className="text-xl font-black">{t.departTime}</div><div className="text-xs text-slate-500">{t.fromCity}</div></div>
                    <div className="flex-1 flex flex-col items-center text-xs text-slate-400"><span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" />{dur(t.departTime, t.arriveTime)}</span><span className="w-full h-px bg-slate-300 my-1" /></div>
                    <div className="text-center"><div className="text-xl font-black">{t.arriveTime}</div><div className="text-xs text-slate-500">{t.toCity}</div></div>
                  </div>
                  <div className="flex flex-wrap gap-3 mt-3 text-xs text-slate-500">
                    <span className="flex items-center gap-1"><Wifi className="w-3.5 h-3.5" />{t.amenities.join(" • ")}</span>
                    <span className={`flex items-center gap-1 ${t.seatsLeft < 8 ? "text-red-600 font-bold" : ""}`}><Users className="w-3.5 h-3.5" />{t.seatsLeft} مقعد متاح</span>
                  </div>
                </div>
                <div className="flex sm:flex-col items-center sm:items-end justify-between gap-2 border-t sm:border-t-0 sm:border-r sm:pr-5 pt-3 sm:pt-0">
                  <div className="text-2xl font-black text-blue-700">{lyd(t.price)}</div>
                  <Link href={`/bus/${t.id}`} className={`h-11 px-6 rounded-xl font-black flex items-center ${t.seatsLeft > 0 ? "bg-amber-500 hover:bg-amber-400 text-slate-950" : "bg-slate-200 text-slate-500 pointer-events-none"}`}>{t.seatsLeft > 0 ? "اختر مقعدك" : "ممتلئة"}</Link>
                </div>
              </div>
            ))}
          </>
        )}
      </main>
    </>
  );
}

export default function BusPage() {
  return (
    <div className="min-h-screen bg-slate-50">
      <SiteHeader />
      <Suspense fallback={<div className="max-w-5xl mx-auto p-4"><Skeleton /></div>}><Results /></Suspense>
      <SiteFooter />
    </div>
  );
}
