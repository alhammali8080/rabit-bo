"use client";

import Link from "next/link";
import { use, useEffect, useState } from "react";
import { CheckCircle2, MapPin } from "lucide-react";
import SiteHeader, { useMe } from "@/components/site/SiteHeader";
import SiteFooter from "@/components/site/SiteFooter";
import { fmtDate } from "@/components/site/EventCard";
import { Btn, ErrorBox, Skeleton, inputCls, lyd, postJson } from "@/components/ui";
import { apiFetch } from "@/lib/clientAuth";

interface Trip { id: number; operator: string; fromCity: string; toCity: string; tripDate: string; departTime: string; arriveTime: string; busType: string; seatCount: number; price: string; amenities: string[]; stationAr: string; taken: number[] }

export default function TripPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const me = useMe();
  const [trip, setTrip] = useState<Trip | null>(null);
  const [err, setErr] = useState("");
  const [picked, setPicked] = useState<number[]>([]);
  const [name, setName] = useState("");
  const [balance, setBalance] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const [bookErr, setBookErr] = useState("");
  const [done, setDone] = useState<{ bookingRef: string; seats: number[] } | null>(null);
  const isCustomer = me?.user?.role === "CUSTOMER";

  const load = () => fetch(`/api/bus/trips/${id}`).then(async (r) => { const j = await r.json(); if (!r.ok) throw new Error(j.error); setTrip(j); }).catch((e) => setErr(e.message));
  useEffect(() => { load(); }, [id]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (me?.user) setName(me.user.fullName); if (isCustomer) apiFetch("/api/wallet?limit=1").then((r) => r.json()).then((j) => setBalance(parseFloat(j.wallet.balance))).catch(() => {}); }, [me, isCustomer, done]);

  if (err) return <div className="min-h-screen bg-slate-50"><SiteHeader /><main className="max-w-3xl mx-auto p-4"><ErrorBox message={err} /></main></div>;
  if (!trip) return <div className="min-h-screen bg-slate-50"><SiteHeader /><main className="max-w-5xl mx-auto p-4"><Skeleton rows={5} /></main></div>;

  const perRow = trip.busType === "VIP" ? 3 : 4;
  const rows = Math.ceil(trip.seatCount / perRow);
  const total = picked.length * (parseFloat(trip.price) + 1);
  const toggle = (n: number) => setPicked((p) => (p.includes(n) ? p.filter((x) => x !== n) : p.length < 6 ? [...p, n].sort((a, b) => a - b) : p));

  async function book() {
    setBusy(true); setBookErr("");
    try { const r = await postJson(`/api/bus/trips/${id}/book`, { seats: picked, passengerName: name }); setDone(r); setPicked([]); load(); }
    catch (e) { setBookErr((e as Error).message); load(); setPicked([]); } finally { setBusy(false); }
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <SiteHeader />
      <main className="max-w-5xl mx-auto px-4 py-6">
        <Link href={`/bus?from=${trip.fromCity}&to=${trip.toCity}&date=${trip.tripDate}`} className="text-sm font-bold text-blue-700">→ رجوع للرحلات</Link>
        <div className="bg-white rounded-2xl border border-slate-200 p-5 mt-3">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <div className="text-xl font-black">{trip.fromCity} ← {trip.toCity}</div>
              <div className="text-sm text-slate-500">{fmtDate(trip.tripDate)} • {trip.departTime} – {trip.arriveTime} • {trip.operator}</div>
              <div className="text-xs text-slate-500 flex items-center gap-1 mt-1"><MapPin className="w-3.5 h-3.5" />{trip.stationAr}</div>
            </div>
            <div className="text-2xl font-black text-blue-700">{lyd(trip.price)} <span className="text-sm text-slate-500 font-normal">/ مقعد</span></div>
          </div>
        </div>

        <div className="grid lg:grid-cols-[1fr_340px] gap-6 mt-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-5">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-black">اختر مقعدك (حتى 6)</h2>
              <div className="flex gap-3 text-xs">
                <span className="flex items-center gap-1"><span className="w-4 h-4 rounded border-2 border-slate-300" />متاح</span>
                <span className="flex items-center gap-1"><span className="w-4 h-4 rounded bg-blue-700" />اختيارك</span>
                <span className="flex items-center gap-1"><span className="w-4 h-4 rounded bg-slate-300" />محجوز</span>
              </div>
            </div>
            <div className="max-w-xs mx-auto border-2 border-slate-200 rounded-t-[40px] rounded-b-2xl p-4">
              <div className="flex justify-start mb-4"><span className="text-xs text-slate-400 border rounded-lg px-2 py-1">🚍 السائق</span></div>
              <div className="space-y-2">
                {Array.from({ length: rows }).map((_, r) => (
                  <div key={r} className="flex justify-between">
                    {Array.from({ length: perRow + 1 }).map((__, c) => {
                      const aisle = perRow === 3 ? c === 1 : c === 2;
                      if (aisle) return <span key={c} className="w-10" />;
                      const idx = c > (perRow === 3 ? 1 : 2) ? c - 1 : c;
                      const n = r * perRow + idx + 1;
                      if (n > trip.seatCount) return <span key={c} className="w-10" />;
                      const taken = trip.taken.includes(n), sel = picked.includes(n);
                      return (
                        <button key={c} disabled={taken || !!done} onClick={() => toggle(n)} aria-label={`مقعد ${n}${taken ? " محجوز" : ""}`} aria-pressed={sel}
                          className={`w-10 h-10 rounded-lg text-xs font-bold transition ${taken ? "bg-slate-300 text-slate-500 cursor-not-allowed" : sel ? "bg-blue-700 text-white" : "border-2 border-slate-300 hover:border-blue-500"}`}>{n}</button>
                      );
                    })}
                  </div>
                ))}
              </div>
            </div>
          </div>

          <aside className="bg-white rounded-2xl border border-slate-200 p-5 h-fit lg:sticky lg:top-20 space-y-4">
            {done ? (
              <div className="text-center space-y-3">
                <CheckCircle2 className="w-14 h-14 text-emerald-600 mx-auto" />
                <div className="font-black text-lg">تم حجز رحلتك</div>
                <div className="font-mono font-bold text-blue-700">{done.bookingRef}</div>
                <p className="text-sm text-slate-500">المقاعد: {done.seats.join("، ")} – احضر إلى المحطة قبل 30 دقيقة.</p>
                <Link href="/app/bookings"><Btn className="w-full">عرض حجوزاتي</Btn></Link>
              </div>
            ) : (
              <>
                <div className="font-black">ملخص الحجز</div>
                <div className="text-sm">المقاعد: {picked.length ? <b>{picked.join("، ")}</b> : <span className="text-slate-400">لم تختر بعد</span>}</div>
                <input className={inputCls} placeholder="اسم المسافر" value={name} onChange={(e) => setName(e.target.value)} />
                <div className="bg-slate-50 rounded-xl p-3 text-sm space-y-1">
                  <div className="flex justify-between"><span>{picked.length} × {lyd(trip.price)}</span><b>{lyd(picked.length * parseFloat(trip.price))}</b></div>
                  <div className="flex justify-between"><span>رسوم الخدمة</span><b>{lyd(picked.length)}</b></div>
                  <div className="flex justify-between border-t pt-1 text-base"><span>الإجمالي</span><b className="text-blue-700">{lyd(total)}</b></div>
                  {balance != null && <div className={`flex justify-between text-xs ${balance < total ? "text-red-600" : "text-slate-500"}`}><span>رصيد محفظتك</span><span>{lyd(balance)}</span></div>}
                </div>
                {bookErr && <div className="p-3 rounded-xl bg-red-50 text-red-700 text-sm">{bookErr}</div>}
                {!me ? <Skeleton rows={1} /> : !isCustomer ? (
                  <Link href="/login/customer"><Btn variant="accent" className="w-full min-h-[52px]">سجّل الدخول للحجز</Btn></Link>
                ) : balance != null && balance < total ? (
                  <Link href="/app/wallet"><Btn variant="accent" className="w-full min-h-[52px]">الرصيد غير كافٍ – اشحن المحفظة</Btn></Link>
                ) : (
                  <Btn variant="accent" className="w-full min-h-[52px] text-base" disabled={busy || !picked.length || name.trim().length < 3} onClick={book}>{busy ? "جاري الحجز..." : picked.length ? `ادفع ${lyd(total)} واحجز` : "اختر مقعداً"}</Btn>
                )}
              </>
            )}
          </aside>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
