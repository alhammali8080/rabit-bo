"use client";

import Link from "next/link";
import { use, useEffect, useState } from "react";
import { CalendarDays, MapPin, Minus, Plus, CheckCircle2, ShieldCheck } from "lucide-react";
import SiteHeader, { useMe } from "@/components/site/SiteHeader";
import SiteFooter from "@/components/site/SiteFooter";
import { fmtDate } from "@/components/site/EventCard";
import { apiFetch } from "@/lib/clientAuth";
import { Btn, ErrorBox, Skeleton, lyd, postJson } from "@/components/ui";

interface Tier { id: number; nameAr: string; price: string; left: number; maxPerOrder: number }
interface Ev { id: number; titleAr: string; subtitleAr: string | null; venueAr: string; eventDate: string; eventTime: string; imageUrl: string; homeTeam: string | null; awayTeam: string | null; descriptionAr: string | null; tiers: Tier[] }

export default function EventPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = use(params);
  const me = useMe();
  const [ev, setEv] = useState<Ev | null>(null);
  const [err, setErr] = useState("");
  const [tierId, setTierId] = useState<number | null>(null);
  const [qty, setQty] = useState(1);
  const [balance, setBalance] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<{ orderRef: string } | null>(null);
  const [buyErr, setBuyErr] = useState("");

  const load = () => fetch(`/api/events/${slug}`).then(async (r) => { const j = await r.json(); if (!r.ok) throw new Error(j.error); setEv(j); setTierId((t) => t ?? j.tiers.find((x: Tier) => x.left > 0)?.id ?? null); }).catch((e) => setErr(e.message));
  useEffect(() => { load(); }, [slug]); // eslint-disable-line react-hooks/exhaustive-deps
  const isCustomer = me?.user?.role === "CUSTOMER";
  useEffect(() => { if (isCustomer) apiFetch("/api/wallet?limit=1").then((r) => r.json()).then((j) => setBalance(parseFloat(j.wallet.balance))).catch(() => {}); }, [isCustomer, done]);

  if (err) return <div className="min-h-screen bg-slate-50"><SiteHeader /><main className="max-w-3xl mx-auto p-4"><ErrorBox message={err} /></main></div>;
  if (!ev) return <div className="min-h-screen bg-slate-50"><SiteHeader /><main className="max-w-5xl mx-auto p-4"><Skeleton rows={4} /></main></div>;
  const tier = ev.tiers.find((t) => t.id === tierId);
  const total = tier ? parseFloat(tier.price) * qty + qty : 0;

  async function buy() {
    setBusy(true); setBuyErr("");
    try { const r = await postJson(`/api/events/${slug}/buy`, { tierId, quantity: qty }); setDone(r); load(); }
    catch (e) { setBuyErr((e as Error).message); } finally { setBusy(false); }
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <SiteHeader />
      <div className="relative h-64 sm:h-80">
        <img src={ev.imageUrl} alt="" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent" />
        <div className="relative max-w-5xl mx-auto px-4 h-full flex flex-col justify-end pb-6 text-white">
          {ev.homeTeam && <div className="text-2xl sm:text-4xl font-black">{ev.homeTeam} <span className="text-amber-400">×</span> {ev.awayTeam}</div>}
          <h1 className={ev.homeTeam ? "text-slate-200 mt-1" : "text-2xl sm:text-4xl font-black"}>{ev.homeTeam ? ev.subtitleAr : ev.titleAr}</h1>
          <div className="flex flex-wrap gap-4 mt-3 text-sm text-slate-200">
            <span className="flex items-center gap-1"><CalendarDays className="w-4 h-4" />{fmtDate(ev.eventDate)} • {ev.eventTime}</span>
            <span className="flex items-center gap-1"><MapPin className="w-4 h-4" />{ev.venueAr}</span>
          </div>
        </div>
      </div>

      <main className="max-w-5xl mx-auto px-4 py-8 grid lg:grid-cols-[1fr_360px] gap-6">
        <div className="space-y-3">
          <h2 className="font-black text-lg">اختر فئة التذكرة</h2>
          {ev.tiers.map((t) => (
            <button key={t.id} disabled={t.left <= 0} onClick={() => { setTierId(t.id); setQty(1); }}
              className={`w-full text-right bg-white rounded-2xl border-2 p-4 flex items-center justify-between gap-3 transition disabled:opacity-50 ${tierId === t.id ? "border-blue-700 ring-4 ring-blue-100" : "border-slate-200 hover:border-blue-300"}`}>
              <div>
                <div className="font-black">{t.nameAr}</div>
                <div className={`text-xs mt-1 ${t.left < 100 ? "text-red-600 font-bold" : "text-slate-500"}`}>{t.left <= 0 ? "نفدت التذاكر" : t.left < 100 ? `متبقٍ ${t.left} تذكرة فقط` : "متوفرة"}</div>
              </div>
              <div className="text-xl font-black text-blue-700">{lyd(t.price)}</div>
            </button>
          ))}
          <p className="text-sm text-slate-500 pt-2">{ev.descriptionAr}</p>
        </div>

        <aside className="bg-white rounded-2xl border border-slate-200 p-5 h-fit lg:sticky lg:top-20 space-y-4">
          {done ? (
            <div className="text-center space-y-3 py-2">
              <CheckCircle2 className="w-14 h-14 text-emerald-600 mx-auto" />
              <div className="font-black text-lg">تم شراء التذاكر</div>
              <div className="font-mono font-bold text-blue-700">{done.orderRef}</div>
              <p className="text-sm text-slate-500">اعرض رقم الطلب من «حجوزاتي» عند بوابة الملعب.</p>
              <Link href="/app/bookings"><Btn className="w-full">عرض تذاكري</Btn></Link>
            </div>
          ) : tier ? (
            <>
              <div className="font-black">{tier.nameAr}</div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold">عدد التذاكر</span>
                <div className="flex items-center gap-3">
                  <button onClick={() => setQty(Math.max(1, qty - 1))} aria-label="إنقاص" className="w-10 h-10 rounded-xl border flex items-center justify-center"><Minus className="w-4 h-4" /></button>
                  <span className="w-6 text-center font-black text-lg">{qty}</span>
                  <button onClick={() => setQty(Math.min(tier.maxPerOrder, tier.left, qty + 1))} aria-label="زيادة" className="w-10 h-10 rounded-xl border flex items-center justify-center"><Plus className="w-4 h-4" /></button>
                </div>
              </div>
              <div className="bg-slate-50 rounded-xl p-3 text-sm space-y-1">
                <div className="flex justify-between"><span>{qty} × {lyd(tier.price)}</span><b>{lyd(parseFloat(tier.price) * qty)}</b></div>
                <div className="flex justify-between"><span>رسوم الخدمة</span><b>{lyd(qty)}</b></div>
                <div className="flex justify-between border-t pt-1 text-base"><span>الإجمالي</span><b className="text-blue-700">{lyd(total)}</b></div>
                {balance != null && <div className={`flex justify-between text-xs ${balance < total ? "text-red-600" : "text-slate-500"}`}><span>رصيد محفظتك</span><span>{lyd(balance)}</span></div>}
              </div>
              {buyErr && <div className="p-3 rounded-xl bg-red-50 text-red-700 text-sm">{buyErr}</div>}
              {!me ? <Skeleton rows={1} /> : !isCustomer ? (
                <Link href={`/login/customer`}><Btn variant="accent" className="w-full min-h-[52px]">سجّل الدخول لشراء التذاكر</Btn></Link>
              ) : balance != null && balance < total ? (
                <Link href="/app/wallet"><Btn variant="accent" className="w-full min-h-[52px]">الرصيد غير كافٍ – اشحن المحفظة</Btn></Link>
              ) : (
                <Btn variant="accent" className="w-full min-h-[52px] text-base" disabled={busy} onClick={buy}>{busy ? "جاري الشراء..." : `ادفع ${lyd(total)} من المحفظة`}</Btn>
              )}
              <p className="text-xs text-slate-500 flex items-center gap-1"><ShieldCheck className="w-4 h-4 text-emerald-600" /> دفع آمن – التذكرة تصلك فوراً</p>
            </>
          ) : <p className="text-sm text-slate-500">اختر فئة التذكرة</p>}
        </aside>
      </main>
      <SiteFooter />
    </div>
  );
}
