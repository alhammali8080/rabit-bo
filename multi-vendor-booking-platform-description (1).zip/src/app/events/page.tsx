"use client";

import { useEffect, useState } from "react";
import SiteHeader from "@/components/site/SiteHeader";
import SiteFooter from "@/components/site/SiteFooter";
import EventCard, { type EventRow } from "@/components/site/EventCard";
import { Empty } from "@/components/ui";

export default function EventsPage() {
  const [rows, setRows] = useState<EventRow[] | null>(null);
  const [kind, setKind] = useState("all");
  useEffect(() => { fetch("/api/events").then((r) => r.json()).then((d) => setRows(Array.isArray(d) ? d : [])).catch(() => setRows([])); }, []);
  const list = (rows || []).filter((e) => kind === "all" || e.kind === kind);
  return (
    <div className="min-h-screen bg-slate-50">
      <SiteHeader />
      <main className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="text-2xl sm:text-3xl font-black">المباريات والفعاليات</h1>
        <p className="text-slate-500 mt-1 mb-5">تذاكر إلكترونية تُعرض من حسابك عند البوابة – بدون طوابير.</p>
        <div className="flex gap-2 mb-6">
          {[["all", "الكل"], ["MATCH", "⚽ مباريات"], ["CONCERT", "🎤 حفلات"]].map(([k, l]) => (
            <button key={k} onClick={() => setKind(k)} className={`h-10 px-4 rounded-full text-sm font-bold ${kind === k ? "bg-blue-700 text-white" : "bg-white border border-slate-200"}`}>{l}</button>
          ))}
        </div>
        {!rows ? <div className="grid sm:grid-cols-3 gap-5">{[0, 1, 2].map((k) => <div key={k} className="h-72 rounded-2xl bg-slate-200 animate-pulse" />)}</div>
          : list.length === 0 ? <Empty title="لا توجد فعاليات قادمة حالياً" />
          : <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{list.map((e) => <EventCard key={e.id} e={e} />)}</div>}
      </main>
      <SiteFooter />
    </div>
  );
}
