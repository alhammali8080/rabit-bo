CREATE TABLE "audit_logs" (
	"id" serial PRIMARY KEY NOT NULL,
	"user_id" integer,
	"action" text NOT NULL,
	"entity" text NOT NULL,
	"entity_id" text,
	"old_value" text,
	"new_value" text,
	"ip_address" text,
	"user_agent" text,
	"result" text DEFAULT 'SUCCESS' NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);

CREATE TABLE "banners" (
	"id" serial PRIMARY KEY NOT NULL,
	"title_ar" text NOT NULL,
	"subtitle_ar" text NOT NULL,
	"badge_ar" text,
	"image_url" text NOT NULL,
	"cta_label" text NOT NULL,
	"href" text NOT NULL,
	"is_sponsored" boolean DEFAULT true NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"display_order" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);

CREATE TABLE "bookings" (
	"id" serial PRIMARY KEY NOT NULL,
	"booking_ref" text NOT NULL,
	"organization_id" integer NOT NULL,
	"branch_id" integer NOT NULL,
	"service_id" integer NOT NULL,
	"staff_id" integer,
	"customer_id" integer,
	"customer_name" text NOT NULL,
	"customer_phone" text NOT NULL,
	"customer_email" text,
	"booking_date" text NOT NULL,
	"start_time" text NOT NULL,
	"end_time" text NOT NULL,
	"price" numeric(10, 2) NOT NULL,
	"customer_fee" numeric(10, 2) DEFAULT '0.00' NOT NULL,
	"discount_amount" numeric(10, 2) DEFAULT '0.00' NOT NULL,
	"total_price" numeric(10, 2) NOT NULL,
	"commission_percent" numeric(5, 2) NOT NULL,
	"platform_fee" numeric(10, 2) NOT NULL,
	"provider_net" numeric(10, 2) NOT NULL,
	"currency" text DEFAULT 'LYD' NOT NULL,
	"status" text DEFAULT 'CONFIRMED' NOT NULL,
	"payment_status" text DEFAULT 'PAID' NOT NULL,
	"payment_method" text DEFAULT 'ONLINE' NOT NULL,
	"cancellation_reason" text,
	"notes" text,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "bookings_booking_ref_unique" UNIQUE("booking_ref")
);

CREATE TABLE "branches" (
	"id" serial PRIMARY KEY NOT NULL,
	"organization_id" integer NOT NULL,
	"name_ar" text NOT NULL,
	"city" text NOT NULL,
	"district" text NOT NULL,
	"address" text NOT NULL,
	"phone" text NOT NULL,
	"is_main" boolean DEFAULT false NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"opening_time" text DEFAULT '09:00' NOT NULL,
	"closing_time" text DEFAULT '21:00' NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);

CREATE TABLE "bus_seats" (
	"id" serial PRIMARY KEY NOT NULL,
	"trip_id" integer NOT NULL,
	"seat_no" integer NOT NULL,
	"booking_ref" text NOT NULL,
	"user_id" integer NOT NULL,
	"passenger_name" text NOT NULL,
	"price" numeric(10, 2) NOT NULL,
	"status" text DEFAULT 'BOOKED' NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);

CREATE TABLE "bus_trips" (
	"id" serial PRIMARY KEY NOT NULL,
	"operator_id" integer NOT NULL,
	"from_city" text NOT NULL,
	"to_city" text NOT NULL,
	"trip_date" text NOT NULL,
	"depart_time" text NOT NULL,
	"arrive_time" text NOT NULL,
	"bus_type" text DEFAULT 'VIP' NOT NULL,
	"seat_count" integer DEFAULT 40 NOT NULL,
	"price" numeric(10, 2) NOT NULL,
	"amenities" text DEFAULT '[]' NOT NULL,
	"station_ar" text NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL
);

CREATE TABLE "care_requests" (
	"id" serial PRIMARY KEY NOT NULL,
	"request_ref" text NOT NULL,
	"user_id" integer,
	"full_name" text NOT NULL,
	"phone" text NOT NULL,
	"need_type" text NOT NULL,
	"for_whom" text NOT NULL,
	"age" integer,
	"city" text NOT NULL,
	"budget" text,
	"preferred_date" text,
	"notes" text,
	"status" text DEFAULT 'NEW' NOT NULL,
	"assigned_to" integer,
	"created_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "care_requests_request_ref_unique" UNIQUE("request_ref")
);

CREATE TABLE "categories" (
	"id" serial PRIMARY KEY NOT NULL,
	"slug" text NOT NULL,
	"name_ar" text NOT NULL,
	"name_en" text NOT NULL,
	"description_ar" text NOT NULL,
	"icon" text NOT NULL,
	"default_commission_percent" numeric(5, 2) DEFAULT '7.00' NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"display_order" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "categories_slug_unique" UNIQUE("slug")
);

CREATE TABLE "events" (
	"id" serial PRIMARY KEY NOT NULL,
	"slug" text NOT NULL,
	"title_ar" text NOT NULL,
	"subtitle_ar" text,
	"kind" text DEFAULT 'MATCH' NOT NULL,
	"venue_ar" text NOT NULL,
	"city" text NOT NULL,
	"event_date" text NOT NULL,
	"event_time" text NOT NULL,
	"image_url" text NOT NULL,
	"home_team" text,
	"away_team" text,
	"description_ar" text,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "events_slug_unique" UNIQUE("slug")
);

CREATE TABLE "ledger_entries" (
	"id" serial PRIMARY KEY NOT NULL,
	"organization_id" integer NOT NULL,
	"bookingId" integer,
	"transaction_type" text NOT NULL,
	"gross_amount" numeric(10, 2) NOT NULL,
	"platform_fee" numeric(10, 2) DEFAULT '0.00' NOT NULL,
	"net_amount" numeric(10, 2) NOT NULL,
	"currency" text DEFAULT 'LYD' NOT NULL,
	"description" text NOT NULL,
	"reference" text NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);

CREATE TABLE "notifications" (
	"id" serial PRIMARY KEY NOT NULL,
	"user_id" integer NOT NULL,
	"organization_id" integer,
	"title_ar" text NOT NULL,
	"body_ar" text NOT NULL,
	"type" text NOT NULL,
	"action_url" text,
	"is_read" boolean DEFAULT false NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);

CREATE TABLE "organizations" (
	"id" serial PRIMARY KEY NOT NULL,
	"owner_id" integer NOT NULL,
	"category_id" integer NOT NULL,
	"name_ar" text NOT NULL,
	"name_en" text,
	"slug" text NOT NULL,
	"subtitle_ar" text NOT NULL,
	"description_ar" text NOT NULL,
	"city" text DEFAULT 'طرابلس' NOT NULL,
	"primary_address" text NOT NULL,
	"phone" text NOT NULL,
	"email" text NOT NULL,
	"logo_url" text,
	"cover_url" text,
	"status" text DEFAULT 'VERIFIED' NOT NULL,
	"rating" numeric(3, 2) DEFAULT '5.00' NOT NULL,
	"reviews_count" integer DEFAULT 0 NOT NULL,
	"is_featured" boolean DEFAULT false NOT NULL,
	"featured_expiry" timestamp,
	"custom_commission_percent" numeric(5, 2),
	"cancellation_policy_ar" text DEFAULT 'إلغاء مجاني حتى 24 ساعة قبل الموعد' NOT NULL,
	"require_deposit" boolean DEFAULT false NOT NULL,
	"deposit_percent" numeric(5, 2) DEFAULT '0.00',
	"currency" text DEFAULT 'LYD' NOT NULL,
	"allow_instant_booking" boolean DEFAULT true NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "organizations_slug_unique" UNIQUE("slug")
);

CREATE TABLE "otp_codes" (
	"id" serial PRIMARY KEY NOT NULL,
	"phone" text NOT NULL,
	"code_hash" text NOT NULL,
	"attempts" integer DEFAULT 0 NOT NULL,
	"consumed" boolean DEFAULT false NOT NULL,
	"ip_address" text,
	"expires_at" timestamp NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);

CREATE TABLE "payouts" (
	"id" serial PRIMARY KEY NOT NULL,
	"payout_ref" text NOT NULL,
	"organization_id" integer NOT NULL,
	"amount" numeric(10, 2) NOT NULL,
	"currency" text DEFAULT 'LYD' NOT NULL,
	"status" text DEFAULT 'COMPLETED' NOT NULL,
	"bank_details" text NOT NULL,
	"processed_by_user_id" integer,
	"notes" text,
	"created_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "payouts_payout_ref_unique" UNIQUE("payout_ref")
);

CREATE TABLE "recharge_attempts" (
	"id" serial PRIMARY KEY NOT NULL,
	"user_id" integer,
	"ip_address" text,
	"success" boolean NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);

CREATE TABLE "recharge_batches" (
	"id" serial PRIMARY KEY NOT NULL,
	"batch_ref" text NOT NULL,
	"face_value" numeric(10, 2) NOT NULL,
	"quantity" integer NOT NULL,
	"currency" text DEFAULT 'LYD' NOT NULL,
	"status" text DEFAULT 'ACTIVE' NOT NULL,
	"expires_at" timestamp,
	"created_by" integer NOT NULL,
	"exported_count" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "recharge_batches_batch_ref_unique" UNIQUE("batch_ref")
);

CREATE TABLE "recharge_cards" (
	"id" serial PRIMARY KEY NOT NULL,
	"batch_id" integer NOT NULL,
	"code_hash" text NOT NULL,
	"last4" text NOT NULL,
	"serial" text NOT NULL,
	"value" numeric(10, 2) NOT NULL,
	"status" text DEFAULT 'UNUSED' NOT NULL,
	"used_by" integer,
	"used_at" timestamp,
	"expires_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "recharge_cards_code_hash_unique" UNIQUE("code_hash"),
	CONSTRAINT "recharge_cards_serial_unique" UNIQUE("serial")
);

CREATE TABLE "reviews" (
	"id" serial PRIMARY KEY NOT NULL,
	"organization_id" integer NOT NULL,
	"booking_id" integer NOT NULL,
	"customer_id" integer NOT NULL,
	"rating" integer NOT NULL,
	"comment" text NOT NULL,
	"reply_from_provider" text,
	"is_published" boolean DEFAULT true NOT NULL,
	"is_reported" boolean DEFAULT false NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);

CREATE TABLE "service_staff" (
	"id" serial PRIMARY KEY NOT NULL,
	"service_id" integer NOT NULL,
	"staff_id" integer NOT NULL
);

CREATE TABLE "services" (
	"id" serial PRIMARY KEY NOT NULL,
	"organization_id" integer NOT NULL,
	"branch_id" integer,
	"name_ar" text NOT NULL,
	"description_ar" text NOT NULL,
	"duration_minutes" integer DEFAULT 60 NOT NULL,
	"buffer_minutes" integer DEFAULT 15 NOT NULL,
	"price" numeric(10, 2) NOT NULL,
	"deposit_amount" numeric(10, 2) DEFAULT '0.00' NOT NULL,
	"currency" text DEFAULT 'LYD' NOT NULL,
	"require_approval" boolean DEFAULT false NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"custom_commission_percent" numeric(5, 2),
	"created_at" timestamp DEFAULT now() NOT NULL
);

CREATE TABLE "staff" (
	"id" serial PRIMARY KEY NOT NULL,
	"organization_id" integer NOT NULL,
	"branch_id" integer,
	"user_id" integer,
	"full_name" text NOT NULL,
	"title_ar" text NOT NULL,
	"phone" text,
	"email" text,
	"avatar_url" text,
	"role_title" text DEFAULT 'موظف' NOT NULL,
	"permissions_json" text DEFAULT '[]' NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);

CREATE TABLE "subscription_plans" (
	"id" serial PRIMARY KEY NOT NULL,
	"slug" text NOT NULL,
	"name_ar" text NOT NULL,
	"monthly_price" numeric(10, 2) NOT NULL,
	"yearly_price" numeric(10, 2) NOT NULL,
	"currency" text DEFAULT 'LYD' NOT NULL,
	"max_branches" integer DEFAULT 1 NOT NULL,
	"max_staff" integer DEFAULT 3 NOT NULL,
	"commission_rate" numeric(5, 2) DEFAULT '7.00' NOT NULL,
	"features_json" text NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	CONSTRAINT "subscription_plans_slug_unique" UNIQUE("slug")
);

CREATE TABLE "subscriptions" (
	"id" serial PRIMARY KEY NOT NULL,
	"organization_id" integer NOT NULL,
	"plan_id" integer NOT NULL,
	"status" text DEFAULT 'ACTIVE' NOT NULL,
	"start_date" timestamp DEFAULT now() NOT NULL,
	"renewal_date" timestamp NOT NULL,
	"is_trial" boolean DEFAULT false NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "subscriptions_organization_id_unique" UNIQUE("organization_id")
);

CREATE TABLE "support_tickets" (
	"id" serial PRIMARY KEY NOT NULL,
	"ticket_ref" text NOT NULL,
	"user_id" integer NOT NULL,
	"subject" text NOT NULL,
	"category" text NOT NULL,
	"status" text DEFAULT 'OPEN' NOT NULL,
	"priority" text DEFAULT 'NORMAL' NOT NULL,
	"message" text NOT NULL,
	"admin_reply" text,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "support_tickets_ticket_ref_unique" UNIQUE("ticket_ref")
);

CREATE TABLE "system_settings" (
	"id" serial PRIMARY KEY NOT NULL,
	"key" text NOT NULL,
	"value" text NOT NULL,
	"description" text,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "system_settings_key_unique" UNIQUE("key")
);

CREATE TABLE "ticket_orders" (
	"id" serial PRIMARY KEY NOT NULL,
	"order_ref" text NOT NULL,
	"event_id" integer NOT NULL,
	"tier_id" integer NOT NULL,
	"user_id" integer NOT NULL,
	"quantity" integer NOT NULL,
	"unit_price" numeric(10, 2) NOT NULL,
	"fee" numeric(10, 2) NOT NULL,
	"total" numeric(10, 2) NOT NULL,
	"status" text DEFAULT 'PAID' NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "ticket_orders_order_ref_unique" UNIQUE("order_ref")
);

CREATE TABLE "ticket_tiers" (
	"id" serial PRIMARY KEY NOT NULL,
	"event_id" integer NOT NULL,
	"name_ar" text NOT NULL,
	"price" numeric(10, 2) NOT NULL,
	"capacity" integer NOT NULL,
	"sold" integer DEFAULT 0 NOT NULL,
	"max_per_order" integer DEFAULT 6 NOT NULL
);

CREATE TABLE "user_wallets" (
	"id" serial PRIMARY KEY NOT NULL,
	"user_id" integer NOT NULL,
	"balance" numeric(12, 2) DEFAULT '0.00' NOT NULL,
	"currency" text DEFAULT 'LYD' NOT NULL,
	"is_frozen" boolean DEFAULT false NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "user_wallets_user_id_unique" UNIQUE("user_id")
);

CREATE TABLE "users" (
	"id" serial PRIMARY KEY NOT NULL,
	"role" text DEFAULT 'CUSTOMER' NOT NULL,
	"full_name" text NOT NULL,
	"phone" text NOT NULL,
	"email" text,
	"password_hash" text NOT NULL,
	"avatar_url" text,
	"city" text DEFAULT 'طرابلس' NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"is_phone_verified" boolean DEFAULT true NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "users_phone_unique" UNIQUE("phone"),
	CONSTRAINT "users_email_unique" UNIQUE("email")
);

CREATE TABLE "vip_benefits" (
	"id" serial PRIMARY KEY NOT NULL,
	"tier_id" integer NOT NULL,
	"key" text NOT NULL,
	"title_ar" text NOT NULL,
	"value" numeric(10, 2) DEFAULT '0.00' NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL
);

CREATE TABLE "vip_memberships" (
	"id" serial PRIMARY KEY NOT NULL,
	"user_id" integer NOT NULL,
	"tier_id" integer NOT NULL,
	"status" text DEFAULT 'ACTIVE' NOT NULL,
	"starts_at" timestamp DEFAULT now() NOT NULL,
	"ends_at" timestamp NOT NULL,
	"granted_by" integer,
	"created_at" timestamp DEFAULT now() NOT NULL
);

CREATE TABLE "vip_tiers" (
	"id" serial PRIMARY KEY NOT NULL,
	"slug" text NOT NULL,
	"name_ar" text NOT NULL,
	"level" integer DEFAULT 1 NOT NULL,
	"price_lyd" numeric(10, 2) DEFAULT '0.00' NOT NULL,
	"duration_days" integer DEFAULT 365 NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "vip_tiers_slug_unique" UNIQUE("slug")
);

CREATE TABLE "wallet_campaigns" (
	"id" serial PRIMARY KEY NOT NULL,
	"title_ar" text NOT NULL,
	"min_recharge" numeric(10, 2) NOT NULL,
	"bonus_amount" numeric(10, 2) NOT NULL,
	"vip_only" boolean DEFAULT false NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"ends_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL
);

CREATE TABLE "wallet_transactions" (
	"id" serial PRIMARY KEY NOT NULL,
	"tx_ref" text NOT NULL,
	"user_id" integer NOT NULL,
	"wallet_id" integer NOT NULL,
	"type" text NOT NULL,
	"amount" numeric(12, 2) NOT NULL,
	"balance_before" numeric(12, 2) NOT NULL,
	"balance_after" numeric(12, 2) NOT NULL,
	"source" text NOT NULL,
	"reference" text,
	"note" text,
	"status" text DEFAULT 'COMPLETED' NOT NULL,
	"actor_id" integer,
	"created_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "wallet_transactions_tx_ref_unique" UNIQUE("tx_ref")
);

CREATE TABLE "wallets" (
	"id" serial PRIMARY KEY NOT NULL,
	"organization_id" integer NOT NULL,
	"balance" numeric(12, 2) DEFAULT '0.00' NOT NULL,
	"pending_settlement" numeric(12, 2) DEFAULT '0.00' NOT NULL,
	"total_earned" numeric(12, 2) DEFAULT '0.00' NOT NULL,
	"total_commission_paid" numeric(12, 2) DEFAULT '0.00' NOT NULL,
	"total_paid_out" numeric(12, 2) DEFAULT '0.00' NOT NULL,
	"currency" text DEFAULT 'LYD' NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "wallets_organization_id_unique" UNIQUE("organization_id")
);

ALTER TABLE "audit_logs" ADD CONSTRAINT "audit_logs_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "bookings" ADD CONSTRAINT "bookings_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "bookings" ADD CONSTRAINT "bookings_branch_id_branches_id_fk" FOREIGN KEY ("branch_id") REFERENCES "public"."branches"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "bookings" ADD CONSTRAINT "bookings_service_id_services_id_fk" FOREIGN KEY ("service_id") REFERENCES "public"."services"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "bookings" ADD CONSTRAINT "bookings_staff_id_staff_id_fk" FOREIGN KEY ("staff_id") REFERENCES "public"."staff"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "bookings" ADD CONSTRAINT "bookings_customer_id_users_id_fk" FOREIGN KEY ("customer_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "branches" ADD CONSTRAINT "branches_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "bus_seats" ADD CONSTRAINT "bus_seats_trip_id_bus_trips_id_fk" FOREIGN KEY ("trip_id") REFERENCES "public"."bus_trips"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "bus_seats" ADD CONSTRAINT "bus_seats_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "bus_trips" ADD CONSTRAINT "bus_trips_operator_id_organizations_id_fk" FOREIGN KEY ("operator_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "care_requests" ADD CONSTRAINT "care_requests_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "care_requests" ADD CONSTRAINT "care_requests_assigned_to_users_id_fk" FOREIGN KEY ("assigned_to") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "ledger_entries" ADD CONSTRAINT "ledger_entries_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "ledger_entries" ADD CONSTRAINT "ledger_entries_bookingId_bookings_id_fk" FOREIGN KEY ("bookingId") REFERENCES "public"."bookings"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "notifications" ADD CONSTRAINT "notifications_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "notifications" ADD CONSTRAINT "notifications_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "organizations" ADD CONSTRAINT "organizations_owner_id_users_id_fk" FOREIGN KEY ("owner_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "organizations" ADD CONSTRAINT "organizations_category_id_categories_id_fk" FOREIGN KEY ("category_id") REFERENCES "public"."categories"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "payouts" ADD CONSTRAINT "payouts_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "payouts" ADD CONSTRAINT "payouts_processed_by_user_id_users_id_fk" FOREIGN KEY ("processed_by_user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "recharge_attempts" ADD CONSTRAINT "recharge_attempts_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "recharge_batches" ADD CONSTRAINT "recharge_batches_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "recharge_cards" ADD CONSTRAINT "recharge_cards_batch_id_recharge_batches_id_fk" FOREIGN KEY ("batch_id") REFERENCES "public"."recharge_batches"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "recharge_cards" ADD CONSTRAINT "recharge_cards_used_by_users_id_fk" FOREIGN KEY ("used_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "reviews" ADD CONSTRAINT "reviews_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "reviews" ADD CONSTRAINT "reviews_booking_id_bookings_id_fk" FOREIGN KEY ("booking_id") REFERENCES "public"."bookings"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "reviews" ADD CONSTRAINT "reviews_customer_id_users_id_fk" FOREIGN KEY ("customer_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "service_staff" ADD CONSTRAINT "service_staff_service_id_services_id_fk" FOREIGN KEY ("service_id") REFERENCES "public"."services"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "service_staff" ADD CONSTRAINT "service_staff_staff_id_staff_id_fk" FOREIGN KEY ("staff_id") REFERENCES "public"."staff"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "services" ADD CONSTRAINT "services_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "services" ADD CONSTRAINT "services_branch_id_branches_id_fk" FOREIGN KEY ("branch_id") REFERENCES "public"."branches"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "staff" ADD CONSTRAINT "staff_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "staff" ADD CONSTRAINT "staff_branch_id_branches_id_fk" FOREIGN KEY ("branch_id") REFERENCES "public"."branches"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "staff" ADD CONSTRAINT "staff_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "subscriptions" ADD CONSTRAINT "subscriptions_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "subscriptions" ADD CONSTRAINT "subscriptions_plan_id_subscription_plans_id_fk" FOREIGN KEY ("plan_id") REFERENCES "public"."subscription_plans"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "support_tickets" ADD CONSTRAINT "support_tickets_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "ticket_orders" ADD CONSTRAINT "ticket_orders_event_id_events_id_fk" FOREIGN KEY ("event_id") REFERENCES "public"."events"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "ticket_orders" ADD CONSTRAINT "ticket_orders_tier_id_ticket_tiers_id_fk" FOREIGN KEY ("tier_id") REFERENCES "public"."ticket_tiers"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "ticket_orders" ADD CONSTRAINT "ticket_orders_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "ticket_tiers" ADD CONSTRAINT "ticket_tiers_event_id_events_id_fk" FOREIGN KEY ("event_id") REFERENCES "public"."events"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "user_wallets" ADD CONSTRAINT "user_wallets_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "vip_benefits" ADD CONSTRAINT "vip_benefits_tier_id_vip_tiers_id_fk" FOREIGN KEY ("tier_id") REFERENCES "public"."vip_tiers"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "vip_memberships" ADD CONSTRAINT "vip_memberships_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "vip_memberships" ADD CONSTRAINT "vip_memberships_tier_id_vip_tiers_id_fk" FOREIGN KEY ("tier_id") REFERENCES "public"."vip_tiers"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "vip_memberships" ADD CONSTRAINT "vip_memberships_granted_by_users_id_fk" FOREIGN KEY ("granted_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "wallet_transactions" ADD CONSTRAINT "wallet_transactions_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "wallet_transactions" ADD CONSTRAINT "wallet_transactions_wallet_id_user_wallets_id_fk" FOREIGN KEY ("wallet_id") REFERENCES "public"."user_wallets"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "wallet_transactions" ADD CONSTRAINT "wallet_transactions_actor_id_users_id_fk" FOREIGN KEY ("actor_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "wallets" ADD CONSTRAINT "wallets_organization_id_organizations_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;
CREATE INDEX "audit_entity_idx" ON "audit_logs" USING btree ("entity");
CREATE INDEX "audit_created_idx" ON "audit_logs" USING btree ("created_at");
CREATE INDEX "bookings_org_date_idx" ON "bookings" USING btree ("organization_id","booking_date");
CREATE INDEX "bookings_customer_idx" ON "bookings" USING btree ("customer_id");
CREATE INDEX "bookings_status_idx" ON "bookings" USING btree ("status");
CREATE UNIQUE INDEX "unique_active_slot_idx" ON "bookings" USING btree ("organization_id","branch_id","booking_date","start_time","status");
CREATE UNIQUE INDEX "bus_seat_unique" ON "bus_seats" USING btree ("trip_id","seat_no");
CREATE INDEX "bus_seats_user_idx" ON "bus_seats" USING btree ("user_id");
CREATE INDEX "bus_route_idx" ON "bus_trips" USING btree ("from_city","to_city","trip_date");
CREATE INDEX "care_status_idx" ON "care_requests" USING btree ("status","created_at");
CREATE INDEX "ledger_org_idx" ON "ledger_entries" USING btree ("organization_id");
CREATE INDEX "ledger_type_idx" ON "ledger_entries" USING btree ("transaction_type");
CREATE INDEX "orgs_category_idx" ON "organizations" USING btree ("category_id");
CREATE INDEX "orgs_city_idx" ON "organizations" USING btree ("city");
CREATE INDEX "orgs_slug_idx" ON "organizations" USING btree ("slug");
CREATE INDEX "otp_phone_idx" ON "otp_codes" USING btree ("phone","created_at");
CREATE INDEX "ratt_user_idx" ON "recharge_attempts" USING btree ("user_id","created_at");
CREATE INDEX "ratt_ip_idx" ON "recharge_attempts" USING btree ("ip_address","created_at");
CREATE INDEX "cards_batch_idx" ON "recharge_cards" USING btree ("batch_id","status");
CREATE INDEX "tickets_user_idx" ON "ticket_orders" USING btree ("user_id");
CREATE INDEX "users_role_idx" ON "users" USING btree ("role");
CREATE INDEX "users_phone_idx" ON "users" USING btree ("phone");
CREATE INDEX "vip_user_idx" ON "vip_memberships" USING btree ("user_id");
CREATE INDEX "wtx_user_idx" ON "wallet_transactions" USING btree ("user_id","created_at");
