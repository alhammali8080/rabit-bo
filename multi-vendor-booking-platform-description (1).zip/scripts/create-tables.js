#!/usr/bin/env node
// ينشئ كل الجداول في قاعدة بيانات فارغة.
// الاستخدام: node scripts/create-tables.js "<DATABASE_URL>"
import { readFileSync } from "node:fs";
import pg from "pg";

const url = process.argv[2] || process.env.DATABASE_URL;
if (!url) {
  console.error('الاستخدام: node scripts/create-tables.js "postgresql://user:pass@host/db?sslmode=require"');
  process.exit(1);
}

let sql = readFileSync(new URL("../deploy/schema.sql", import.meta.url), "utf8");
// يجعل التنفيذ قابلاً للتكرار: يقفز عن الجداول والفهارس والقيود الموجودة مسبقاً
sql = sql.replace(/CREATE TABLE /g, "CREATE TABLE IF NOT EXISTS ")
         .replace(/CREATE UNIQUE INDEX /g, "CREATE UNIQUE INDEX IF NOT EXISTS ")
         .replace(/CREATE INDEX /g, "CREATE INDEX IF NOT EXISTS ")

const client = new pg.Client({ connectionString: url, ssl: { rejectUnauthorized: false } });

try {
  await client.connect();
  // قيود المفاتيح الأجنبية: أسماؤها ثابتة من Drizzle، فنتخطى الموجود منها فقط
  const existing = await client.query(
    "select conname from pg_constraint where contype='f' and connamespace = 'public'::regnamespace"
  );
  const have = new Set(existing.rows.map((r) => r.conname));
  const kept = sql
    .split(";\n")
    .filter((stmt) => {
      const m = stmt.match(/ADD CONSTRAINT\s+"?([a-zA-Z0-9_]+)"?/);
      return !(m && have.has(m[1]));
    })
    .join(";\n");

  await client.query(kept);
  const { rows: cols } = await client.query("select count(*)::int as n from information_schema.columns where table_schema='public'");
  console.log("columns: " + cols[0].n);
  const { rows } = await client.query("select count(*)::int as n from information_schema.tables where table_schema='public'");
  console.log("OK: tables created. count = " + rows[0].n);
} catch (e) {
  console.error("FAILED: " + e.message);
  process.exit(1);
} finally {
  await client.end();
}
